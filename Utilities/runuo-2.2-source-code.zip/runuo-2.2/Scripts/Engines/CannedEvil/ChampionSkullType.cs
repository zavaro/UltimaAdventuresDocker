using System;
using Server;

namespace Server.Engines.CannedEvil
{
	public enum ChampionSkullType
	{
		Power,
		Enlightenment,
		Venom,
		Pain,
		Greed,
		Death
	}
}