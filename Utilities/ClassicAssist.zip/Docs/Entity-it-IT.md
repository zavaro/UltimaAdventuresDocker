# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Elemento  
### AddFriend  
  
Sintassi del comando:  
  
**Int32 AddFriend(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Aggiunge un mobile all'elenco amici, verra richiesto un target se nessun seriale è inserito**  
  
Esempio:  
  
```python  
AddFriend()  
```  
  
### Ally  
  
Sintassi del comando:  
  
**Boolean Ally(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se la notorietà del mobile è Ally**  
  
Esempio:  
  
```python  
if Criminal("mount"):  
```  
  
### AutoColorPick  
  
Sintassi del comando:  
  
**Void AutoColorPick(Int32)**  
  
#### Parametri  
* hue: ID colore oggetto o -1 per tutti.  
  
Descrizione:  
  
**Imposta una risposta automati al gump delle tite di Colori, permettendo di definire un colore specifico. Il comando va' inserito prima dell'azione che opre il gump dei colori.**  
  
Esempio:  
  
```python  
AutoColorPick(666)
UseObject('dyes')
WaitForTarget(1000)
Target('tub')  
```  
  
### BuffExists  
  
Sintassi del comando:  
  
**Boolean BuffExists(System.String)**  
  
#### Parametri  
* name: Nome Vuff.  
  
Descrizione:  
  
**Risulta se un buff/debuff è presente**  
  
Esempio:  
  
```python  
if BuffExists("Blood Oath"):  
```  
  
### BuffTime  
  
Sintassi del comando:  
  
**Double BuffTime(System.String)**  
  
#### Parametri  
* name: Nome Vuff.  
  
Descrizione:  
  
**Risulta i millisecondi rimanenti di un buff. 0 se scaduto / non abilitato.**  
  
Esempio:  
  
```python  
if not BuffExists('Enemy Of One') or BuffTime('Enemy Of One') < 5000:
    Cast('Enemy Of One')
  
```  
  
### ClearIgnoreList  
  
Sintassi del comando:  
  
**Void ClearIgnoreList()**  
  
Descrizione:  
  
**Pulisci la IgnoreList**  
  
Esempio:  
  
```python  
ClearIgnoreList()  
```  
  
### CountType  
  
Sintassi del comando:  
  
**Int32 CountType(Int32, System.Object, Int32)**  
  
#### Parametri  
* graphic: ID oggetto o ID grafico tipo 0x3db.  
* source: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
* hue: ID colore oggetto o -1 per tutti. (Opzionale)  
  
Descrizione:  
  
**Conta gli oggetti in un continer (seriale grafico)**  
  
Esempio:  
  
```python  
CountType(0xff, "backpack")  
```  
  
### CountTypeGround  
  
Sintassi del comando:  
  
**Int32 CountTypeGround(Int32, Int32, Int32)**  
  
#### Parametri  
* graphic: ID oggetto o ID grafico tipo 0x3db.  
* hue: ID colore oggetto o -1 per tutti. (Opzionale)  
* range: Raggio, per esempio 10. (Opzionale)  
  
Descrizione:  
  
**Conta gli oggetti a terra o mobili in schermo**  
  
Esempio:  
  
```python  
if CountGround(0xff, 0, 10) < 1:  
```  
  
### Criminal  
  
Sintassi del comando:  
  
**Boolean Criminal(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se la notorietà del mobile è Criminal**  
  
Esempio:  
  
```python  
if Criminal("mount"):  
```  
  
### Dead  
  
Sintassi del comando:  
  
**Boolean Dead(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta se l'alias è morto (predefinito: self)**  
  
Esempio:  
  
```python  
if Dead("self"):  
```  
  
### Dex  
  
Sintassi del comando:  
  
**Int32 Dex()**  
  
Descrizione:  
  
**Risulta in base alla destrezza**  
  
Esempio:  
  
```python  
if Str() < 100:  
```  
  
### DiffHits  
  
Sintassi del comando:  
  
**Int32 DiffHits(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta la differenza tra HP massimi e HP correnti**  
  
Esempio:  
  
```python  
if DiffHits("self") > 50:  
```  
  
### DiffWeight  
  
Sintassi del comando:  
  
**Int32 DiffWeight()**  
  
Descrizione:  
  
**Risulta la differenza tra peso e peso massimo**  
  
Esempio:  
  
```python  
if DiffWeight() > 50:  
```  
  
### Direction  
  
Sintassi del comando:  
  
**System.String Direction(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Returns the Direction the given alias/serial is facing**  
  
Esempio:  
  
```python  
if Direction('enemy') == 'West':  
```  
  
### DirectionTo  
  
Sintassi del comando:  
  
**System.String DirectionTo(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Rivolge l'orientamento del giocatore verso l'alias desiderato**  
  
Esempio:  
  
```python  
Run(DirectionTo("enemy"))  
```  
  
### Distance  
  
Sintassi del comando:  
  
**Int32 Distance(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta la distanza di un alias (se in schermata)**  
  
Esempio:  
  
```python  
if Distance("mount") < 4:  
```  
  
### Enemy  
  
Sintassi del comando:  
  
**Boolean Enemy(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se la notorietà del mobile è Enemy**  
  
Esempio:  
  
```python  
if Criminal("mount"):  
```  
  
### EquipWand  
  
Sintassi del comando:  
  
**Boolean EquipWand(System.String, Int32)**  
  
#### Parametri  
* wandname: Nome Wand. Guarda anche: [WandTypes](#WandTypes)  
* minimumcharges: Valore intero: vedere la descrizione per l'utilizzo. (Opzionale)  
  
Descrizione:  
  
**Cerca una Wand nel tuo Zaino e la Equippa**  
  
Esempio:  
  
```python  
#Equip a fireball wand if one can be found in our backpack..
if FindWand("fireball", "backpack", 5):
 #Remove current item in hand
 if FindLayer("OneHanded"):
  ClearHands("left")
 #Equip the wand
 EquipWand("fireball")  
```  
  
### FindObject  
  
Sintassi del comando:  
  
**Boolean FindObject(System.Object, Int32, System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* range: Raggio, per esempio 10. (Opzionale)  
* findlocation: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Cerca per un alias o un seriale e lo imposta come found. Cerca in schermata, se nessuna origine è indicata **  
  
Esempio:  
  
```python  
# Find on ground
FindObject("mount")

# Find on ground with range
FindObject("mount", 10)

# Find in container, must specify search level or -1
FindObject("weapon", -1, "backpack")    
```  
  
### FindType  
  
Sintassi del comando:  
  
**Boolean FindType(Int32, Int32, System.Object, Int32, Int32)**  
  
#### Parametri  
* graphic: ID oggetto o ID grafico tipo 0x3db.  
* range: Raggio, per esempio 10. (Opzionale)  
* findlocation: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
* hue: ID colore oggetto o -1 per tutti. (Opzionale)  
* minimumstackamount: Numero intero che rappresenta un importo, ovvero 10. (Opzionale)  
  
Descrizione:  
  
**Cerca per un seriale grafico e lo imposta come found. Cerca in schermata, se nessuna origine è indicata **  
  
Esempio:  
  
```python  
# Look for a food item from a list and eat 1 if found.
if not ListExists("food"): 
 CreateList("food") 
 PushList("food", 0x9b7) #bird 
 PushList("food", 0x9d3) #ham 
 PushList("food", 0x97d) #cheese 
 PushList("food", 0x9d0) #apple 
 PushList("food", 0x9eb) #muffin 
 PushList("food", 0x97b) #fishsteak 
 PushList("food", 0x9c0) #sausage 
 PushList("food", 0x9f2) #ribs 
 PushList("food", 0x9d1) #grapes 
 PushList("food", 0x9d2) #peach 

for i in GetList("food"): 
 if FindType(i, -1, "backpack"): 
  UseObject("found") 
  break  
```  
  
### FindWand  
  
Sintassi del comando:  
  
**Boolean FindWand(System.String, System.Object, Int32)**  
  
#### Parametri  
* wandname: Nome Wand. Guarda anche: [WandTypes](#WandTypes)  
* containersource: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
* minimumcharges: Valore intero: vedere la descrizione per l'utilizzo. (Opzionale)  
  
Descrizione:  
  
**Cerca una Want e la imposta come Alias "found"**  
  
Esempio:  
  
```python  
FindWand("fireball", "backpack", 10)  
```  
  
### Followers  
  
Sintassi del comando:  
  
**Int32 Followers()**  
  
Descrizione:  
  
**Risulta il numero di Followers**  
  
Esempio:  
  
```python  
if Followers() < 1:  
```  
  
### Gold  
  
Sintassi del comando:  
  
**Int32 Gold()**  
  
Descrizione:  
  
**Risulta il Gold presente nello zaino**  
  
Esempio:  
  
```python  
if Gold() < 2000:  
```  
  
### Graphic  
  
Sintassi del comando:  
  
**Int32 Graphic(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta seriale grafico di un oggetto (alias o seriale)**  
  
Esempio:  
  
```python  
Graphic("mount")  
```  
  
### Gray  
  
Sintassi del comando:  
  
**Boolean Gray(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se notorietà del mobile è attaccabile senza diventare criminal**  
  
Esempio:  
  
```python  
if Criminal("mount"):  
```  
  
### Hidden  
  
Sintassi del comando:  
  
**Boolean Hidden(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta se sei hiddato (se non specificato, predefinito: self)**  
  
Esempio:  
  
```python  
if Hidden("self"):  
```  
  
### Hits  
  
Sintassi del comando:  
  
**Int32 Hits(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta gli HP di un alias (se non specificato, predefinito: self)**  
  
Esempio:  
  
```python  
hits = Hits("self")  
```  
  
### Hue  
  
Sintassi del comando:  
  
**Int32 Hue(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta il colore di un oggetto (alias o seriale)**  
  
Esempio:  
  
```python  
if Hue("mount") == 0:  
```  
  
### IgnoreObject  
  
Sintassi del comando:  
  
**Void IgnoreObject(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Inserisci nella IgnoreList un oggetto. Non verra più considerato.**  
  
Esempio:  
  
```python  
IgnoreObject("self")  
```  
  
### InFriendList  
  
Sintassi del comando:  
  
**Boolean InFriendList(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se il mobile è presente in FriendList**  
  
Esempio:  
  
```python  
if InFriendList("last"):  
```  
  
### InIgnoreList  
  
Sintassi del comando:  
  
**Boolean InIgnoreList(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Controlla se un Serial o un Alias è presente nella Ignore List**  
  
Esempio:  
  
```python  
if InIgnoreList("mount"):  
```  
  
### Innocent  
  
Sintassi del comando:  
  
**Boolean Innocent(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se la notorietà del mobile è Innocent**  
  
Esempio:  
  
```python  
if Criminal("mount"):  
```  
  
### InParty  
  
Sintassi del comando:  
  
**Boolean InParty(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se il mobile è presente in Party**  
  
Esempio:  
  
```python  
if InParty("friend"):  
```  
  
### InRange  
  
Sintassi del comando:  
  
**Boolean InRange(System.Object, Int32)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* distance: Distanza.  
  
Descrizione:  
  
**Calcola la portata tra il tuo personaggio e un altro mobile od oggetto**  
  
Esempio:  
  
```python  
if InRange("enemy", 10):  
```  
  
### Int  
  
Sintassi del comando:  
  
**Int32 Int()**  
  
Descrizione:  
  
**Risulta in base all'intelligenza**  
  
Esempio:  
  
```python  
if Str() < 100:  
```  
  
### Invulnerable  
  
Sintassi del comando:  
  
**Boolean Invulnerable(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta  se la notorietà del mobile è Invulnerable**  
  
Esempio:  
  
```python  
if Criminal("mount"):  
```  
  
### Luck  
  
Sintassi del comando:  
  
**Int32 Luck()**  
  
Descrizione:  
  
**Risulta il valore di Luck**  
  
Esempio:  
  
```python  
if Luck() < 800:  
```  
  
### Mana  
  
Sintassi del comando:  
  
**Int32 Mana(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta l'ammontare di mana di un mobile**  
  
Esempio:  
  
```python  
if Mana("self") < 25:  
```  
  
### MaxFollowers  
  
Sintassi del comando:  
  
**Int32 MaxFollowers()**  
  
Descrizione:  
  
**Risulta se i Follower sono al massimo**  
  
Esempio:  
  
```python  
if Followers() == MaxFollowers():  
```  
  
### MaxHits  
  
Sintassi del comando:  
  
**Int32 MaxHits(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta se gli HP del mobile sono al massimo**  
  
Esempio:  
  
```python  
hits = MaxHits("self")  
```  
  
### MaxMana  
  
Sintassi del comando:  
  
**Int32 MaxMana(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta se il mana del mobile è al massimo**  
  
Esempio:  
  
```python  
mana = MaxMana("self")  
```  
  
### MaxStam  
  
Sintassi del comando:  
  
**Int32 MaxStam(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta se la stamina del mobile è al massimo**  
  
Esempio:  
  
```python  
stam = MaxStam("self")  
```  
  
### MaxWeight  
  
Sintassi del comando:  
  
**Int32 MaxWeight()**  
  
Descrizione:  
  
**Risulta il peso massimo**  
  
Esempio:  
  
```python  
if MaxWeight() < 300:  
```  
  
### Mounted  
  
Sintassi del comando:  
  
**Boolean Mounted(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se il mobile è montato**  
  
Esempio:  
  
```python  
if Mounted("self"):  
```  
  
### MoveItem  
  
Sintassi del comando:  
  
**Void MoveItem(System.Object, System.Object, Int32, Int32, Int32)**  
  
#### Parametri  
* item: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* destination: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* amount: Numero intero che rappresenta un importo, ovvero 10. (Opzionale)  
* x: X Coordinate. (Opzionale)  
* y: Y Coordinate. (Opzionale)  
  
Descrizione:  
  
**Muovi un oggetto in un contenitore (alias o seriale)**  
  
Esempio:  
  
```python  
MoveItem("source", "destination")  
```  
  
### MoveItemOffset  
  
Sintassi del comando:  
  
**Void MoveItemOffset(System.Object, Int32, Int32, Int32, Int32)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* xoffset: X Coordinate offset.  
* yoffset: Y Coordinate offset.  
* zoffset: Z Coordinate offset.  
* amount: Numero intero che rappresenta un importo, ovvero 10. (Opzionale)  
  
Descrizione:  
  
**Muovi un alias/seriale in una posizione x,y,z specifica attorno a te.  Se nessuna (o -1) quantità è specificata, verra spostata l'intero stock dell'oggetto**  
  
Esempio:  
  
```python  
MoveItemOffset("trashitem", 0, 1, 0, -1)  
```  
  
### MoveType  
  
Sintassi del comando:  
  
**Void MoveType(Int32, System.Object, System.Object, Int32, Int32, Int32, Int32, Int32)**  
  
#### Parametri  
* id: ID oggetto o ID grafico tipo 0x3db.  
* sourcecontainer: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* destinationcontainer: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* x: X Coordinate. (Opzionale)  
* y: Y Coordinate. (Opzionale)  
* z: Z Coordinate. (Opzionale)  
* hue: ID colore oggetto o -1 per tutti. (Opzionale)  
* amount: Numero intero che rappresenta un importo, ovvero 10. (Opzionale)  
  
Descrizione:  
  
**Muovi un seriale grafico da contenitore di origine ad uno di destinazione (seriale o alias)**  
  
Esempio:  
  
```python  
#To move a type to another container...

MoveType(0x170f, "backpack", "bank")

#Destination can be the ground by specifying destination container to -1 and specifying the coordinates...

MoveType(0x170f, "backpack", -1, 1928, 2526, 0)

#Optional parameters exist for Hue and Amount, to move 10 maximum with the a Hue of 50...
MoveType(0x170f, "backpack", "bank", -1, -1, 0, 50, 10)  
```  
  
### MoveTypeOffset  
  
Sintassi del comando:  
  
**Boolean MoveTypeOffset(Int32, System.Object, Int32, Int32, Int32, Int32)**  
  
#### Parametri  
* id: ID oggetto o ID grafico tipo 0x3db.  
* findlocation: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* xoffset: X Coordinate offset.  
* yoffset: Y Coordinate offset.  
* zoffset: Z Coordinate offset.  
* amount: Numero intero che rappresenta un importo, ovvero 10. (Opzionale)  
  
Descrizione:  
  
**Muovi un seriale grafico in una posizione x,y,z specifica attorno a te.  Se nessuna (o -1) quantità è specificata, verra spostata l'intero stock dell'oggetto**  
  
Esempio:  
  
```python  
MoveTypeOffset(0xf0e, "backpack", 0, 1, 0, -1)  
```  
  
### Murderer  
  
Sintassi del comando:  
  
**Boolean Murderer(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se la notorietà di un mobile è Murderer**  
  
Esempio:  
  
```python  
if Criminal("mount"):  
```  
  
### Name  
  
Sintassi del comando:  
  
**System.String Name(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta il nome di un mobile**  
  
Esempio:  
  
```python  
if Name("self") == "Shmoo":  
```  
  
### Paralyzed  
  
Sintassi del comando:  
  
**Boolean Paralyzed(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se un mobile è frozen**  
  
Esempio:  
  
```python  
if Paralyzed("self"):  
```  
  
### Poisoned  
  
Sintassi del comando:  
  
**Boolean Poisoned(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se un mobile è poisoned**  
  
Esempio:  
  
```python  
if Poisoned("self"):  
```  
  
### Rehue  
  
Sintassi del comando:  
  
**Void Rehue(System.Object, Int32)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* hue: ID colore oggetto o -1 per tutti.  
  
Descrizione:  
  
**Ricolora un elemento / mobile con la tonalità specificata, impostare su 0 per rimuovere. (Sperimentale)**  
  
Esempio:  
  
```python  
Rehue("mount", 1176)  
```  
  
### RemoveFriend  
  
Sintassi del comando:  
  
**Void RemoveFriend(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Rimuovi un mobile dalla FriendList, mosta il target se non specificato**  
  
Esempio:  
  
```python  
RemoveFriend()  
```  
  
### SpecialMoveExists  
  
Sintassi del comando:  
  
**Boolean SpecialMoveExists(System.String)**  
  
#### Parametri  
* name: Nome Special Ability.  
  
Descrizione:  
  
**Risulta se una Special Ability è attivata**  
  
Esempio:  
  
```python  
if SpecialMoveExists("Death Strike"):  
```  
  
### Stam  
  
Sintassi del comando:  
  
**Int32 Stam(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta la quantità di stamina di un mobile**  
  
Esempio:  
  
```python  
if Stam("self") < 25:  
```  
  
### Str  
  
Sintassi del comando:  
  
**Int32 Str()**  
  
Descrizione:  
  
**Risulta in base la forza**  
  
Esempio:  
  
```python  
if Str() < 100:  
```  
  
### TithingPoints  
  
Sintassi del comando:  
  
**Int32 TithingPoints()**  
  
Descrizione:  
  
**Risulta i TithingPoints correnti**  
  
Esempio:  
  
```python  
if TithingPoints() < 1000:  
```  
  
### UseLayer  
  
Sintassi del comando:  
  
**Boolean UseLayer(System.Object, System.Object)**  
  
#### Parametri  
* layer: Stringa che rappresenta un layer, tipo "OneHanded" o "Talisman" etc.  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Usa un oggetto che è in un Layer specifico. Parametri opzionali per Mobili**  
  
Esempio:  
  
```python  
UseLayer("Talisman")  
```  
  
### War  
  
Sintassi del comando:  
  
**Boolean War(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se in War**  
  
Esempio:  
  
```python  
if War("self"):  
```  
  
### Weight  
  
Sintassi del comando:  
  
**Int32 Weight()**  
  
Descrizione:  
  
**Risulta il peso corrente**  
  
Esempio:  
  
```python  
if Weight() > 300:  
```  
  
### X  
  
Sintassi del comando:  
  
**Int32 X(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta le cordinate X di un oggetto (alias o seriale)**  
  
Esempio:  
  
```python  
x = X("self")  
```  
  
### Y  
  
Sintassi del comando:  
  
**Int32 Y(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta le cordinate Y di un oggetto (alias o seriale)**  
  
Esempio:  
  
```python  
y = Y("self")  
```  
  
### YellowHits  
  
Sintassi del comando:  
  
**Boolean YellowHits(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se il mobile ha YellowHits**  
  
Esempio:  
  
```python  
if YellowHits("self"):  
```  
  
### Z  
  
Sintassi del comando:  
  
**Int32 Z(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta le cordinate Z di un oggetto (alias o seriale)**  
  
Esempio:  
  
```python  
y = Y("self")  
```  
  



## Tipi  
### WandTypes  
* Clumsy  
* Identification  
* Heal  
* Feeblemind  
* Weaken  
* Magic_Arrow  
* Harm  
* Fireball  
* Greater_Heal  
* Lightning  
* Mana_Drain  
  
