# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Umiejętności...  
### ActiveAbility  
  
Sygnatura metody:  
  
**Boolean ActiveAbility()**  
  
Opis:  
  
**Returns True if either the primary or secondary ability is set**  
  
Przykład:  
  
```python  
if not ActiveAbility():
 SetAbility("primary", "on")  
```  
  
### ClearAbility  
  
Sygnatura metody:  
  
**Void ClearAbility()**  
  
Opis:  
  
**Wyczyść zaznaczenie umiejętności broni**  
  
Przykład:  
  
```python  
ClearAbility()  
```  
  
### Fly  
  
Sygnatura metody:  
  
**Void Fly()**  
  
Opis:  
  
**(Gargoyle) Zaczyna latać o ile już nie lata.**  
  
Przykład:  
  
```python  
Fly()  
```  
  
### Flying  
  
Sygnatura metody:  
  
**Boolean Flying(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca true jeśli obiekt mobile obecnie lata.**  
  
Przykład:  
  
```python  
if Flying("self"):  
```  
  
### Land  
  
Sygnatura metody:  
  
**Void Land()**  
  
Opis:  
  
**(Gargoyle) Przestaje latać jeżeli obecnie lata.**  
  
Przykład:  
  
```python  
Land()  
```  
  
### SetAbility  
  
Sygnatura metody:  
  
**Void SetAbility(System.String, System.String)**  
  
#### Parametry  
* ability: Nazwa umiejętności broni. Możliwe wartości: "primary", "secondary", "stun" or "disarm".  
* onoff: "on" lub "off". (Opcjonalny)  
  
Opis:  
  
**Ustawia broń jako "primary" lub "secondary".**  
  
Przykład:  
  
```python  
SetAbility("primary")  
```  
  



