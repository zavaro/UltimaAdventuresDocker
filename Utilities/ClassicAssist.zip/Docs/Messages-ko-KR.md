# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 메시지  
### AllyMsg  
  
메서드 시그니처:  
  
**Void AllyMsg(System.String)**  
  
#### 파라미터  
* message: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**메시지를 동맹 채팅에 보냅니다.**  
  
예시:  
  
```python  
AllyMsg("alert")  
```  
  
### CancelPrompt  
  
메서드 시그니처:  
  
**Void CancelPrompt()**  
  
설명:  
  
**현재 프롬프트를 취소합니다.**  
  
예시:  
  
```python  
CancelPrompt()  
```  
  
### ChatMsg  
  
메서드 시그니처:  
  
**Void ChatMsg(System.String)**  
  
#### 파라미터  
* message: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**메시지를 보냅니다.**  
  
예시:  
  
```python  
ChatMsg("Mary had a little lamb")  
```  
  
### EmoteMsg  
  
메서드 시그니처:  
  
**Void EmoteMsg(System.String)**  
  
#### 파라미터  
* message: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**메시지를 표현합니다**  
  
예시:  
  
```python  
EmoteMsg("hi")  
```  
  
### GetText  
  
메서드 시그니처:  
  
**System.ValueTuple`2[System.Boolean,System.String] GetText(System.String, Int32)**  
  
#### 파라미터  
* prompt: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
* timeout: milliseconds 지정된 시간초과됨. (옵션)  
  
설명:  
  
**Sends an internal prompt request and returns the text entered**  
  
예시:  
  
```python  
res, name = GetText("Name?", 10000)

if res:
 Rename(0xc1b, name)  
```  
  
### GuildMsg  
  
메서드 시그니처:  
  
**Void GuildMsg(System.String)**  
  
#### 파라미터  
* message: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**길드 채팅에 메시지를 보냅니다.**  
  
예시:  
  
```python  
GuildMsg("alert")  
```  
  
### HeadMsg  
  
메서드 시그니처:  
  
**Void HeadMsg(System.String, System.Object, Int32)**  
  
#### 파라미터  
* message: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
* hue: 아이탬 색조 또는 모든 값에 -1. (옵션)  
  
설명:  
  
**지정된 대상에 위에 메시지를 표시합니다.**  
  
예시:  
  
```python  
HeadMsg("hi", "backpack")  
```  
  
### Msg  
  
메서드 시그니처:  
  
**Void Msg(System.String, Int32)**  
  
#### 파라미터  
* message: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
* hue: 아이탬 색조 또는 모든 값에 -1. (옵션)  
  
설명:  
  
**선택된 색상으로 메세지를 보냅니다.**  
  
예시:  
  
```python  
Msg("hi")  
```  
  
### PartyMsg  
  
메서드 시그니처:  
  
**Void PartyMsg(System.String)**  
  
#### 파라미터  
* message: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**메시지를 파티 채팅으로 보냅니다.**  
  
예시:  
  
```python  
PartyMsg("alert")  
```  
  
### PromptMsg  
  
메서드 시그니처:  
  
**Void PromptMsg(System.String)**  
  
#### 파라미터  
* message: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**메시지를 프롬프트 응답으로 보냅니다.**  
  
예시:  
  
```python  
PromptMsg("hello")  
```  
  
### WaitForPrompt  
  
메서드 시그니처:  
  
**Boolean WaitForPrompt(Int32)**  
  
#### 파라미터  
* timeout: milliseconds 지정된 시간초과됨.  
  
설명:  
  
**프롬프트 패킷이 수신 될 때까지 지정된 시간동안 대기합니다.**  
  
예시:  
  
```python  
WaitForPrompt(5000)  
```  
  
### WhisperMsg  
  
메서드 시그니처:  
  
**Void WhisperMsg(System.String)**  
  
#### 파라미터  
* message: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**메시지를 속삭입니다.**  
  
예시:  
  
```python  
WhisperMsg("hi")  
```  
  
### YellMsg  
  
메서드 시그니처:  
  
**Void YellMsg(System.String)**  
  
#### 파라미터  
* message: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**메시지를 외칩니다**  
  
예시:  
  
```python  
YellMsg("hi")  
```  
  



