# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 이동  
### Pathfind  
  
메서드 시그니처:  
  
**Void Pathfind(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**Requests client to pathfind to given coordinates / entity**  
  
예시:  
  
```python  
#Pathfind to coordinates
Pathfind(1438, 1630, 20)

#Pathfind to entity
SetEnemy(0x3c9)
Pathfind('enemy')  
```  
  
### Pathfind  
  
메서드 시그니처:  
  
**Void Pathfind(Int32, Int32, Int32)**  
  
#### 파라미터  
* x: X 좌표.  
* y: Y 좌표.  
* z: Z 좌표.  
  
설명:  
  
**Requests client to pathfind to given coordinates / entity**  
  
예시:  
  
```python  
#Pathfind to coordinates
Pathfind(1438, 1630, 20)

#Pathfind to entity
SetEnemy(0x3c9)
Pathfind('enemy')  
```  
  
### Run  
  
메서드 시그니처:  
  
**Boolean Run(System.String)**  
  
#### 파라미터  
* direction: 방향 예시) "서쪽". 참조: [Direction](#Direction)  
  
설명:  
  
**동쪽 방향으로 달린다.**  
  
예시:  
  
```python  
Run("east")  
```  
  
### SetForceWalk  
  
메서드 시그니처:  
  
**Void SetForceWalk(Boolean)**  
  
설명:  
  
**포스 걷기 설정**  
  
예시:  
  
```python  
SetForceWalk(True)  
```  
  
### ToggleForceWalk  
  
메서드 시그니처:  
  
**Void ToggleForceWalk()**  
  
설명:  
  
**포스 걷기 토글**  
  
예시:  
  
```python  
ToggleForceWalk()  
```  
  
### Turn  
  
메서드 시그니처:  
  
**Void Turn(System.String)**  
  
#### 파라미터  
* direction: 방향 예시) "서쪽". 참조: [Direction](#Direction)  
  
설명:  
  
**동쪽 방향으로 돕니다.**  
  
예시:  
  
```python  
Turn("east")  
```  
  
### Walk  
  
메서드 시그니처:  
  
**Boolean Walk(System.String)**  
  
#### 파라미터  
* direction: 방향 예시) "서쪽".  
  
설명:  
  
**동쪽  방향으로 걷습니다.**  
  
예시:  
  
```python  
Walk("east")  
```  
  



## 타입  
### Direction  
* North  
* Northeast  
* East  
* Southeast  
* South  
* Southwest  
* West  
* Northwest  
* Invalid  
  
