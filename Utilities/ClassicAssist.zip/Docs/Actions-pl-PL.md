# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Akcje  
### Attack  
  
Sygnatura metody:  
  
**Void Attack(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Atakuj obiek mobile (przekazywany parametr może być serialem lub aliasem).**  
  
Przykład:  
  
```python  
Attack("last")  
```  
  
### BandageSelf  
  
Sygnatura metody:  
  
**Boolean BandageSelf()**  
  
Opis:  
  
**Używa bandaży bezpośrednio na postaci.**  
  
Przykład:  
  
```python  
BandageSelf()  
```  
  
### ClearHands  
  
Sygnatura metody:  
  
**Void ClearHands(System.String)**  
  
#### Parametry  
* hand: Ręka. Możliwe wartości:  "left", "right", lub "both". (Opcjonalny)  
  
Opis:  
  
**Odkłada przedmioty z dłoni. Możlie wartości: "left", 'right", "both"**  
  
Przykład:  
  
```python  
ClearHands("both")  
```  
  
### ClearUseOnce  
  
Sygnatura metody:  
  
**Void ClearUseOnce()**  
  
Opis:  
  
**Czyści listę przedmiotów dla komendy UseOnce.**  
  
Przykład:  
  
```python  
Clear UseOnce()  
```  
  
### ClickObject  
  
Sygnatura metody:  
  
**Void ClickObject(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Pojedyńczy klik w przedmiot (parametr może być serialem albo aliasem)**  
  
Przykład:  
  
```python  
ClockObject("last")  
```  
  
### Contents  
  
Sygnatura metody:  
  
**Int32 Contents(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca liczbę przedmiotów w podanym kontenerze.**  
  
Przykład:  
  
```python  
if Contents("backpack") > 120:  
```  
  
### ContextMenu  
  
Sygnatura metody:  
  
**Void ContextMenu(System.Object, Int32)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* entry: Numer indeksu kontekstowego menu.  
  
Opis:  
  
**Żądanie otwarcia menu kontekstowego.**  
  
Przykład:  
  
```python  
ContextMenu(0x00aabbcc, 1)  
```  
  
### EquipItem  
  
Sygnatura metody:  
  
**Void EquipItem(System.Object, System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* layer: Zmienna String reprezentująca layer, np. "OneHanded" lub "Talisman" itp.... Zobacz też: [Layer](#Layer)  
  
Opis:  
  
**Zakłada wskazany przedmiot w podany layer (layer można sprawdzić za pomocją Inspektora Obiektów)**  
  
Przykład:  
  
```python  
EquipItem("axe", "TwoHanded")  
```  
  
### EquipLastWeapon  
  
Sygnatura metody:  
  
**Void EquipLastWeapon()**  
  
Opis:  
  
**Wysyła szybki pakiet założenia ostatniej broni. UWAGA! może nie działać przed wersją serwera AoS!**  
  
Przykład:  
  
```python  
EquipLastWeapon()  
```  
  
### EquipType  
  
Sygnatura metody:  
  
**Void EquipType(Int32, System.Object)**  
  
#### Parametry  
* id: ItemId/Grafika np. 0x3db.  
* layer: Zmienna String reprezentująca layer, np. "OneHanded" lub "Talisman" itp.... Zobacz też: [Layer](#Layer)  
  
Opis:  
  
**Zakłada wybrany typ przedmiotu w podany layer (layer można sprawdzić za pomocą Inspektora Obiektów)**  
  
Przykład:  
  
```python  
EquipType(0xff, "TwoHanded")  
```  
  
### Feed  
  
Sygnatura metody:  
  
**Void Feed(System.Object, Int32, Int32, Int32)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* graphic: ItemId/Grafika np. 0x3db.  
* amount: Zmienna integer reprezentująca liczbę, np. 10. (Opcjonalny)  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek). (Opcjonalny)  
  
Opis:  
  
**Uzupełnia podany alias albo serial grafiką.**  
  
Przykład:  
  
```python  
Feed("mount", 0xff)  
```  
  
### FindLayer  
  
Sygnatura metody:  
  
**Boolean FindLayer(System.Object, System.Object)**  
  
#### Parametry  
* layer: Zmienna String reprezentująca layer, np. "OneHanded" lub "Talisman" itp.... Zobacz też: [Layer](#Layer)  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Zwraca "true" oraz aktualizuje obiekt "found" o ile przedmiot istnieje w specyficznym layerze, opcjonalny seria/alias dla sprawdzenia obiektów typu mobile".**  
  
Przykład:  
  
```python  
if FindLayer("OneHanded"):  
```  
  
### InRegion  
  
Sygnatura metody:  
  
**Boolean InRegion(System.String, System.Object)**  
  
#### Parametry  
* attribute: Zmienna typu string - zobacz opis, aby zobaczyć użycie. Zobacz też: [RegionAttributes](#RegionAttributes)  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca "true"  o ile w podanym zakresie celu jest podany atrybut.**  
  
Przykład:  
  
```python  
if InRegion("Guarded", "self")  
```  
  
### Ping  
  
Sygnatura metody:  
  
**Int64 Ping()**  
  
Opis:  
  
**Zwraca wyliczony ping z serwera. W przypadku błędu zwraca "-1"**  
  
Przykład:  
  
```python  
Ping()  
```  
  
### Rename  
  
Sygnatura metody:  
  
**Void Rename(System.Object, System.String)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* name: Zmienna string reprezentująca nazwę, np. "Snoopy".  
  
Opis:  
  
**Wysyła żadanie zmiany nazwy.**  
  
Przykład:  
  
```python  
Rename("mount", "Snoopy")  
```  
  
### ShowNames  
  
Sygnatura metody:  
  
**Void ShowNames(System.String)**  
  
#### Parametry  
* showtype: Pokaż typy obiektów. Możliwe wartości "mobiles", lub "corpses". Zobacz też: [ShowNamesType](#ShowNamesType)  
  
Opis:  
  
**Wyświetla ciała lub/i nazwy mobile. Możliwe parametry: "mobiles", "corpses".**  
  
Przykład:  
  
```python  
ShowNames("corpses")  
```  
  
### ToggleMounted  
  
Sygnatura metody:  
  
**Void ToggleMounted()**  
  
Opis:  
  
**Zejście ze zwierzęcia jeśli w siodle lub wejśćie na zwierzę jeśli nie w siodle. Polecenie poprosi o zwierze jeśli nie podany jest jego alias.**  
  
Przykład:  
  
```python  
ToggleMounted()  
```  
  
### UseObject  
  
Sygnatura metody:  
  
**Void UseObject(System.Object, Boolean)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* skipqueue: Nie zdefiniowano - zobacz opis, aby zobaczyć użycie. (Opcjonalny)  
  
Opis:  
  
**Używa przedmiotu (dwuklik). Parametrem może być serial albo alias.**  
  
Przykład:  
  
```python  
UseObject("mount")  
```  
  
### UseOnce  
  
Sygnatura metody:  
  
**Boolean UseOnce(Int32, Int32)**  
  
#### Parametry  
* graphic: ItemId/Grafika np. 0x3db.  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek). (Opcjonalny)  
  
Opis:  
  
**Używa tylko raz podanego typu obiektu (grafiki) z twojego plecaka.**  
  
Przykład:  
  
```python  
UseOnce(0xff)  
```  
  
### UseTargetedItem  
  
Sygnatura metody:  
  
**Void UseTargetedItem(System.Object, System.Object)**  
  
#### Parametry  
* item: An entity serial in integer or hex format, or an alias string such as "self".  
* target: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Używa podanego przedmiotu lub celu w jednej akcji. Wymaga wsparcia OSI/ServUO**  
  
Przykład:  
  
```python  
UseTargetedItem('bandage', 'pet')  
```  
  
### UseType  
  
Sygnatura metody:  
  
**Void UseType(System.Object, Int32, System.Object)**  
  
#### Parametry  
* type: An entity serial in integer or hex format, or an alias string such as "self".  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek). (Opcjonalny)  
* container: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Używa przedmiotu o podanym typie (dwuklik). Opcjonalne parametry to kolor i obiekt kontenera (domyślnie ustawiony jest plecak gracza). Parametry mogą być serialem lub aliasem.**  
  
Przykład:  
  
```python  
UseType(0xff)  
```  
  
### WaitForContents  
  
Sygnatura metody:  
  
**Boolean WaitForContents(System.Object, Int32)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* timeout: Timeout w milisekundach. (Opcjonalny)  
  
Opis:  
  
**Czeka na zawartość podanego kontenera.**  
  
Przykład:  
  
```python  
WaitForContents("backpack", 5000)  
```  
  
### WaitForContext  
  
Sygnatura metody:  
  
**Boolean WaitForContext(System.Object, Int32, Int32)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* entry: Numer indeksu kontekstowego menu.  
* timeout: Timeout w milisekundach.  
  
Opis:  
  
**Żądanie lub oczekiwanie na opcję wybraną z menu kontekstowego.**  
  
Przykład:  
  
```python  
WaitForContext(0x00aabbcc, 1, 5000)  
```  
  



## Typy  
### Layer  
* Invalid  
* OneHanded  
* TwoHanded  
* Shoes  
* Pants  
* Shirt  
* Helm  
* Gloves  
* Ring  
* Talisman  
* Neck  
* Hair  
* Waist  
* InnerTorso  
* Bracelet  
* Unused_xF  
* FacialHair  
* MiddleTorso  
* Earrings  
* Arms  
* Cloak  
* Backpack  
* OuterTorso  
* OuterLegs  
* InnerLegs  
* Mount  
* ShopBuy  
* ShopResale  
* ShopSell  
* Bank  
* LastValid  
  
### RegionAttributes  
* None  
* Guarded  
* Jail  
* Wilderness  
* Town  
* Dungeon  
* Special  
* Default  
  
### ShowNamesType  
* Mobiles  
* Corpses  
  
