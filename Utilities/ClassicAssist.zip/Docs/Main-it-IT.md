# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Principale  
### DisplayQuestPointer  
  
Sintassi del comando:  
  
**Void DisplayQuestPointer(Int32, Int32, Boolean)**  
  
#### Parametri  
* x: X Coordinate.  
* y: Y Coordinate.  
* enabled: Valore True/False, vedere la descrizione per l'uso. (Opzionale)  
  
Descrizione:  
  
**Mostra il puntatore a freccia (quest) alle coordinate specificate**  
  
Esempio:  
  
```python  
# add pointer
DisplayQuestPointer(1000, 1000, True)
Pause(2000)
# remove pointer
DisplayQuestPointer(1000, 1000, False)  
```  
  
### HideEntity  
  
Sintassi del comando:  
  
**Void HideEntity(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Rimuove un Oggetto/Mobile dallo schermo**  
  
Esempio:  
  
```python  
ClearIgnoreList()
# Hide all corpses on screen
while FindType(0x2006):
 HideEntity('found')
 IgnoreObject('found')  
```  
  
### Hotkeys  
  
Sintassi del comando:  
  
**Void Hotkeys(System.String)**  
  
#### Parametri  
* onoff: "on" oppure "off". (Opzionale)  
  
Descrizione:  
  
**Abilita/Disabilita i Tasti Rapidi**  
  
Esempio:  
  
```python  
Hotkeys()  
```  
  
### Info  
  
Sintassi del comando:  
  
**Void Info(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Ispeziona Oggetto (seriale o alias. Altrimenti apre un Target)**  
  
Esempio:  
  
```python  
Info("self")  
```  
  
### InvokeVirtue  
  
Sintassi del comando:  
  
**Void InvokeVirtue(System.String)**  
  
#### Parametri  
* virtue: Valore stringa: vedere la descrizione per l'utilizzo. Guarda anche: [Virtues](#Virtues)  
  
Descrizione:  
  
**Utilizza una Virtù**  
  
Esempio:  
  
```python  
InvokeVirtue("Honor")  
```  
  
### MessageBox  
  
Sintassi del comando:  
  
**Void MessageBox(System.String, System.String)**  
  
#### Parametri  
* title: Valore stringa: vedere la descrizione per l'utilizzo.  
* body: Valore stringa: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Fai apparire un Box di avviso con titolo, testo, e tasto ok**  
  
Esempio:  
  
```python  
MessageBox("title", "message")  
```  
  
### Pause  
  
Sintassi del comando:  
  
**Void Pause(Int32)**  
  
#### Parametri  
* milliseconds: Timeout specificato in millisecondi.  
  
Descrizione:  
  
**Pausa. In millisecondi**  
  
Esempio:  
  
```python  
Pause(1000)  
```  
  
### Playing  
  
Sintassi del comando:  
  
**Boolean Playing(System.String)**  
  
#### Parametri  
* macroname: Nome Script.  
  
Descrizione:  
  
**Risulta se un altro Script è in svolgimento. Utile per non far sovrapporre Scripts negli script in background**  
  
Esempio:  
  
```python  
if Playing():  
```  
  
### Playing  
  
Sintassi del comando:  
  
**Boolean Playing()**  
  
Descrizione:  
  
**Risulta se un altro Script è in svolgimento. Utile per non far sovrapporre Scripts negli script in background**  
  
Esempio:  
  
```python  
if Playing():  
```  
  
### PlaySound  
  
Sintassi del comando:  
  
**Void PlaySound(System.Object)**  
  
Descrizione:  
  
**Riproduci un suono. In base a ID o file .wav di sistema**  
  
Esempio:  
  
```python  
PlaySound("Bike Horn.wav")  
```  
  
### Resync  
  
Sintassi del comando:  
  
**Void Resync()**  
  
Descrizione:  
  
**Risincronizza il client con il server**  
  
Esempio:  
  
```python  
Resync()  
```  
  
### SetQuietMode  
  
Sintassi del comando:  
  
**Void SetQuietMode(Boolean)**  
  
#### Parametri  
* onoff: "on" oppure "off".  
  
Descrizione:  
  
**Abilita/Disabilita la modalita Script Silenziosi (riduce la quantita di avvisi che gli script producono)**  
  
Esempio:  
  
```python  
SetQuietMode(True)  
```  
  
### SysMessage  
  
Sintassi del comando:  
  
**Void SysMessage(System.String, Int32)**  
  
#### Parametri  
* text: Valore stringa: vedere la descrizione per l'utilizzo.  
* hue: ID colore oggetto o -1 per tutti. (Opzionale)  
  
Descrizione:  
  
**Invia un messaggio come fosse di sistema**  
  
Esempio:  
  
```python  
# default hue
SysMessage("Hello")
# specifying hue
SysMessage("Hello", 35)  
```  
  
### WarMode  
  
Sintassi del comando:  
  
**Void WarMode(System.String)**  
  
#### Parametri  
* onoff: "on" oppure "off". (Opzionale)  
  
Descrizione:  
  
**War ON/OFF. Attiva/Disattiva se nessun parametro è fornito**  
  
Esempio:  
  
```python  
WarMode("on")  
```  
  



## Tipi  
### Virtues  
* None  
* Honor  
* Sacrafice  
* Valor  
* Compassion  
* Honesty  
* Humility  
* Justice  
* Spirituality  
  
