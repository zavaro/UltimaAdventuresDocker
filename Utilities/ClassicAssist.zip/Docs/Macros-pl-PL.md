# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Makra  
### PlayMacro  
  
Sygnatura metody:  
  
**Void PlayMacro(System.String)**  
  
#### Parametry  
* name: Nazwa makra.  
  
Opis:  
  
**Uruchamia podane makro.**  
  
Przykład:  
  
```python  
PlayMacro("beep")  
```  
  
### Replay  
  
Sygnatura metody:  
  
**Void Replay()**  
  
Opis:  
  
**Odgrywa ponownie obecne makro.**  
  
Przykład:  
  
```python  
Replay()  
```  
  
### Stop  
  
Sygnatura metody:  
  
**Void Stop(System.String)**  
  
#### Parametry  
* name: Zmienna typu string - zobacz opis, aby zobaczyć użycie. (Opcjonalny)  
  
Opis:  
  
**Zatrzymuje obecne makro.**  
  
Przykład:  
  
```python  
# Stop the current macro
Stop()
# Stop a macro by name
Stop("Background Macro")  
```  
  
### StopAll  
  
Sygnatura metody:  
  
**Void StopAll()**  
  
Opis:  
  
**Zatrzymuje wszystkie makra włącznie z tymi działającymi w tle.**  
  
Przykład:  
  
```python  
StopAll()  
```  
  



