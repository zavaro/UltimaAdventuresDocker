# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 타이머  
### CreateTimer  
  
메서드 시그니처:  
  
**Void CreateTimer(System.String)**  
  
#### 파라미터  
* name: 타이머 이름.  
  
설명:  
  
**타이머를 새로 만듭니다.**  
  
예시:  
  
```python  
CreateTimer("shmoo")  
```  
  
### RemoveTimer  
  
메서드 시그니처:  
  
**Void RemoveTimer(System.String)**  
  
#### 파라미터  
* name: 타이머 이름.  
  
설명:  
  
**타이머를 제거합니다.**  
  
예시:  
  
```python  
RemoveTimer("shmoo")  
```  
  
### SetTimer  
  
메서드 시그니처:  
  
**Void SetTimer(System.String, Int32)**  
  
#### 파라미터  
* name: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* milliseconds: 정수 값 - 사용 방법에 대한 설명을 보세요. (옵션)  
  
설명:  
  
**타이머 값을 설정하고 존재하지 않는 경우 생성합니다.**  
  
예시:  
  
```python  
SetTimer("shmoo", 0)  
```  
  
### Timer  
  
메서드 시그니처:  
  
**Int64 Timer(System.String)**  
  
#### 파라미터  
* name: 타이머 이름.  
  
설명:  
  
**타이머 값을 확인하십시오.**  
  
예시:  
  
```python  
if Timer("shmoo") > 10000:  
```  
  
### TimerExists  
  
메서드 시그니처:  
  
**Boolean TimerExists(System.String)**  
  
#### 파라미터  
* name: 타이머 이름.  
  
설명:  
  
**타이머가 존재하면 동작합니다.**  
  
예시:  
  
```python  
if TimerExists("shmoo"):  
```  
  
### TimerMsg  
  
메서드 시그니처:  
  
**Void TimerMsg(System.String)**  
  
#### 파라미터  
* name: 타이머 이름.  
  
설명:  
  
**경과 된 타이머 값을 시스템 메세지로 축력합니다.**  
  
예시:  
  
```python  
TimerMsg("shmoo")  
```  
  



