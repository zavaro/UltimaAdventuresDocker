# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Aliasy  
### FindAlias  
  
Sygnatura metody:  
  
**Boolean FindAlias(System.String)**  
  
#### Parametry  
* aliasname: Nazwa aliasu.  
  
Opis:  
  
**Zwraca "true" jeśli podany alias zostanie znaleziony na ekranie. Zwraca false w przypadku nie znalezienia.**  
  
Przykład:  
  
```python  
if FindAlias("mount"):  
```  
  
### GetAlias  
  
Sygnatura metody:  
  
**Int32 GetAlias(System.String)**  
  
#### Parametry  
* aliasname: Nazwa aliasu.  
  
Opis:  
  
**Zwraca wartość podanego aliasu.**  
  
Przykład:  
  
```python  
GetAlias("mount")  
```  
  
### PromptAlias  
  
Sygnatura metody:  
  
**Int32 PromptAlias(System.String)**  
  
#### Parametry  
* aliasname: Nazwa aliasu.  
  
Opis:  
  
**Wybiera za pomocą wbudowego w grę kursora szukania i przypisuje do podanego aliasu.**  
  
Przykład:  
  
```python  
PromptAlias("mount")  
```  
  
### SetAlias  
  
Sygnatura metody:  
  
**Void SetAlias(System.String, System.Object)**  
  
#### Parametry  
* aliasname: Nazwa aliasu.  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Ustawia wartość podanego aliasu.**  
  
Przykład:  
  
```python  
SetAlias("mount", 0x40000001)  
```  
  
### SetMacroAlias  
  
Sygnatura metody:  
  
**Void SetMacroAlias(System.String, System.Object)**  
  
#### Parametry  
* aliasname: Nazwa aliasu.  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Ustawia wartość podanego aliasu w obrębie skryptu.**  
  
Przykład:  
  
```python  
SetMacroAlias("mount", 0x40000001)  
```  
  
### UnsetAlias  
  
Sygnatura metody:  
  
**Void UnsetAlias(System.String)**  
  
#### Parametry  
* aliasname: Nazwa aliasu.  
  
Opis:  
  
**Usuwa podany alias.**  
  
Przykład:  
  
```python  
UnsetAlias("mount")  
```  
  



