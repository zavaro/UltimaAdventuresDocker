# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Skills  
### SetSkill  
  
Sintassi del comando:  
  
**Void SetSkill(System.String, System.String)**  
  
#### Parametri  
* skill: Nome Skill.  
* status: Lock Status - "up", "down", o "locked". Guarda anche: [LockStatus](#LockStatus)  
  
Descrizione:  
  
**Imposta lo stato di una Skill (locked, up, down)**  
  
Esempio:  
  
```python  
SetSkill("hiding", "locked")  
```  
  
### SetStatus  
  
Sintassi del comando:  
  
**Void SetStatus(System.String, System.String)**  
  
#### Parametri  
* stat: Valore stringa: vedere la descrizione per l'utilizzo. Guarda anche: [StatType](#StatType)  
* lockstatus: Lock Status - "up", "down", o "locked". Guarda anche: [LockStatus](#LockStatus)  
  
Descrizione:  
  
**Imposta lo stato di una Stat, su, giù o bloccata.**  
  
Esempio:  
  
```python  
SetStatus('str', 'locked')  
```  
  
### Skill  
  
Sintassi del comando:  
  
**Double Skill(System.String)**  
  
#### Parametri  
* name: Nome Skill.  
  
Descrizione:  
  
**Risulta il valore di una Skill**  
  
Esempio:  
  
```python  
if Skill("hiding") < 100:  
```  
  
### SkillCap  
  
Sintassi del comando:  
  
**Double SkillCap(System.String)**  
  
#### Parametri  
* name: Nome Skill.  
  
Descrizione:  
  
**Risulta lo SkillCap di una skill**  
  
Esempio:  
  
```python  
if SkillCap("Blacksmithy") == 120:  
```  
  
### SkillState  
  
Sintassi del comando:  
  
**System.String SkillState(System.String)**  
  
#### Parametri  
* name: Nome Skill.  
  
Descrizione:  
  
**Risulta lo stato di una Skill (locked, up, down)**  
  
Esempio:  
  
```python  
if SkillState("hiding') == "locked":  
```  
  
### UseSkill  
  
Sintassi del comando:  
  
**Void UseSkill(System.String)**  
  
#### Parametri  
* skill: Nome Skill.  
  
Descrizione:  
  
**Attiva una Skill**  
  
Esempio:  
  
```python  
UseSkill("Hiding")  
```  
  



## Tipi  
### LockStatus  
* Up  
* Down  
* Locked  
  
### StatType  
* Str  
* Dex  
* Int  
  
