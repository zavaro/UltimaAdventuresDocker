# ClassicAssist Macro Commands  
Generated on 12/7/2020 6:04:46 AM  
Version: 0.3.156.250  
  
## Agents  
### Counter  
  
Method Signature:  
  
**Int32 Counter(System.String)**  
  
#### Parameters  
* name: Agent entry name.  
  
Description:  
  
**Returns the count of the given counter agent.**  
  
Example:  
  
```python  
Counter("bm")  
```  
  
### Dress  
  
Method Signature:  
  
**Void Dress(System.String)**  
  
#### Parameters  
* name: Agent entry name. (Optional)  
  
Description:  
  
**Dress all items in the specified dress agent.**  
  
Example:  
  
```python  
Dress("Dress-1")  
```  
  
### DressConfig  
  
Method Signature:  
  
**Void DressConfig()**  
  
Description:  
  
**Adds all equipped items to a temporary list that isn't persisted on client close.**  
  
Example:  
  
```python  
DressConfig()  
```  
  
### Dressing  
  
Method Signature:  
  
**Boolean Dressing()**  
  
Description:  
  
**Returns true if the Dress agent is currently dressing or undressing.**  
  
Example:  
  
```python  
if Dressing():  
```  
  
### Organizer  
  
Method Signature:  
  
**Void Organizer(System.String, System.Object, System.Object)**  
  
#### Parameters  
* name: Agent entry name.  
* sourcecontainer: An entity serial in integer or hex format, or an alias string such as "self". (Optional)  
* destinationcontainer: An entity serial in integer or hex format, or an alias string such as "self". (Optional)  
  
Description:  
  
**Executes the named Organizer agent.**  
  
Example:  
  
```python  
Organizer("Organizer-1")  
```  
  
### Organizing  
  
Method Signature:  
  
**Boolean Organizing()**  
  
Description:  
  
**Returns true if currently running an organizer agent, or false if not.**  
  
Example:  
  
```python  
if Organizing():  
```  
  
### SetAutolootContainer  
  
Method Signature:  
  
**Void SetAutolootContainer(System.Object)**  
  
#### Parameters  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Description:  
  
**Sets the container for the Autoloot agent to put items into...**  
  
Example:  
  
```python  
SetAutolootContainer("backpack")  
```  
  
### SetOrganizerContainers  
  
Method Signature:  
  
**Void SetOrganizerContainers(System.String, System.Object, System.Object)**  
  
#### Parameters  
* entryname: Agent entry name.  
* sourcecontainer: An entity serial in integer or hex format, or an alias string such as "self". (Optional)  
* destinationcontainer: An entity serial in integer or hex format, or an alias string such as "self". (Optional)  
  
Description:  
  
**Set the source and destination for the specified Organizer name**  
  
Example:  
  
```python  
SetOrganizerContainers("Organizer-1", "backpack", "bank")  
```  
  
### Undress  
  
Method Signature:  
  
**Void Undress(System.String)**  
  
#### Parameters  
* name: Agent entry name.  
  
Description:  
  
**Undress all items in the specified dress agent.**  
  
Example:  
  
```python  
Undress("Dress-1")  
```  
  



