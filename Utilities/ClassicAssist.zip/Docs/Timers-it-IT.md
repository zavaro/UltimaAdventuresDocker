# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Timers  
### CreateTimer  
  
Sintassi del comando:  
  
**Void CreateTimer(System.String)**  
  
#### Parametri  
* name: Nome Timer.  
  
Descrizione:  
  
**Crea un timer**  
  
Esempio:  
  
```python  
CreateTimer("shmoo")  
```  
  
### RemoveTimer  
  
Sintassi del comando:  
  
**Void RemoveTimer(System.String)**  
  
#### Parametri  
* name: Nome Timer.  
  
Descrizione:  
  
**Rimuovi un timer**  
  
Esempio:  
  
```python  
RemoveTimer("shmoo")  
```  
  
### SetTimer  
  
Sintassi del comando:  
  
**Void SetTimer(System.String, Int32)**  
  
#### Parametri  
* name: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* milliseconds: Valore intero: vedere la descrizione per l'utilizzo. (Opzionale)  
  
Descrizione:  
  
**Imposta il valore di un timer (millisecondi)**  
  
Esempio:  
  
```python  
SetTimer("shmoo", 0)  
```  
  
### Timer  
  
Sintassi del comando:  
  
**Int64 Timer(System.String)**  
  
#### Parametri  
* name: Nome Timer.  
  
Descrizione:  
  
**Ritorna il valore di un timer (millisecondi)**  
  
Esempio:  
  
```python  
if Timer("shmoo") > 10000:  
```  
  
### TimerExists  
  
Sintassi del comando:  
  
**Boolean TimerExists(System.String)**  
  
#### Parametri  
* name: Nome Timer.  
  
Descrizione:  
  
**Ritorna se un timer esiste**  
  
Esempio:  
  
```python  
if TimerExists("shmoo"):  
```  
  
### TimerMsg  
  
Sintassi del comando:  
  
**Void TimerMsg(System.String)**  
  
#### Parametri  
* name: Nome Timer.  
  
Descrizione:  
  
**Mostra il valore di un timer come messaggio di sistema**  
  
Esempio:  
  
```python  
TimerMsg("shmoo")  
```  
  



