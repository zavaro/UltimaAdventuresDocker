# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Azioni  
### Attack  
  
Sintassi del comando:  
  
**Void Attack(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Attacca (seriale o alias)**  
  
Esempio:  
  
```python  
Attack("last")  
```  
  
### BandageSelf  
  
Sintassi del comando:  
  
**Boolean BandageSelf()**  
  
Descrizione:  
  
**Applica le bende su di se'**  
  
Esempio:  
  
```python  
BandageSelf()  
```  
  
### ClearHands  
  
Sintassi del comando:  
  
**Void ClearHands(System.String)**  
  
#### Parametri  
* hand: Equippa - "left", "right", o "both". (Opzionale)  
  
Descrizione:  
  
**Sposta nello zaino quello che si impugna (Left, Right, o Both)**  
  
Esempio:  
  
```python  
ClearHands("both")  
```  
  
### ClearUseOnce  
  
Sintassi del comando:  
  
**Void ClearUseOnce()**  
  
Descrizione:  
  
**Pulisci oggetti registrati nella lista UsaUnaVolta**  
  
Esempio:  
  
```python  
ClearUseOnce()  
```  
  
### ClickObject  
  
Sintassi del comando:  
  
**Void ClickObject(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Clicca una volta su di un oggetto (seriale o alias)**  
  
Esempio:  
  
```python  
ClickObject("last")  
```  
  
### Contents  
  
Sintassi del comando:  
  
**Int32 Contents(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se in un contenitore ci sono un Tot di oggetti (seriale o alias)**  
  
Esempio:  
  
```python  
if Contents("backpack") > 120:  
```  
  
### ContextMenu  
  
Sintassi del comando:  
  
**Void ContextMenu(System.Object, Int32)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* entry: Numero indice del menu contestuale.  
  
Descrizione:  
  
**Seleziona un opzione in un menu contestuale**  
  
Esempio:  
  
```python  
ContextMenu(0x00aabbcc, 1)  
```  
  
### EquipItem  
  
Sintassi del comando:  
  
**Void EquipItem(System.Object, System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* layer: Stringa che rappresenta un layer, tipo "OneHanded" o "Talisman" etc. Guarda anche: [Layer](#Layer)  
  
Descrizione:  
  
**Dressa un oggetto specifico in un layer specifico. Usa il comando Ispeziona Oggetto per determinare il valore del layer**  
  
Esempio:  
  
```python  
EquipItem("axe", "TwoHanded")  
```  
  
### EquipLastWeapon  
  
Sintassi del comando:  
  
**Void EquipLastWeapon()**  
  
Descrizione:  
  
**Dressa l'arma che si aveva in mano precedentemente istantaneamente (probabilmente non supportato sui server pre-Aos)**  
  
Esempio:  
  
```python  
EquipLastWeapon()  
```  
  
### EquipType  
  
Sintassi del comando:  
  
**Void EquipType(Int32, System.Object)**  
  
#### Parametri  
* id: ID oggetto o ID grafico tipo 0x3db.  
* layer: Stringa che rappresenta un layer, tipo "OneHanded" o "Talisman" etc. Guarda anche: [Layer](#Layer)  
  
Descrizione:  
  
**Dressa un Type specifico in un layer specifico. Usa il comando Ispeziona Oggetto per determinare il valore del layer**  
  
Esempio:  
  
```python  
EquipType(0xff, "TwoHanded")  
```  
  
### Feed  
  
Sintassi del comando:  
  
**Void Feed(System.Object, Int32, Int32, Int32)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* graphic: ID oggetto o ID grafico tipo 0x3db.  
* amount: Numero intero che rappresenta un importo, ovvero 10. (Opzionale)  
* hue: ID colore oggetto o -1 per tutti. (Opzionale)  
  
Descrizione:  
  
**Nutri (seriale o alias)**  
  
Esempio:  
  
```python  
Feed("mount", 0xff)  
```  
  
### FindLayer  
  
Sintassi del comando:  
  
**Boolean FindLayer(System.Object, System.Object)**  
  
#### Parametri  
* layer: Stringa che rappresenta un layer, tipo "OneHanded" o "Talisman" etc. Guarda anche: [Layer](#Layer)  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Risulta e aggiorna l'alias trovato se esiste un elemento nel layer specificato, opzione seriale / alias per il controllo da mobile.**  
  
Esempio:  
  
```python  
if FindLayer("OneHanded"):  
```  
  
### InRegion  
  
Sintassi del comando:  
  
**Boolean InRegion(System.String, System.Object)**  
  
#### Parametri  
* attribute: Valore stringa: vedere la descrizione per l'utilizzo. Guarda anche: [RegionAttributes](#RegionAttributes)  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Risulta se la zona del oggetto/mobile è in quella richiesta**  
  
Esempio:  
  
```python  
if InRegion("Guarded", "self")  
```  
  
### Ping  
  
Sintassi del comando:  
  
**Int64 Ping()**  
  
Descrizione:  
  
**Ping approssimato con il server. -1 in caso di fallimento.**  
  
Esempio:  
  
```python  
Ping()  
```  
  
### Rename  
  
Sintassi del comando:  
  
**Void Rename(System.Object, System.String)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* name: Stringa che rappresenta un nome. Tipo "Snoopy".  
  
Descrizione:  
  
**Rinomina un alias rinominabile (tipo, un pet)**  
  
Esempio:  
  
```python  
Rename("mount", "Snoopy")  
```  
  
### ShowNames  
  
Sintassi del comando:  
  
**Void ShowNames(System.String)**  
  
#### Parametri  
* showtype: Mostra type - "mobiles" o "corpses". Guarda anche: [ShowNamesType](#ShowNamesType)  
  
Descrizione:  
  
**Visualizza i nomi dei cadaveri e/o degli elementi mobili (mobiles, corpses)**  
  
Esempio:  
  
```python  
ShowNames("corpses")  
```  
  
### ToggleMounted  
  
Sintassi del comando:  
  
**Void ToggleMounted()**  
  
Descrizione:  
  
**Smonta se montato, o monta se smontato. Richiede di impostare la mount se non è gia presente un alias chiamato "mount"**  
  
Esempio:  
  
```python  
ToggleMounted()  
```  
  
### UseObject  
  
Sintassi del comando:  
  
**Void UseObject(System.Object, Boolean)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* skipqueue: Non specificato: vedere la descrizione per l'utilizzo. (Opzionale)  
  
Descrizione:  
  
**Utilizza un oggetto (seriale o alias)**  
  
Esempio:  
  
```python  
UseObject("mount")  
```  
  
### UseOnce  
  
Sintassi del comando:  
  
**Boolean UseOnce(Int32, Int32)**  
  
#### Parametri  
* graphic: ID oggetto o ID grafico tipo 0x3db.  
* hue: ID colore oggetto o -1 per tutti. (Opzionale)  
  
Descrizione:  
  
**Usa una singola volta un tipo specifico di oggetti (seriale grafico) dallo zaino**  
  
Esempio:  
  
```python  
UseOnce(0xff)  
```  
  
### UseTargetedItem  
  
Sintassi del comando:  
  
**Void UseTargetedItem(System.Object, System.Object)**  
  
#### Parametri  
* item: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* target: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Usa un oggetto specifico e Targetta un target, tutto insieme. Richiede che sia supportato dal server (OSI / ServUO)**  
  
Esempio:  
  
```python  
UseTargetedItem('bandage', 'pet')  
```  
  
### UseType  
  
Sintassi del comando:  
  
**Void UseType(System.Object, Int32, System.Object)**  
  
#### Parametri  
* type: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* hue: ID colore oggetto o -1 per tutti. (Opzionale)  
* container: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Usa un tipo specifico di oggetti (seriale grafico), parametri opzionali come contenitore e / o colore si possono scegliere (predefinito: zaino) (parametri possono essere seriali o alias).**  
  
Esempio:  
  
```python  
UseType(0xff)  
```  
  
### WaitForContents  
  
Sintassi del comando:  
  
**Boolean WaitForContents(System.Object, Int32)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* timeout: Timeout specificato in millisecondi. (Opzionale)  
  
Descrizione:  
  
**Attendere che il contenuto del contenitore per un determinato contenitore sia caricato correttamente**  
  
Esempio:  
  
```python  
WaitForContents("backpack", 5000)  
```  
  
### WaitForContext  
  
Sintassi del comando:  
  
**Boolean WaitForContext(System.Object, Int32, Int32)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* entry: Numero indice del menu contestuale.  
* timeout: Timeout specificato in millisecondi.  
  
Descrizione:  
  
**Attendere che il contenuto del del menu contestuale sia caricato correttamente**  
  
Esempio:  
  
```python  
WaitForContext(0x00aabbcc, 1, 5000)  
```  
  



## Tipi  
### Layer  
* Invalid  
* OneHanded  
* TwoHanded  
* Shoes  
* Pants  
* Shirt  
* Helm  
* Gloves  
* Ring  
* Talisman  
* Neck  
* Hair  
* Waist  
* InnerTorso  
* Bracelet  
* Unused_xF  
* FacialHair  
* MiddleTorso  
* Earrings  
* Arms  
* Cloak  
* Backpack  
* OuterTorso  
* OuterLegs  
* InnerLegs  
* Mount  
* ShopBuy  
* ShopResale  
* ShopSell  
* Bank  
* LastValid  
  
### RegionAttributes  
* None  
* Guarded  
* Jail  
* Wilderness  
* Town  
* Dungeon  
* Special  
* Default  
  
### ShowNamesType  
* Mobiles  
* Corpses  
  
