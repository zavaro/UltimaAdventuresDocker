# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Scripts  
### PlayMacro  
  
Sintassi del comando:  
  
**Void PlayMacro(System.String)**  
  
#### Parametri  
* name: Nome Script.  
  
Descrizione:  
  
**Avvia lo Script desiderato**  
  
Esempio:  
  
```python  
PlayMacro("beep")  
```  
  
### Replay  
  
Sintassi del comando:  
  
**Void Replay()**  
  
Descrizione:  
  
**Ripeti lo Script corrente**  
  
Esempio:  
  
```python  
Replay()  
```  
  
### Stop  
  
Sintassi del comando:  
  
**Void Stop(System.String)**  
  
#### Parametri  
* name: Valore stringa: vedere la descrizione per l'utilizzo. (Opzionale)  
  
Descrizione:  
  
**Ferma lo Script corrente**  
  
Esempio:  
  
```python  
# Stop the current macro
Stop()
# Stop a macro by name
Stop("Background Macro")  
```  
  
### StopAll  
  
Sintassi del comando:  
  
**Void StopAll()**  
  
Descrizione:  
  
**Ferma tutti gli scripts, compresi quelli in background**  
  
Esempio:  
  
```python  
StopAll()  
```  
  



