# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Dziennik  
### ClearJournal  
  
Sygnatura metody:  
  
**Void ClearJournal()**  
  
Opis:  
  
**Wyczyść dziennik. (Nie powoduje wyczyszczenia dziennika widocznego w grze, ale jego kopię w Classic Assist).**  
  
Przykład:  
  
```python  
ClearJournal()  
```  
  
### InJournal  
  
Sygnatura metody:  
  
**Boolean InJournal(System.String, System.String, Int32)**  
  
Opis:  
  
**Sprawdź czy podany tekst występuje w dzienniku. Opcjonalnie można podać źródło wpisu do dziennika.**  
  
Przykład:  
  
```python  
if InJournal("town guards", "system"):  
```  
  
### WaitForJournal  
  
Sygnatura metody:  
  
**Boolean WaitForJournal(System.String, Int32, System.String)**  
  
Opis:  
  
**Czeka określoną ilość czasu aż pojawi się szukany tekst w dzienniku.**  
  
Przykład:  
  
```python  
if WaitForJournal("town guards", 5000, "system"):  
```  
  



