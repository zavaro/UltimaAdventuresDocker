# ClassicAssist Macro Commands  
Generated on 12/7/2020 6:04:46 AM  
Version: 0.3.156.250  
  
## Macros  
### PlayMacro  
  
Method Signature:  
  
**Void PlayMacro(System.String)**  
  
#### Parameters  
* name: Macro name.  
  
Description:  
  
**Plays the given macro name.**  
  
Example:  
  
```python  
PlayMacro("beep")  
```  
  
### Replay  
  
Method Signature:  
  
**Void Replay()**  
  
Description:  
  
**Replay the current macro**  
  
Example:  
  
```python  
Replay()  
```  
  
### Stop  
  
Method Signature:  
  
**Void Stop(System.String)**  
  
#### Parameters  
* name: String value - See description for usage. (Optional)  
  
Description:  
  
**Stops the current macro.**  
  
Example:  
  
```python  
# Stop the current macro
Stop()
# Stop a macro by name
Stop("Background Macro")  
```  
  
### StopAll  
  
Method Signature:  
  
**Void StopAll()**  
  
Description:  
  
**Stops all running macros including background macros.**  
  
Example:  
  
```python  
StopAll()  
```  
  



