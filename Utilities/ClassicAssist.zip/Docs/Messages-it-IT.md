# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Messaggi  
### AllyMsg  
  
Sintassi del comando:  
  
**Void AllyMsg(System.String)**  
  
#### Parametri  
* message: Valore stringa: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Invia un messaggio nella Chat Ally**  
  
Esempio:  
  
```python  
AllyMsg("alert")  
```  
  
### CancelPrompt  
  
Sintassi del comando:  
  
**Void CancelPrompt()**  
  
Descrizione:  
  
**Cancella un prompt aperto di sistema**  
  
Esempio:  
  
```python  
CancelPrompt()  
```  
  
### ChatMsg  
  
Sintassi del comando:  
  
**Void ChatMsg(System.String)**  
  
#### Parametri  
* message: Valore stringa: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Invia un messaggio in chat.**  
  
Esempio:  
  
```python  
ChatMsg("Mary ha una pecorella")  
```  
  
### EmoteMsg  
  
Sintassi del comando:  
  
**Void EmoteMsg(System.String)**  
  
#### Parametri  
* message: Valore stringa: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Invia un messaggio Emote**  
  
Esempio:  
  
```python  
EmoteMsg("hi")  
```  
  
### GetText  
  
Sintassi del comando:  
  
**System.ValueTuple`2[System.Boolean,System.String] GetText(System.String, Int32)**  
  
#### Parametri  
* prompt: Valore stringa: vedere la descrizione per l'utilizzo.  
* timeout: Timeout specificato in millisecondi. (Opzionale)  
  
Descrizione:  
  
**Sends an internal prompt request and returns the text entered**  
  
Esempio:  
  
```python  
res, name = GetText("Name?", 10000)

if res:
 Rename(0xc1b, name)  
```  
  
### GuildMsg  
  
Sintassi del comando:  
  
**Void GuildMsg(System.String)**  
  
#### Parametri  
* message: Valore stringa: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Invia un messaggio nella Chat Guild**  
  
Esempio:  
  
```python  
GuildMsg("alert")  
```  
  
### HeadMsg  
  
Sintassi del comando:  
  
**Void HeadMsg(System.String, System.Object, Int32)**  
  
#### Parametri  
* message: Valore stringa: vedere la descrizione per l'utilizzo.  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
* hue: ID colore oggetto o -1 per tutti. (Opzionale)  
  
Descrizione:  
  
**Fai apparire del testo sopra un mobile / alias / seriale (gli altri player non lo vedranno)**  
  
Esempio:  
  
```python  
HeadMsg("hi", "backpack")  
```  
  
### Msg  
  
Sintassi del comando:  
  
**Void Msg(System.String, Int32)**  
  
#### Parametri  
* message: Valore stringa: vedere la descrizione per l'utilizzo.  
* hue: ID colore oggetto o -1 per tutti. (Opzionale)  
  
Descrizione:  
  
**Scrivi in game**  
  
Esempio:  
  
```python  
Msg("hi")  
```  
  
### PartyMsg  
  
Sintassi del comando:  
  
**Void PartyMsg(System.String)**  
  
#### Parametri  
* message: Valore stringa: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Invia un messaggio nella Chat Party**  
  
Esempio:  
  
```python  
PartyMsg("alert")  
```  
  
### PromptMsg  
  
Sintassi del comando:  
  
**Void PromptMsg(System.String)**  
  
#### Parametri  
* message: Valore stringa: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Rispondi automaticamente alle domande di sistema (per esempio: "Enter a new rune name..")**  
  
Esempio:  
  
```python  
PromptMsg("hello")  
```  
  
### WaitForPrompt  
  
Sintassi del comando:  
  
**Boolean WaitForPrompt(Int32)**  
  
#### Parametri  
* timeout: Timeout specificato in millisecondi.  
  
Descrizione:  
  
**Attendi che una domanda di sistema venga posta**  
  
Esempio:  
  
```python  
WaitForPrompt(5000)  
```  
  
### WhisperMsg  
  
Sintassi del comando:  
  
**Void WhisperMsg(System.String)**  
  
#### Parametri  
* message: Valore stringa: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Invia un messaggio Whisper**  
  
Esempio:  
  
```python  
WhisperMsg("hi")  
```  
  
### YellMsg  
  
Sintassi del comando:  
  
**Void YellMsg(System.String)**  
  
#### Parametri  
* message: Valore stringa: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Invia un messaggio Yell**  
  
Esempio:  
  
```python  
YellMsg("hi")  
```  
  



