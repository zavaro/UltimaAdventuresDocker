# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 주문  
### Cast  
  
메서드 시그니처:  
  
**Void Cast(System.String)**  
  
#### 파라미터  
* name: 스펠 이름.  
  
설명:  
  
**주문을 대상에게 자동으로 시전합니다.**  
  
예시:  
  
```python  
Cast("Recall", "runebook")  
```  
  
### Cast  
  
메서드 시그니처:  
  
**Boolean Cast(System.String, System.Object)**  
  
#### 파라미터  
* name: 스펠 이름.  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**주문을 대상에게 자동으로 시전합니다.**  
  
예시:  
  
```python  
Cast("Recall", "runebook")  
```  
  
### InterruptSpell  
  
메서드 시그니처:  
  
**Void InterruptSpell()**  
  
설명:  
  
**Attempts to interrupt spell by lifting an item briefly.**  
  
예시:  
  
```python  
InterruptSpell()  
```  
  



