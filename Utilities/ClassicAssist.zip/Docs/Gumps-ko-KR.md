# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 검프  
### CloseGump  
  
메서드 시그니처:  
  
**Void CloseGump(Int32)**  
  
#### 파라미터  
* serial: 시리얼 예시) 0xf00ff00f .  
  
설명:  
  
**지정된 검프 시리얼 닫습니다.**  
  
예시:  
  
```python  
CloseGump(0x454ddef)  
```  
  
### ConfirmPrompt  
  
메서드 시그니처:  
  
**Boolean ConfirmPrompt(System.String, Boolean)**  
  
설명:  
  
**메시지와 함께 게임 내 프롬프트를 표시하고, Okay를 누르면 True로, 그렇지 않으면 False로 동작합니다.**  
  
예시:  
  
```python  
res = ConfirmPrompt("Play macro?")

if res:
 PlayMacro("Macro")  
```  
  
### GumpExists  
  
메서드 시그니처:  
  
**Boolean GumpExists(UInt32)**  
  
설명:  
  
**검프 ID가 있는지 확인합니다.**  
  
예시:  
  
```python  
if GumpExists(0xff):  
```  
  
### InGump  
  
메서드 시그니처:  
  
**Boolean InGump(UInt32, System.String)**  
  
#### 파라미터  
* gumpid: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* text: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**검프 텍스트를 확인합니다.**  
  
예시:  
  
```python  
if InGump(0xf00f, "lethal darts"):  
```  
  
### MessagePrompt  
  
메서드 시그니처:  
  
**System.ValueTuple`2[System.Boolean,System.String] MessagePrompt(System.String, System.String, Boolean)**  
  
#### 파라미터  
* message: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
* initialtext: 문자열 값 - 사용 방법에 대한 설명을 보세요. (옵션)  
* closable: Ture/False 값, 사용 방법에 대한 설명을 보세요. (옵션)  
  
설명:  
  
**Displays an ingame gump prompting for a message**  
  
예시:  
  
```python  
res, name = MessagePrompt("Enter Name?", "Whiskers")

if res:
 Rename(0xc1b, name)  
```  
  
### OpenGuildGump  
  
메서드 시그니처:  
  
**Void OpenGuildGump()**  
  
설명:  
  
**길드 검프를 엽니다**  
  
예시:  
  
```python  
OpenGuildGump()  
```  
  
### OpenQuestsGump  
  
메서드 시그니처:  
  
**Void OpenQuestsGump()**  
  
설명:  
  
**퀘스트 검프를 엽니다**  
  
예시:  
  
```python  
OpenQuestsGump()  
```  
  
### OpenVirtueGump  
  
메서드 시그니처:  
  
**Void OpenVirtueGump(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**시리얼 / 이름의 미덕 검프를 엽니다. (기본값은 현재 플레이어)**  
  
예시:  
  
```python  
OpenVirtueGump("enemy")  
```  
  
### ReplyGump  
  
메서드 시그니처:  
  
**Void ReplyGump(UInt32, Int32, Int32[])**  
  
#### 파라미터  
* gumpid: 아이템ID/그래픽 예시) 0x3db .  
* buttonid: 검프버튼 ID.  
* switches: 정수 값 - 사용 방법에 대한 설명을 보세요. (옵션)  
  
설명:  
  
**서버 검프에에 버튼 응답을 보냅니다. 매개 변수는 검프ID 및 버튼ID입니다.**  
  
예시:  
  
```python  
ReplyGump(0xff, 0)  
```  
  
### WaitForGump  
  
메서드 시그니처:  
  
**Boolean WaitForGump(UInt32, Int32)**  
  
#### 파라미터  
* gumpid: 아이템ID/그래픽 예시) 0x3db . (옵션)  
* timeout: milliseconds 지정된 시간초과됨. (옵션)  
  
설명:  
  
**검프 패킷이 수신 될 때까지 일시 정지 됩니다.**  
  
예시:  
  
```python  
WaitForGump(0xff, 5000)  
```  
  



