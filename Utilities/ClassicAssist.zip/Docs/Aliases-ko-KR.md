# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 별명  
### FindAlias  
  
메서드 시그니처:  
  
**Boolean FindAlias(System.String)**  
  
#### 파라미터  
* aliasname: 이름.  
  
설명:  
  
**지정된 시리얼을 찾는 것에 상관 없이 작동합니다.**  
  
예시:  
  
```python  
if FindAlias("mount"):  
```  
  
### GetAlias  
  
메서드 시그니처:  
  
**Int32 GetAlias(System.String)**  
  
#### 파라미터  
* aliasname: 이름.  
  
설명:  
  
**설정된 이름을 가져옵니다.**  
  
예시:  
  
```python  
GetAlias("mount")  
```  
  
### PromptAlias  
  
메서드 시그니처:  
  
**Int32 PromptAlias(System.String)**  
  
#### 파라미터  
* aliasname: 이름.  
  
설명:  
  
**대상을 커서로 선택하여 이름을 정하세요.**  
  
예시:  
  
```python  
PromptAlias("mount")  
```  
  
### SetAlias  
  
메서드 시그니처:  
  
**Void SetAlias(System.String, System.Object)**  
  
#### 파라미터  
* aliasname: 이름.  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**이름을 설정합니다.**  
  
예시:  
  
```python  
SetAlias("mount", 0x40000001)  
```  
  
### SetMacroAlias  
  
메서드 시그니처:  
  
**Void SetMacroAlias(System.String, System.Object)**  
  
#### 파라미터  
* aliasname: 이름.  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**이름을 설정합니다. 설정된 이름은 현재 매크로에서만 유효합니다.**  
  
예시:  
  
```python  
SetMacroAlias("mount", 0x40000001)  
```  
  
### UnsetAlias  
  
메서드 시그니처:  
  
**Void UnsetAlias(System.String)**  
  
#### 파라미터  
* aliasname: 이름.  
  
설명:  
  
**설정된 이름을 제거합니다.**  
  
예시:  
  
```python  
UnsetAlias("mount")  
```  
  



