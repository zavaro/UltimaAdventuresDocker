# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 목록  
### ClearList  
  
메서드 시그니처:  
  
**Void ClearList(System.String)**  
  
#### 파라미터  
* listname: 리스트 이름.  
  
설명:  
  
**목록에서 이름을 삭제합니다.**  
  
예시:  
  
```python  
ClearList("list")  
```  
  
### CreateList  
  
메서드 시그니처:  
  
**Void CreateList(System.String)**  
  
#### 파라미터  
* listname: 리스트 이름.  
  
설명:  
  
**이름으로 목록을 만듭니다. 목록이 이미 있으면 겹쳐 씁니다.**  
  
예시:  
  
```python  
CreateList("list")  
```  
  
### GetList  
  
메서드 시그니처:  
  
**Int32[] GetList(System.String)**  
  
#### 파라미터  
* listname: 리스트 이름.  
  
설명:  
  
**루프 등과 함께 사용하기 위해 목록에있는 모든 항목의 배열을 표시합니다.**  
  
예시:  
  
```python  
GetList("list")  
```  
  
### InList  
  
메서드 시그니처:  
  
**Boolean InList(System.String, Int32)**  
  
#### 파라미터  
* listname: 리스트 이름.  
* value: 정수 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**주어진 요소가 목록에 포함되어 있는지 확인합니다.**  
  
예시:  
  
```python  
if InList("shmoo", 1):  
```  
  
### List  
  
메서드 시그니처:  
  
**Int32 List(System.String)**  
  
#### 파라미터  
* listname: 리스트 이름.  
  
설명:  
  
**리스트 내의 엔트리 수를 보여줍니다.**  
  
예시:  
  
```python  
if List("list") < 5:  
```  
  
### ListExists  
  
메서드 시그니처:  
  
**Boolean ListExists(System.String)**  
  
#### 파라미터  
* listname: 리스트 이름.  
  
설명:  
  
**리스트가 존재하면 true, 그렇지 않으면 false.**  
  
예시:  
  
```python  
if ListExists("list"):  
```  
  
### PopList  
  
메서드 시그니처:  
  
**Int32 PopList(System.String, System.String)**  
  
#### 파라미터  
* listname: 리스트 이름.  
* elementvalue: Element value to remove from list, or 'front' to remove the first item, or 'back' to remove last entry, default 'back'. (옵션)  
  
설명:  
  
**Remove elements from a list, returns the number of elements removed**  
  
예시:  
  
```python  
CreateList("hippies")
PushList("hippies", 1)
PushList("hippies", 2)
PushList("hippies", 3)

PopList("hippies", "front") # Removes 1
PopList("hippies", "back") # Removes 3
PopList("hippies", "2") # Removes any 2's that exist in the list


for x in GetList("hippies"):
 print x # Never reached because list is empty
  
```  
  
### PushList  
  
메서드 시그니처:  
  
**Void PushList(System.String, Int32)**  
  
#### 파라미터  
* listname: 리스트 이름.  
* value: 정수 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**목록의 끝을 보여주고, 목록이 없으면 목록을 만듭니다.**  
  
예시:  
  
```python  
PushList("list", 1)  
```  
  
### RemoveList  
  
메서드 시그니처:  
  
**Void RemoveList(System.String)**  
  
#### 파라미터  
* listname: 리스트 이름.  
  
설명:  
  
**주어진 이름의 목록을 제거합니다.**  
  
예시:  
  
```python  
RemoveList("list")  
```  
  



