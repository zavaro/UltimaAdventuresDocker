# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Entity  
### AddFriend  
  
Sygnatura metody:  
  
**Int32 AddFriend(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Dodaje mobile do listy przyjaciół, jeśli nie jest podany serial/alias zostanie wywołany wbudowany w grę kursor szukania celem ustawienia.**  
  
Przykład:  
  
```python  
AddFriend()  
```  
  
### Ally  
  
Sygnatura metody:  
  
**Boolean Ally(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca "true" jeśli dany mobile jest sprzymierzeńcem.**  
  
Przykład:  
  
```python  
if Criminal("mount"):  
```  
  
### AutoColorPick  
  
Sygnatura metody:  
  
**Void AutoColorPick(Int32)**  
  
#### Parametry  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek).  
  
Opis:  
  
**Setup an automated reply to the incoming dye color gump, allowing you to define dye tubs color.
That command should be added prior to the action that opens the color pick gump.**  
  
Przykład:  
  
```python  
AutoColorPick(666)
UseObject('dyes')
WaitForTarget(1000)
Target('tub')  
```  
  
### BuffExists  
  
Sygnatura metody:  
  
**Boolean BuffExists(System.String)**  
  
#### Parametry  
* name: Nazwa buffu.  
  
Opis:  
  
**Sprawdza specyficzny buff.**  
  
Przykład:  
  
```python  
if BuffExists("Blood Oath"):  
```  
  
### BuffTime  
  
Sygnatura metody:  
  
**Double BuffTime(System.String)**  
  
#### Parametry  
* name: Nazwa buffu.  
  
Opis:  
  
**Zwraca ilość czasu pozostałego dla  podaneg buffa, lub 0 jeśli już się skończył lub nie był aktywny.**  
  
Przykład:  
  
```python  
if not BuffExists('Enemy Of One') or BuffTime('Enemy Of One') < 5000:
    Cast('Enemy Of One')
  
```  
  
### ClearIgnoreList  
  
Sygnatura metody:  
  
**Void ClearIgnoreList()**  
  
Opis:  
  
**Czyści listę ignorowanych.**  
  
Przykład:  
  
```python  
ClearIgnoreList()  
```  
  
### CountType  
  
Sygnatura metody:  
  
**Int32 CountType(Int32, System.Object, Int32)**  
  
#### Parametry  
* graphic: ItemId/Grafika np. 0x3db.  
* source: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek). (Opcjonalny)  
  
Opis:  
  
**Zlicza podany typ przedmiotów wewnątrz kontenera.**  
  
Przykład:  
  
```python  
CountType(0xff, "backpack")  
```  
  
### CountTypeGround  
  
Sygnatura metody:  
  
**Int32 CountTypeGround(Int32, Int32, Int32)**  
  
#### Parametry  
* graphic: ItemId/Grafika np. 0x3db.  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek). (Opcjonalny)  
* range: Odległość, np. 10. (Opcjonalny)  
  
Opis:  
  
**Zlicza i porównuje przedmioty lub obiekty mobile na ziemi.**  
  
Przykład:  
  
```python  
if CountGround(0xff, 0, 10) < 1:  
```  
  
### Criminal  
  
Sygnatura metody:  
  
**Boolean Criminal(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca "true" jeśli obiekt mobile jest kryminalistą.**  
  
Przykład:  
  
```python  
if Criminal("mount"):  
```  
  
### Dead  
  
Sygnatura metody:  
  
**Boolean Dead(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Zwraca "true" jeśli obiekt mobole jest martwy. Jeżeli parametr jest pusty (null), zwraca watość dla gracza (parametrem może być serialem albo aliasem).**  
  
Przykład:  
  
```python  
if Dead("self"):  
```  
  
### Dex  
  
Sygnatura metody:  
  
**Int32 Dex()**  
  
Opis:  
  
**Zwraca wartość zręcznści gracza.**  
  
Przykład:  
  
```python  
if Str() < 100:  
```  
  
### DiffHits  
  
Sygnatura metody:  
  
**Int32 DiffHits(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Zwraca wartość różnicy pomiędzy pełnym zdrowiem a obecnym dla podanego obiektu mobile. W przypadku braku parametru zwraca obecną wartość dla gracza (parametrem może być serial lub alias).**  
  
Przykład:  
  
```python  
if DiffHits("self") > 50:  
```  
  
### DiffWeight  
  
Sygnatura metody:  
  
**Int32 DiffWeight()**  
  
Opis:  
  
**Zwraca różnicę pomiędzy maksymalnym udźwigiem a obecnym obciązeniem gracza.**  
  
Przykład:  
  
```python  
if DiffWeight() > 50:  
```  
  
### Direction  
  
Sygnatura metody:  
  
**System.String Direction(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Returns the Direction the given alias/serial is facing**  
  
Przykład:  
  
```python  
if Direction('enemy') == 'West':  
```  
  
### DirectionTo  
  
Sygnatura metody:  
  
**System.String DirectionTo(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca obecny kierunek obiektu względem gracza.**  
  
Przykład:  
  
```python  
Run(DirectionTo("enemy"))  
```  
  
### Distance  
  
Sygnatura metody:  
  
**Int32 Distance(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Zwraca odległość od danego obiektu.**  
  
Przykład:  
  
```python  
if Distance("mount") < 4:  
```  
  
### Enemy  
  
Sygnatura metody:  
  
**Boolean Enemy(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca "true" jeśli obiekt mobile jest wrogiem.**  
  
Przykład:  
  
```python  
if Criminal("mount"):  
```  
  
### EquipWand  
  
Sygnatura metody:  
  
**Boolean EquipWand(System.String, Int32)**  
  
#### Parametry  
* wandname: Nazwa różdżki. Zobacz też: [WandTypes](#WandTypes)  
* minimumcharges: Zmianna typu integer - zobacz opis, aby zobaczyć użycie. (Opcjonalny)  
  
Opis:  
  
**Szuka podanej różdżki wewnątrz plecaka gracza i bierze ją do ręki.**  
  
Przykład:  
  
```python  
#Equip a fireball wand if one can be found in our backpack..
if FindWand("fireball", "backpack", 5):
 #Remove current item in hand
 if FindLayer("OneHanded"):
  ClearHands("left")
 #Equip the wand
 EquipWand("fireball")  
```  
  
### FindObject  
  
Sygnatura metody:  
  
**Boolean FindObject(System.Object, Int32, System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* range: Odległość, np. 10. (Opcjonalny)  
* findlocation: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Szuka obiektu po serialu a następnie ustawia aliast "found". Domyślnie wybrana ziemia jeśli ne podano źódła.**  
  
Przykład:  
  
```python  
# Find on ground
FindObject("mount")

# Find on ground with range
FindObject("mount", 10)

# Find in container, must specify search level or -1
FindObject("weapon", -1, "backpack")    
```  
  
### FindType  
  
Sygnatura metody:  
  
**Boolean FindType(Int32, Int32, System.Object, Int32, Int32)**  
  
#### Parametry  
* graphic: ItemId/Grafika np. 0x3db.  
* range: Odległość, np. 10. (Opcjonalny)  
* findlocation: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek). (Opcjonalny)  
* minimumstackamount: Zmienna integer reprezentująca liczbę, np. 10. (Opcjonalny)  
  
Opis:  
  
**Szuka obiektu po ID grafiki i ustawia alias "found". Domyślnie wybrana ziemia jeśli nie podano źródła.**  
  
Przykład:  
  
```python  
# Look for a food item from a list and eat 1 if found.
if not ListExists("food"): 
 CreateList("food") 
 PushList("food", 0x9b7) #bird 
 PushList("food", 0x9d3) #ham 
 PushList("food", 0x97d) #cheese 
 PushList("food", 0x9d0) #apple 
 PushList("food", 0x9eb) #muffin 
 PushList("food", 0x97b) #fishsteak 
 PushList("food", 0x9c0) #sausage 
 PushList("food", 0x9f2) #ribs 
 PushList("food", 0x9d1) #grapes 
 PushList("food", 0x9d2) #peach 

for i in GetList("food"): 
 if FindType(i, -1, "backpack"): 
  UseObject("found") 
  break  
```  
  
### FindWand  
  
Sygnatura metody:  
  
**Boolean FindWand(System.String, System.Object, Int32)**  
  
#### Parametry  
* wandname: Nazwa różdżki. Zobacz też: [WandTypes](#WandTypes)  
* containersource: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
* minimumcharges: Zmianna typu integer - zobacz opis, aby zobaczyć użycie. (Opcjonalny)  
  
Opis:  
  
**Szuka różdżki po czym ustawia alias "found".**  
  
Przykład:  
  
```python  
FindWand("fireball", "backpack", 10)  
```  
  
### Followers  
  
Sygnatura metody:  
  
**Int32 Followers()**  
  
Opis:  
  
**Zwraca liczbę podązających zwerząt zgodnie z oknem statusu postaci.**  
  
Przykład:  
  
```python  
if Followers() < 1:  
```  
  
### Gold  
  
Sygnatura metody:  
  
**Int32 Gold()**  
  
Opis:  
  
**Zwraca liczbę złota zgodnie z oknej statusu postaci.**  
  
Przykład:  
  
```python  
if Gold() < 2000:  
```  
  
### Graphic  
  
Sygnatura metody:  
  
**Int32 Graphic(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Zwraca ID przedmiotu (parametrem może być serial albo alias).**  
  
Przykład:  
  
```python  
Graphic("mount")  
```  
  
### Gray  
  
Sygnatura metody:  
  
**Boolean Gray(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca "true" jeśli obiekt mobile jest możliwy do zaatakowania.**  
  
Przykład:  
  
```python  
if Criminal("mount"):  
```  
  
### Hidden  
  
Sygnatura metody:  
  
**Boolean Hidden(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Zwraca "true" jeśli obiekt mobile jest ukryty, "false" w odwrotnym wypadku. Jeżeli parametr jest pusty, wtedy zwracana jest wartość dla gracza (parametrem może być serial albo alias).**  
  
Przykład:  
  
```python  
if Hidden("self"):  
```  
  
### Hits  
  
Sygnatura metody:  
  
**Int32 Hits(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Zwraca podane punkty życia dla obiektu mobile. Jeżeli parametr jest pusty, wtedy zwracana jest wartość dla gracza (parametrem może być serial albo alias).**  
  
Przykład:  
  
```python  
hits = Hits("self")  
```  
  
### Hue  
  
Sygnatura metody:  
  
**Int32 Hue(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Zwraca kolor dla podanego obiektu (parametrem może być serial albo alias).**  
  
Przykład:  
  
```python  
if Hue("mount") == 0:  
```  
  
### IgnoreObject  
  
Sygnatura metody:  
  
**Void IgnoreObject(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Ignoruje wskazany biekt z komend szukania.**  
  
Przykład:  
  
```python  
IgnoreObject("self")  
```  
  
### InFriendList  
  
Sygnatura metody:  
  
**Boolean InFriendList(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca "true" jesli obiekt mobile istnieje na liście przyjaciół.**  
  
Przykład:  
  
```python  
if InFriendList("last"):  
```  
  
### InIgnoreList  
  
Sygnatura metody:  
  
**Boolean InIgnoreList(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Sprawdza czy podany serial lub alias istnieje w liście ignorowanych.**  
  
Przykład:  
  
```python  
if InIgnoreList("mount"):  
```  
  
### Innocent  
  
Sygnatura metody:  
  
**Boolean Innocent(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca "true" jeśli obiekt mobile jest niewinny.**  
  
Przykład:  
  
```python  
if Criminal("mount"):  
```  
  
### InParty  
  
Sygnatura metody:  
  
**Boolean InParty(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca "true" jeśli obiekt mobile jest z Tobą w drużynie (parametrem może być serial albo alias).**  
  
Przykład:  
  
```python  
if InParty("friend"):  
```  
  
### InRange  
  
Sygnatura metody:  
  
**Boolean InRange(System.Object, Int32)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* distance: Dystans.  
  
Opis:  
  
**Sprawdza odległość pomiędzy Twoją postacią a innym obiektem mobile lub przedmiotem.**  
  
Przykład:  
  
```python  
if InRange("enemy", 10):  
```  
  
### Int  
  
Sygnatura metody:  
  
**Int32 Int()**  
  
Opis:  
  
**Zwraca liczbę inteligencji gracza.**  
  
Przykład:  
  
```python  
if Str() < 100:  
```  
  
### Invulnerable  
  
Sygnatura metody:  
  
**Boolean Invulnerable(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca "true" jeśli obiekt mobile jest niezniszczalny/nietykalny.**  
  
Przykład:  
  
```python  
if Criminal("mount"):  
```  
  
### Luck  
  
Sygnatura metody:  
  
**Int32 Luck()**  
  
Opis:  
  
**Zwraca liczbę punktów szczęscia zgodnie z oknem statusu gracza.**  
  
Przykład:  
  
```python  
if Luck() < 800:  
```  
  
### Mana  
  
Sygnatura metody:  
  
**Int32 Mana(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
** Zwraca liczbę punktów many wybranego obiektu mobile. Jesli paramter jest pusty, zwraca liczbę punktów many gracza (parametrem może być serial albo alias).**  
  
Przykład:  
  
```python  
if Mana("self") < 25:  
```  
  
### MaxFollowers  
  
Sygnatura metody:  
  
**Int32 MaxFollowers()**  
  
Opis:  
  
**Zwraca liczbę maksylanych podązających zwierząt zgodnie z oknem statusu gracza.**  
  
Przykład:  
  
```python  
if Followers() == MaxFollowers():  
```  
  
### MaxHits  
  
Sygnatura metody:  
  
**Int32 MaxHits(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
** Zwraca liczbę punktów życia wybranego obiektu mobile. Jesli paramter jest pusty, zwraca liczbę punktów życia gracza (parametrem może być serial albo alias).**  
  
Przykład:  
  
```python  
hits = MaxHits("self")  
```  
  
### MaxMana  
  
Sygnatura metody:  
  
**Int32 MaxMana(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
** Zwraca maksymalną liczbę punktów many wybranego obiektu mobile. Jesli paramter jest pusty, zwraca maksymalną liczbę punktów many gracza (parametrem może być serial albo alias).**  
  
Przykład:  
  
```python  
mana = MaxMana("self")  
```  
  
### MaxStam  
  
Sygnatura metody:  
  
**Int32 MaxStam(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
** Zwraca maksymalną liczbę punktów staminy wybranego obiektu mobile. Jesli paramter jest pusty, zwraca maksymalną liczbę punktów staminy gracza (parametrem może być serial albo alias).**  
  
Przykład:  
  
```python  
stam = MaxStam("self")  
```  
  
### MaxWeight  
  
Sygnatura metody:  
  
**Int32 MaxWeight()**  
  
Opis:  
  
**Zwraca maksymalne obciązenie zgodnie z oknem statusu gracza.**  
  
Przykład:  
  
```python  
if MaxWeight() < 300:  
```  
  
### Mounted  
  
Sygnatura metody:  
  
**Boolean Mounted(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca "true" jeśli podany obiekt mobile jest w siodle.**  
  
Przykład:  
  
```python  
if Mounted("self"):  
```  
  
### MoveItem  
  
Sygnatura metody:  
  
**Void MoveItem(System.Object, System.Object, Int32, Int32, Int32)**  
  
#### Parametry  
* item: An entity serial in integer or hex format, or an alias string such as "self".  
* destination: An entity serial in integer or hex format, or an alias string such as "self".  
* amount: Zmienna integer reprezentująca liczbę, np. 10. (Opcjonalny)  
* x: Koordynata X. (Opcjonalny)  
* y: Koordynata Y. (Opcjonalny)  
  
Opis:  
  
**Przenosi przedmiot do kontenera (parametrem może być serial lub alias).**  
  
Przykład:  
  
```python  
MoveItem("source", "destination")  
```  
  
### MoveItemOffset  
  
Sygnatura metody:  
  
**Void MoveItemOffset(System.Object, Int32, Int32, Int32, Int32)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* xoffset: Odstęp dla koordynaty X.  
* yoffset: Odstęp dla koordynaty Y.  
* zoffset: Odstęp dla koordynaty Z.  
* amount: Zmienna integer reprezentująca liczbę, np. 10. (Opcjonalny)  
  
Opis:  
  
**Przenosi podany serial/alias do lokacji oddalonej od gracza o koordynaty x,y,z. Brak podanej ilości lub wartość "-1" przenosi cały stos.**  
  
Przykład:  
  
```python  
MoveItemOffset("trashitem", 0, 1, 0, -1)  
```  
  
### MoveType  
  
Sygnatura metody:  
  
**Void MoveType(Int32, System.Object, System.Object, Int32, Int32, Int32, Int32, Int32)**  
  
#### Parametry  
* id: ItemId/Grafika np. 0x3db.  
* sourcecontainer: An entity serial in integer or hex format, or an alias string such as "self".  
* destinationcontainer: An entity serial in integer or hex format, or an alias string such as "self".  
* x: Koordynata X. (Opcjonalny)  
* y: Koordynata Y. (Opcjonalny)  
* z: Koordynata Z. (Opcjonalny)  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek). (Opcjonalny)  
* amount: Zmienna integer reprezentująca liczbę, np. 10. (Opcjonalny)  
  
Opis:  
  
**Przenieś typ obiektów ze źródła do podanej lokacji.**  
  
Przykład:  
  
```python  
#To move a type to another container...

MoveType(0x170f, "backpack", "bank")

#Destination can be the ground by specifying destination container to -1 and specifying the coordinates...

MoveType(0x170f, "backpack", -1, 1928, 2526, 0)

#Optional parameters exist for Hue and Amount, to move 10 maximum with the a Hue of 50...
MoveType(0x170f, "backpack", "bank", -1, -1, 0, 50, 10)  
```  
  
### MoveTypeOffset  
  
Sygnatura metody:  
  
**Boolean MoveTypeOffset(Int32, System.Object, Int32, Int32, Int32, Int32)**  
  
#### Parametry  
* id: ItemId/Grafika np. 0x3db.  
* findlocation: An entity serial in integer or hex format, or an alias string such as "self".  
* xoffset: Odstęp dla koordynaty X.  
* yoffset: Odstęp dla koordynaty Y.  
* zoffset: Odstęp dla koordynaty Z.  
* amount: Zmienna integer reprezentująca liczbę, np. 10. (Opcjonalny)  
  
Opis:  
  
**Przenosi typ obiektów ze źródłowego kontenera do lokalizacji oddalonej od gracza o koordynaty x,y,z. Brak podanej ilości lub wartość "-1" przenosi cały stos.**  
  
Przykład:  
  
```python  
MoveTypeOffset(0xf0e, "backpack", 0, 1, 0, -1)  
```  
  
### Murderer  
  
Sygnatura metody:  
  
**Boolean Murderer(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca "true" jeśli obiekt mobile jest mordercą.**  
  
Przykład:  
  
```python  
if Criminal("mount"):  
```  
  
### Name  
  
Sygnatura metody:  
  
**System.String Name(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Zwraca nazwę podanego obiektu mobile.**  
  
Przykład:  
  
```python  
if Name("self") == "Shmoo":  
```  
  
### Paralyzed  
  
Sygnatura metody:  
  
**Boolean Paralyzed(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca "true" jeśli podany obiekt mobile jest sparaliżowany/zamrożony.**  
  
Przykład:  
  
```python  
if Paralyzed("self"):  
```  
  
### Poisoned  
  
Sygnatura metody:  
  
**Boolean Poisoned(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Zwraca "true" jeśli podany obiekt mobile jest zatruty.**  
  
Przykład:  
  
```python  
if Poisoned("self"):  
```  
  
### Rehue  
  
Sygnatura metody:  
  
**Void Rehue(System.Object, Int32)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek).  
  
Opis:  
  
**Koloruje podany item/obiekt mobile na podaną wartość koloru. Ustawienie 0 usuwa kolor. (Eksperymentalna funkcjonalność!).**  
  
Przykład:  
  
```python  
Rehue("mount", 1176)  
```  
  
### RemoveFriend  
  
Sygnatura metody:  
  
**Void RemoveFriend(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Usuwa obiekt mobile z listy przyjaciół. W przypadku podania serial/alias zostanie użyty kursor szukania z klienta gry.**  
  
Przykład:  
  
```python  
RemoveFriend()  
```  
  
### SpecialMoveExists  
  
Sygnatura metody:  
  
**Boolean SpecialMoveExists(System.String)**  
  
#### Parametry  
* name: Nazwa specjalinego ruchu.  
  
Opis:  
  
**Sprawdź podany atak specjalny.**  
  
Przykład:  
  
```python  
if SpecialMoveExists("Death Strike"):  
```  
  
### Stam  
  
Sygnatura metody:  
  
**Int32 Stam(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Zwraca liczbę punktów staminy obiektu mobile. Jeśli parametr jest pusty, zwraca liczbę punktów staminy gracza (parametrem może być serial/alias).**  
  
Przykład:  
  
```python  
if Stam("self") < 25:  
```  
  
### Str  
  
Sygnatura metody:  
  
**Int32 Str()**  
  
Opis:  
  
**Zwraca liczbe punktów siły gracza.**  
  
Przykład:  
  
```python  
if Str() < 100:  
```  
  
### TithingPoints  
  
Sygnatura metody:  
  
**Int32 TithingPoints()**  
  
Opis:  
  
**Returns the current players' tithing points.**  
  
Przykład:  
  
```python  
if TithingPoints() < 1000:  
```  
  
### UseLayer  
  
Sygnatura metody:  
  
**Boolean UseLayer(System.Object, System.Object)**  
  
#### Parametry  
* layer: Zmienna String reprezentująca layer, np. "OneHanded" lub "Talisman" itp....  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Używa obiektu w podanym layerze, opcjonalnie można podać parametr obiektu mobile**  
  
Przykład:  
  
```python  
UseLayer("Talisman")  
```  
  
### War  
  
Sygnatura metody:  
  
**Boolean War(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Sprwadza, czy obiekt mobile jest w trybie walki.**  
  
Przykład:  
  
```python  
if War("self"):  
```  
  
### Weight  
  
Sygnatura metody:  
  
**Int32 Weight()**  
  
Opis:  
  
**Zwraca obecne obiciążenie zgodnie z oknem statusu gracza.**  
  
Przykład:  
  
```python  
if Weight() > 300:  
```  
  
### X  
  
Sygnatura metody:  
  
**Int32 X(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Zwraca koordynatę X dla podanego obiektu (parametrem może być serial lub alias).**  
  
Przykład:  
  
```python  
x = X("self")  
```  
  
### Y  
  
Sygnatura metody:  
  
**Int32 Y(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Zwraca koordynatę Y dla podanego obiektu (parametrem może być serial lub alias).**  
  
Przykład:  
  
```python  
y = Y("self")  
```  
  
### YellowHits  
  
Sygnatura metody:  
  
**Boolean YellowHits(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Returns true if the specified mobile is yellowhits.**  
  
Przykład:  
  
```python  
if YellowHits("self"):  
```  
  
### Z  
  
Sygnatura metody:  
  
**Int32 Z(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Zwraca koordynatę Z dla podanego obiektu (parametrem może być serial lub alias).**  
  
Przykład:  
  
```python  
y = Y("self")  
```  
  



## Typy  
### WandTypes  
* Clumsy  
* Identification  
* Heal  
* Feeblemind  
* Weaken  
* Magic_Arrow  
* Harm  
* Fireball  
* Greater_Heal  
* Lightning  
* Mana_Drain  
  
