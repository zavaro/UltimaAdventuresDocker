# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 게임오브젝트  
### AddFriend  
  
메서드 시그니처:  
  
**Int32 AddFriend(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**대상을 친구 목록에 추가. 시리얼 / 이름이 없으면, 타겟 커서가 표시됩니다.**  
  
예시:  
  
```python  
AddFriend()  
```  
  
### Ally  
  
메서드 시그니처:  
  
**Boolean Ally(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**대상이 동맹인 경우 작동합니다.**  
  
예시:  
  
```python  
if Criminal("mount"):  
```  
  
### AutoColorPick  
  
메서드 시그니처:  
  
**Void AutoColorPick(Int32)**  
  
#### 파라미터  
* hue: 아이탬 색조 또는 모든 값에 -1.  
  
설명:  
  
**Setup an automated reply to the incoming dye color gump, allowing you to define dye tubs color.
That command should be added prior to the action that opens the color pick gump.**  
  
예시:  
  
```python  
AutoColorPick(666)
UseObject('dyes')
WaitForTarget(1000)
Target('tub')  
```  
  
### BuffExists  
  
메서드 시그니처:  
  
**Boolean BuffExists(System.String)**  
  
#### 파라미터  
* name: 버프 이름.  
  
설명:  
  
**특정 버프를 확인합니다.**  
  
예시:  
  
```python  
if BuffExists("Blood Oath"):  
```  
  
### BuffTime  
  
메서드 시그니처:  
  
**Double BuffTime(System.String)**  
  
#### 파라미터  
* name: 버프 이름.  
  
설명:  
  
**버프 주문이 시전중이거나 만료 / 비활성화 된 경우 동작합니다.**  
  
예시:  
  
```python  
if not BuffExists('Enemy Of One') or BuffTime('Enemy Of One') < 5000:
    Cast('Enemy Of One')
  
```  
  
### ClearIgnoreList  
  
메서드 시그니처:  
  
**Void ClearIgnoreList()**  
  
설명:  
  
**차단된 리스트를 초기화합니다.**  
  
예시:  
  
```python  
ClearIgnoreList()  
```  
  
### CountType  
  
메서드 시그니처:  
  
**Int32 CountType(Int32, System.Object, Int32)**  
  
#### 파라미터  
* graphic: 아이템ID/그래픽 예시) 0x3db .  
* source: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
* hue: 아이탬 색조 또는 모든 값에 -1. (옵션)  
  
설명:  
  
**컨테이너 안에 있는 물건의 수량을 비교합니다.**  
  
예시:  
  
```python  
CountType(0xff, "backpack")  
```  
  
### CountTypeGround  
  
메서드 시그니처:  
  
**Int32 CountTypeGround(Int32, Int32, Int32)**  
  
#### 파라미터  
* graphic: 아이템ID/그래픽 예시) 0x3db .  
* hue: 아이탬 색조 또는 모든 값에 -1. (옵션)  
* range: 거리 예시) 10. (옵션)  
  
설명:  
  
**지상에있는 탈것 또는 물건의 수량을 비교합니다.**  
  
예시:  
  
```python  
if CountGround(0xff, 0, 10) < 1:  
```  
  
### Criminal  
  
메서드 시그니처:  
  
**Boolean Criminal(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**대상이 범죄자인 경우 작동합니다.**  
  
예시:  
  
```python  
if Criminal("mount"):  
```  
  
### Dead  
  
메서드 시그니처:  
  
**Boolean Dead(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**대상이 죽은 경우 true로, 그렇지 않은 경우 false로 동작하고, 매개 변수가 null 인 경우 플레이어에게 적용됩니다. (매개 변수는 시리얼 번호 또는 이름입니다.)**  
  
예시:  
  
```python  
if Dead("self"):  
```  
  
### Dex  
  
메서드 시그니처:  
  
**Int32 Dex()**  
  
설명:  
  
**플레이어의 덱스를 돌려줍니다.**  
  
예시:  
  
```python  
if Str() < 100:  
```  
  
### DiffHits  
  
메서드 시그니처:  
  
**Int32 DiffHits(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**매개 변수가 null인 경우 최대 및 현재 타격의 차이를 적용하고, 다음 플레이어에서 동작합니다. (매개 변수는 시리얼 번호 또는 이름입니다.)**  
  
예시:  
  
```python  
if DiffHits("self") > 50:  
```  
  
### DiffWeight  
  
메서드 시그니처:  
  
**Int32 DiffWeight()**  
  
설명:  
  
**최대로 소지할 수 있는 무게가 되었을때 작동합니다.**  
  
예시:  
  
```python  
if DiffWeight() > 50:  
```  
  
### Direction  
  
메서드 시그니처:  
  
**System.String Direction(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**Returns the Direction the given alias/serial is facing**  
  
예시:  
  
```python  
if Direction('enemy') == 'West':  
```  
  
### DirectionTo  
  
메서드 시그니처:  
  
**System.String DirectionTo(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**플레이어와 해당 개체의 방향으로 작동합니다.**  
  
예시:  
  
```python  
Run(DirectionTo("enemy"))  
```  
  
### Distance  
  
메서드 시그니처:  
  
**Int32 Distance(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**해당 개체와 정해진 거리가 되었을때 작동합니다.**  
  
예시:  
  
```python  
if Distance("mount") < 4:  
```  
  
### Enemy  
  
메서드 시그니처:  
  
**Boolean Enemy(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**대상이 적일때 작동됩니다.**  
  
예시:  
  
```python  
if Criminal("mount"):  
```  
  
### EquipWand  
  
메서드 시그니처:  
  
**Boolean EquipWand(System.String, Int32)**  
  
#### 파라미터  
* wandname: 지팡이 이름. 참조: [WandTypes](#WandTypes)  
* minimumcharges: 정수 값 - 사용 방법에 대한 설명을 보세요. (옵션)  
  
설명:  
  
**배낭 안에서 wand를 찾아서 착용합니다.**  
  
예시:  
  
```python  
#Equip a fireball wand if one can be found in our backpack..
if FindWand("fireball", "backpack", 5):
 #Remove current item in hand
 if FindLayer("OneHanded"):
  ClearHands("left")
 #Equip the wand
 EquipWand("fireball")  
```  
  
### FindObject  
  
메서드 시그니처:  
  
**Boolean FindObject(System.Object, Int32, System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* range: 거리 예시) 10. (옵션)  
* findlocation: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**개체에 대한 정보를 찾습니다. 해당 개체에 대한 정보가 없으면 기본 값으로 변경됩니다.**  
  
예시:  
  
```python  
# Find on ground
FindObject("mount")

# Find on ground with range
FindObject("mount", 10)

# Find in container, must specify search level or -1
FindObject("weapon", -1, "backpack")    
```  
  
### FindType  
  
메서드 시그니처:  
  
**Boolean FindType(Int32, Int32, System.Object, Int32, Int32)**  
  
#### 파라미터  
* graphic: 아이템ID/그래픽 예시) 0x3db .  
* range: 거리 예시) 10. (옵션)  
* findlocation: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
* hue: 아이탬 색조 또는 모든 값에 -1. (옵션)  
* minimumstackamount: 수량을 나타내는 정수, 예) 10. (옵션)  
  
설명:  
  
**개체에 대한 이미지 정보를 찾습니다.  해당 개체에 대한 정보가 없으면 기본 값으로 변경됩니다.**  
  
예시:  
  
```python  
# Look for a food item from a list and eat 1 if found.
if not ListExists("food"): 
 CreateList("food") 
 PushList("food", 0x9b7) #bird 
 PushList("food", 0x9d3) #ham 
 PushList("food", 0x97d) #cheese 
 PushList("food", 0x9d0) #apple 
 PushList("food", 0x9eb) #muffin 
 PushList("food", 0x97b) #fishsteak 
 PushList("food", 0x9c0) #sausage 
 PushList("food", 0x9f2) #ribs 
 PushList("food", 0x9d1) #grapes 
 PushList("food", 0x9d2) #peach 

for i in GetList("food"): 
 if FindType(i, -1, "backpack"): 
  UseObject("found") 
  break  
```  
  
### FindWand  
  
메서드 시그니처:  
  
**Boolean FindWand(System.String, System.Object, Int32)**  
  
#### 파라미터  
* wandname: 지팡이 이름. 참조: [WandTypes](#WandTypes)  
* containersource: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
* minimumcharges: 정수 값 - 사용 방법에 대한 설명을 보세요. (옵션)  
  
설명:  
  
**wand를 검색하고 이름을 "found"로 설정합니다.**  
  
예시:  
  
```python  
FindWand("fireball", "backpack", 10)  
```  
  
### Followers  
  
메서드 시그니처:  
  
**Int32 Followers()**  
  
설명:  
  
**상태 표시 줄에 현재 팔로워 수를 표시합니다.**  
  
예시:  
  
```python  
if Followers() < 1:  
```  
  
### Gold  
  
메서드 시그니처:  
  
**Int32 Gold()**  
  
설명:  
  
**상태 표시 줄에 현재 골드양을 표시합니다.**  
  
예시:  
  
```python  
if Gold() < 2000:  
```  
  
### Graphic  
  
메서드 시그니처:  
  
**Int32 Graphic(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**주어진 객체의 아이템 ID를 표시합니다. (개체는 시리얼 번호 또는 이름입니다.)**  
  
예시:  
  
```python  
Graphic("mount")  
```  
  
### Gray  
  
메서드 시그니처:  
  
**Boolean Gray(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**대상이 공격 가능한 경우 작동합니다.**  
  
예시:  
  
```python  
if Criminal("mount"):  
```  
  
### Hidden  
  
메서드 시그니처:  
  
**Boolean Hidden(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**대상이 숨어 있으면 true로, 그렇지 않으면 false로 동작하고, 매개 변수가 null이면 플레이어에서 적용됩니다.  (매개 변수는 시리얼 번호 또는 이름입니다.)**  
  
예시:  
  
```python  
if Hidden("self"):  
```  
  
### Hits  
  
메서드 시그니처:  
  
**Int32 Hits(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**매개 변수가 null 인 경우 대상의 히트 포인트가 다음 플레이어에게 적용됩니다. (매개 변수는 시리얼 번호 또는 이름입니다.)**  
  
예시:  
  
```python  
hits = Hits("self")  
```  
  
### Hue  
  
메서드 시그니처:  
  
**Int32 Hue(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**지정된 객체의 색상을 변경합니다. (매개 변수는 색상번호 또는 색상이름입니다.)**  
  
예시:  
  
```python  
if Hue("mount") == 0:  
```  
  
### IgnoreObject  
  
메서드 시그니처:  
  
**Void IgnoreObject(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**찾기 명령에서 지정된 대상을 무시합니다.**  
  
예시:  
  
```python  
IgnoreObject("self")  
```  
  
### InFriendList  
  
메서드 시그니처:  
  
**Boolean InFriendList(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**대상이 친구 목록에 있으면 작동합니다.**  
  
예시:  
  
```python  
if InFriendList("last"):  
```  
  
### InIgnoreList  
  
메서드 시그니처:  
  
**Boolean InIgnoreList(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**시리얼 / 이름이 무시 목록에 있는지 확인하세요.**  
  
예시:  
  
```python  
if InIgnoreList("mount"):  
```  
  
### Innocent  
  
메서드 시그니처:  
  
**Boolean Innocent(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**대상이 무고한 상태일 경우 작동합니다.**  
  
예시:  
  
```python  
if Criminal("mount"):  
```  
  
### InParty  
  
메서드 시그니처:  
  
**Boolean InParty(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**주어진 시리얼 /  대상이 당신과 파티에 있다면 작동합니다.**  
  
예시:  
  
```python  
if InParty("friend"):  
```  
  
### InRange  
  
메서드 시그니처:  
  
**Boolean InRange(System.Object, Int32)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* distance: 거리.  
  
설명:  
  
**캐릭터와 다른 대상 또는 아이템 사이의 거리를 확인하십시오.**  
  
예시:  
  
```python  
if InRange("enemy", 10):  
```  
  
### Int  
  
메서드 시그니처:  
  
**Int32 Int()**  
  
설명:  
  
**플레이어의 지능을 반환합니다.**  
  
예시:  
  
```python  
if Str() < 100:  
```  
  
### Invulnerable  
  
메서드 시그니처:  
  
**Boolean Invulnerable(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**모바일의 무적이라면 작동합니다.**  
  
예시:  
  
```python  
if Criminal("mount"):  
```  
  
### Luck  
  
메서드 시그니처:  
  
**Int32 Luck()**  
  
설명:  
  
**상태 표시 줄에 운 값이 표시합니다.**  
  
예시:  
  
```python  
if Luck() < 800:  
```  
  
### Mana  
  
메서드 시그니처:  
  
**Int32 Mana(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**매개 변수가 null 인 경우 지정된 대상의 마나를 플레이어에게 반환합니다. (매개 변수는 시리얼 또는 이름입니다.)**  
  
예시:  
  
```python  
if Mana("self") < 25:  
```  
  
### MaxFollowers  
  
메서드 시그니처:  
  
**Int32 MaxFollowers()**  
  
설명:  
  
**상태 표시 줄에 최대 팔로워 수를 표시합니다.**  
  
예시:  
  
```python  
if Followers() == MaxFollowers():  
```  
  
### MaxHits  
  
메서드 시그니처:  
  
**Int32 MaxHits(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**매개 변수가 null 인 경우 대상의 최대 히트 포인트를 플레이어에서 돌려줍니다.  (매개 변수는 시리얼 또는 이름입니다.)**  
  
예시:  
  
```python  
hits = MaxHits("self")  
```  
  
### MaxMana  
  
메서드 시그니처:  
  
**Int32 MaxMana(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**매개 변수가 null 인 경우 대상의 최대 마나를 플레이어에서 돌려줍니다.  (매개 변수는 시리얼 또는 이름입니다.)**  
  
예시:  
  
```python  
mana = MaxMana("self")  
```  
  
### MaxStam  
  
메서드 시그니처:  
  
**Int32 MaxStam(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**매개 변수가 null 인 경우 지정된 대상의 최대 체력 플레이어에서 돌려줍니다. (매개 변수는 시리얼 또는 이름입니다.)**  
  
예시:  
  
```python  
stam = MaxStam("self")  
```  
  
### MaxWeight  
  
메서드 시그니처:  
  
**Int32 MaxWeight()**  
  
설명:  
  
**상태 막대 데이터에 따라 최대 무게를 반환합니다.**  
  
예시:  
  
```python  
if MaxWeight() < 300:  
```  
  
### Mounted  
  
메서드 시그니처:  
  
**Boolean Mounted(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**대상이 마운트 된 경우 작동합니다.**  
  
예시:  
  
```python  
if Mounted("self"):  
```  
  
### MoveItem  
  
메서드 시그니처:  
  
**Void MoveItem(System.Object, System.Object, Int32, Int32, Int32)**  
  
#### 파라미터  
* item: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* destination: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* amount: 수량을 나타내는 정수, 예) 10. (옵션)  
* x: X 좌표. (옵션)  
* y: Y 좌표. (옵션)  
  
설명:  
  
**아이템을 컨테이너로 옮깁니다. (매개 변수는 시리얼 또는 이름입니다.)**  
  
예시:  
  
```python  
MoveItem("source", "destination")  
```  
  
### MoveItemOffset  
  
메서드 시그니처:  
  
**Void MoveItemOffset(System.Object, Int32, Int32, Int32, Int32)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* xoffset: X 좌표 변수.  
* yoffset: Y 좌표 변수.  
* zoffset: Z 좌표 변수.  
* amount: 수량을 나타내는 정수, 예) 10. (옵션)  
  
설명:  
  
**시리얼 / 이름을 플레이어의 해당 x, y, z 오프셋으로 이동 시키십시오. 지정된 것이 없거나 -1이면 전체 스택이 옮겨짐니다.**  
  
예시:  
  
```python  
MoveItemOffset("trashitem", 0, 1, 0, -1)  
```  
  
### MoveType  
  
메서드 시그니처:  
  
**Void MoveType(Int32, System.Object, System.Object, Int32, Int32, Int32, Int32, Int32)**  
  
#### 파라미터  
* id: 아이템ID/그래픽 예시) 0x3db .  
* sourcecontainer: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* destinationcontainer: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* x: X 좌표. (옵션)  
* y: Y 좌표. (옵션)  
* z: Z 좌표. (옵션)  
* hue: 아이탬 색조 또는 모든 값에 -1. (옵션)  
* amount: 수량을 나타내는 정수, 예) 10. (옵션)  
  
설명:  
  
**소스에서 대상으로 이동합니다.**  
  
예시:  
  
```python  
#To move a type to another container...

MoveType(0x170f, "backpack", "bank")

#Destination can be the ground by specifying destination container to -1 and specifying the coordinates...

MoveType(0x170f, "backpack", -1, 1928, 2526, 0)

#Optional parameters exist for Hue and Amount, to move 10 maximum with the a Hue of 50...
MoveType(0x170f, "backpack", "bank", -1, -1, 0, 50, 10)  
```  
  
### MoveTypeOffset  
  
메서드 시그니처:  
  
**Boolean MoveTypeOffset(Int32, System.Object, Int32, Int32, Int32, Int32)**  
  
#### 파라미터  
* id: 아이템ID/그래픽 예시) 0x3db .  
* findlocation: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* xoffset: X 좌표 변수.  
* yoffset: Y 좌표 변수.  
* zoffset: Z 좌표 변수.  
* amount: 수량을 나타내는 정수, 예) 10. (옵션)  
  
설명:  
  
**대상을 지정된 소스 컨테이너에서 플레이어의 해당 x, y, z 오프셋으로 이동 시키십시오. 지정된 것이 없거나 -1이면 전체 스택이 옮겨짐니다.**  
  
예시:  
  
```python  
MoveTypeOffset(0xf0e, "backpack", 0, 1, 0, -1)  
```  
  
### Murderer  
  
메서드 시그니처:  
  
**Boolean Murderer(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**대상이 살인자인 경우 작동합니다.**  
  
예시:  
  
```python  
if Criminal("mount"):  
```  
  
### Name  
  
메서드 시그니처:  
  
**System.String Name(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**대상의 이름을 표시합니다.**  
  
예시:  
  
```python  
if Name("self") == "Shmoo":  
```  
  
### Paralyzed  
  
메서드 시그니처:  
  
**Boolean Paralyzed(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**대상이 마비 된 경우 작동합니다.**  
  
예시:  
  
```python  
if Paralyzed("self"):  
```  
  
### Poisoned  
  
메서드 시그니처:  
  
**Boolean Poisoned(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**대상이 중독 된 경우 작동합니다.**  
  
예시:  
  
```python  
if Poisoned("self"):  
```  
  
### Rehue  
  
메서드 시그니처:  
  
**Void Rehue(System.Object, Int32)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* hue: 아이탬 색조 또는 모든 값에 -1.  
  
설명:  
  
**색조 값으로 아이템 / 대상을 변경합니다.  0이면 제거됩니다. (실험)**  
  
예시:  
  
```python  
Rehue("mount", 1176)  
```  
  
### RemoveFriend  
  
메서드 시그니처:  
  
**Void RemoveFriend(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**친구 목록에서 대상을 제거하고 시리얼 / 이름을 제공하지 않으면 대상 커서가 표시됩니다.**  
  
예시:  
  
```python  
RemoveFriend()  
```  
  
### SpecialMoveExists  
  
메서드 시그니처:  
  
**Boolean SpecialMoveExists(System.String)**  
  
#### 파라미터  
* name: 특수기 이름.  
  
설명:  
  
**특정 특별 이동 확인합니다.**  
  
예시:  
  
```python  
if SpecialMoveExists("Death Strike"):  
```  
  
### Stam  
  
메서드 시그니처:  
  
**Int32 Stam(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**매개 변수가 null 인 경우 지정된 대상의 체력 플레이어에서 돌려줍니다. (매개 변수는 시리얼 또는 이름입니다.)**  
  
예시:  
  
```python  
if Stam("self") < 25:  
```  
  
### Str  
  
메서드 시그니처:  
  
**Int32 Str()**  
  
설명:  
  
**플레이어의 힘을 돌려줍니다**  
  
예시:  
  
```python  
if Str() < 100:  
```  
  
### TithingPoints  
  
메서드 시그니처:  
  
**Int32 TithingPoints()**  
  
설명:  
  
**현재 플레이어의 십일조 포인트를 반환합니다.**  
  
예시:  
  
```python  
if TithingPoints() < 1000:  
```  
  
### UseLayer  
  
메서드 시그니처:  
  
**Boolean UseLayer(System.Object, System.Object)**  
  
#### 파라미터  
* layer: "한손" 또는 "부적" 등과 같은 레이어를 나태니는 문자열.  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**Uses object in the specified layer, optional parameter for mobile**  
  
예시:  
  
```python  
UseLayer("Talisman")  
```  
  
### War  
  
메서드 시그니처:  
  
**Boolean War(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**대상이 전쟁 모드인지 확인합니다.**  
  
예시:  
  
```python  
if War("self"):  
```  
  
### Weight  
  
메서드 시그니처:  
  
**Int32 Weight()**  
  
설명:  
  
**스텟창에 현재 무게를 표시합니다.**  
  
예시:  
  
```python  
if Weight() > 300:  
```  
  
### X  
  
메서드 시그니처:  
  
**Int32 X(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**대상에 X 좌표를 표시합니다. (매개 변수는 시리얼 또는 이름입니다.)**  
  
예시:  
  
```python  
x = X("self")  
```  
  
### Y  
  
메서드 시그니처:  
  
**Int32 Y(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**대상에 Y 좌표를 표시합니다. (매개 변수는 시리얼 또는 이름입니다.)**  
  
예시:  
  
```python  
y = Y("self")  
```  
  
### YellowHits  
  
메서드 시그니처:  
  
**Boolean YellowHits(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**대상이 노랑색이면 작동합니다.**  
  
예시:  
  
```python  
if YellowHits("self"):  
```  
  
### Z  
  
메서드 시그니처:  
  
**Int32 Z(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**대상에 Z 좌표를 표시합니다. (매개 변수는 시리얼 또는 이름입니다.)**  
  
예시:  
  
```python  
y = Y("self")  
```  
  



## 타입  
### WandTypes  
* Clumsy  
* Identification  
* Heal  
* Feeblemind  
* Weaken  
* Magic_Arrow  
* Harm  
* Fireball  
* Greater_Heal  
* Lightning  
* Mana_Drain  
  
