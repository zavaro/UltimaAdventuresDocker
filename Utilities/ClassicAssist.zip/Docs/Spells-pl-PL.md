# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Czary  
### Cast  
  
Sygnatura metody:  
  
**Boolean Cast(System.String, System.Object)**  
  
#### Parametry  
* name: Nazwa czaru.  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Używa wybrany czas i automatycznie ustawia na cel wybrany obiekt.**  
  
Przykład:  
  
```python  
Cast("Recall", "runebook")  
```  
  
### Cast  
  
Sygnatura metody:  
  
**Void Cast(System.String)**  
  
#### Parametry  
* name: Nazwa czaru.  
  
Opis:  
  
**Używa wybrany czas i automatycznie ustawia na cel wybrany obiekt.**  
  
Przykład:  
  
```python  
Cast("Recall", "runebook")  
```  
  
### InterruptSpell  
  
Sygnatura metody:  
  
**Void InterruptSpell()**  
  
Opis:  
  
**Attempts to interrupt spell by lifting an item briefly.**  
  
Przykład:  
  
```python  
InterruptSpell()  
```  
  



