# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 스킬  
### SetSkill  
  
메서드 시그니처:  
  
**Void SetSkill(System.String, System.String)**  
  
#### 파라미터  
* skill: 스킬 이름.  
* status: 잠금상태 - "위","아래", 또는 "잠금". 참조: [LockStatus](#LockStatus)  
  
설명:  
  
**스킬의 잠금 상태를 위, 아래 또는 잠금으로 설정합니다.**  
  
예시:  
  
```python  
SetSkill("hiding", "locked")  
```  
  
### SetStatus  
  
메서드 시그니처:  
  
**Void SetStatus(System.String, System.String)**  
  
#### 파라미터  
* stat: 문자열 값 - 사용 방법에 대한 설명을 보세요. 참조: [StatType](#StatType)  
* lockstatus: 잠금상태 - "위","아래", 또는 "잠금". 참조: [LockStatus](#LockStatus)  
  
설명:  
  
**스텟을 잠급으로 설정합니다.**  
  
예시:  
  
```python  
SetStatus('str', 'locked')  
```  
  
### Skill  
  
메서드 시그니처:  
  
**Double Skill(System.String)**  
  
#### 파라미터  
* name: 스킬 이름.  
  
설명:  
  
**스킬 이름 기본 값으로 변경합니다.**  
  
예시:  
  
```python  
if Skill("hiding") < 100:  
```  
  
### SkillCap  
  
메서드 시그니처:  
  
**Double SkillCap(System.String)**  
  
#### 파라미터  
* name: 스킬 이름.  
  
설명:  
  
**지정된 스킬의 스킬 캡을 지정합니다.**  
  
예시:  
  
```python  
if SkillCap("Blacksmithy") == 120:  
```  
  
### SkillState  
  
메서드 시그니처:  
  
**System.String SkillState(System.String)**  
  
#### 파라미터  
* name: 스킬 이름.  
  
설명:  
  
**스킬의 잠금 상태, 위, 아래 또는 잠금으로 변경합니다.**  
  
예시:  
  
```python  
if SkillState("hiding') == "locked":  
```  
  
### UseSkill  
  
메서드 시그니처:  
  
**Void UseSkill(System.String)**  
  
#### 파라미터  
* skill: 스킬 이름.  
  
설명:  
  
**주어진 스킬 이름을 불러옵니다.**  
  
예시:  
  
```python  
UseSkill("Hiding")  
```  
  



## 타입  
### LockStatus  
* Up  
* Down  
* Locked  
  
### StatType  
* Str  
* Dex  
* Int  
  
