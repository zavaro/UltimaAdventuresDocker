# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Menu  
### CloseMenu  
  
Sygnatura metody:  
  
**Void CloseMenu(Int32)**  
  
#### Parametry  
* gumpid: ItemId/Grafika np. 0x3db.  
  
Opis:  
  
**Zamyka podane menu o zadanym id**  
  
Przykład:  
  
```python  
CloseMenu(0x1d1)  
```  
  
### InMenu  
  
Sygnatura metody:  
  
**Boolean InMenu(Int32, System.String)**  
  
#### Parametry  
* gumpid: ItemId/Grafika np. 0x3db.  
* text: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Zwraca "True" jeśli tutył menu lub wpisy tytułó zawierają podany tekst.**  
  
Przykład:  
  
```python  
UseSkill('Tracking')
WaitForMenu(0x1d0, 5000)
ReplyMenu(0x1d0, 3, 0x2106, 0)
WaitForMenu(0x1d1, 5000)
if InMenu(0x1d1, 'Omar'):
 HeadMsg('Omar is in range', 'self')
CloseMenu(0x1d1)  
```  
  
### MenuExists  
  
Sygnatura metody:  
  
**Boolean MenuExists(Int32)**  
  
Opis:  
  
**Zwraca "True" jeśli podane menu o zadanym id występuje**  
  
Przykład:  
  
```python  
if MenuExists(0x1d1):  
```  
  
### ReplyMenu  
  
Sygnatura metody:  
  
**Void ReplyMenu(Int32, Int32, Int32, Int32)**  
  
#### Parametry  
* gumpid: ItemId/Grafika np. 0x3db.  
* buttonid: ID przycisku Gump.  
* itemid: ItemId/Grafika np. 0x3db. (Opcjonalny)  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek). (Opcjonalny)  
  
Opis:  
  
**Wysyła żadanie powtórzenia przycisku do menu serwera**  
  
Przykład:  
  
```python  
ReplyMenu(0x1d0, 3, 0x2106, 0)  
```  
  
### WaitForMenu  
  
Sygnatura metody:  
  
**Boolean WaitForMenu(Int32, Int32)**  
  
#### Parametry  
* gumpid: ItemId/Grafika np. 0x3db. (Opcjonalny)  
* timeout: Timeout w milisekundach. (Opcjonalny)  
  
Opis:  
  
**Zatrzymuje działanie dopóki nie odbierze pakietu . Opcjonalne parametry gumpId lub timeout.**  
  
Przykład:  
  
```python  
UseSkill('Tracking')
WaitForMenu(0x1d0, 5000)
ReplyMenu(0x1d0, 3, 0x2106, 0)
WaitForMenu(0x1d1, 5000)  
```  
  



