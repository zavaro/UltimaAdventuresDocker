# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Abilità  
### ActiveAbility  
  
Sintassi del comando:  
  
**Boolean ActiveAbility()**  
  
Descrizione:  
  
**Risulta True se una delle Abilità (primaria o secondaria) è abilitata**  
  
Esempio:  
  
```python  
if not ActiveAbility():
 SetAbility("primary", "on")  
```  
  
### ClearAbility  
  
Sintassi del comando:  
  
**Void ClearAbility()**  
  
Descrizione:  
  
**Disabilita Weapon Ability**  
  
Esempio:  
  
```python  
ClearAbility()  
```  
  
### Fly  
  
Sintassi del comando:  
  
**Void Fly()**  
  
Descrizione:  
  
**Gargoyle vola se non sta già volando**  
  
Esempio:  
  
```python  
Fly()  
```  
  
### Flying  
  
Sintassi del comando:  
  
**Boolean Flying(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Se stai volando**  
  
Esempio:  
  
```python  
if Flying("self"):  
```  
  
### Land  
  
Sintassi del comando:  
  
**Void Land()**  
  
Descrizione:  
  
**Gargoyle smette di volare se sta volando**  
  
Esempio:  
  
```python  
Land()  
```  
  
### SetAbility  
  
Sintassi del comando:  
  
**Void SetAbility(System.String, System.String)**  
  
#### Parametri  
* ability: Il nome della abilità, "primary", "secondary", "stun" o "disarm".  
* onoff: "on" oppure "off". (Opzionale)  
  
Descrizione:  
  
**Attiva Weapon Ability Primaria/Secondaria**  
  
Esempio:  
  
```python  
SetAbility("primary")  
```  
  



