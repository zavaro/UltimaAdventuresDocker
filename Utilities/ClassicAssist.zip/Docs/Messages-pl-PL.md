# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Wiadomość  
### AllyMsg  
  
Sygnatura metody:  
  
**Void AllyMsg(System.String)**  
  
#### Parametry  
* message: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Wysyła wiadomość do sojuszników na czacie.**  
  
Przykład:  
  
```python  
AllyMsg("alert")  
```  
  
### CancelPrompt  
  
Sygnatura metody:  
  
**Void CancelPrompt()**  
  
Opis:  
  
**Anuluje prompt (np. podczas zapytania o wskazanie obiektu).**  
  
Przykład:  
  
```python  
CancelPrompt()  
```  
  
### ChatMsg  
  
Sygnatura metody:  
  
**Void ChatMsg(System.String)**  
  
#### Parametry  
* message: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Wysyła wiadomość na chacie.**  
  
Przykład:  
  
```python  
ChatMsg("Mary had a little lamb")  
```  
  
### EmoteMsg  
  
Sygnatura metody:  
  
**Void EmoteMsg(System.String)**  
  
#### Parametry  
* message: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Użycie emocji w grze.**  
  
Przykład:  
  
```python  
EmoteMsg("hi")  
```  
  
### GetText  
  
Sygnatura metody:  
  
**System.ValueTuple`2[System.Boolean,System.String] GetText(System.String, Int32)**  
  
#### Parametry  
* prompt: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
* timeout: Timeout w milisekundach. (Opcjonalny)  
  
Opis:  
  
**Sends an internal prompt request and returns the text entered**  
  
Przykład:  
  
```python  
res, name = GetText("Name?", 10000)

if res:
 Rename(0xc1b, name)  
```  
  
### GuildMsg  
  
Sygnatura metody:  
  
**Void GuildMsg(System.String)**  
  
#### Parametry  
* message: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Wysyła wiadomość do czatu gildii.**  
  
Przykład:  
  
```python  
GuildMsg("alert")  
```  
  
### HeadMsg  
  
Sygnatura metody:  
  
**Void HeadMsg(System.String, System.Object, Int32)**  
  
#### Parametry  
* message: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek). (Opcjonalny)  
  
Opis:  
  
**Wyświetla wiadomość nad głową obiektu mobile lub nad przedmiotem.**  
  
Przykład:  
  
```python  
HeadMsg("hi", "backpack")  
```  
  
### Msg  
  
Sygnatura metody:  
  
**Void Msg(System.String, Int32)**  
  
#### Parametry  
* message: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek). (Opcjonalny)  
  
Opis:  
  
**Używanie mówienia postaci. Opcjonalnie można podać kolor.**  
  
Przykład:  
  
```python  
Msg("hi")  
```  
  
### PartyMsg  
  
Sygnatura metody:  
  
**Void PartyMsg(System.String)**  
  
#### Parametry  
* message: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Wysyła wiadomść do czatu sprzymieżeńców.**  
  
Przykład:  
  
```python  
PartyMsg("alert")  
```  
  
### PromptMsg  
  
Sygnatura metody:  
  
**Void PromptMsg(System.String)**  
  
#### Parametry  
* message: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Sends the specified message as a prompt response**  
  
Przykład:  
  
```python  
PromptMsg("hello")  
```  
  
### WaitForPrompt  
  
Sygnatura metody:  
  
**Boolean WaitForPrompt(Int32)**  
  
#### Parametry  
* timeout: Timeout w milisekundach.  
  
Opis:  
  
**Czeka określoną ilość czasu aż pojawi się pakiet z wybranym obiektem za pomocą wbudowanego narzędzia gry.**  
  
Przykład:  
  
```python  
WaitForPrompt(5000)  
```  
  
### WhisperMsg  
  
Sygnatura metody:  
  
**Void WhisperMsg(System.String)**  
  
#### Parametry  
* message: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Szepcze postacią gracza dany tekst.**  
  
Przykład:  
  
```python  
WhisperMsg("hi")  
```  
  
### YellMsg  
  
Sygnatura metody:  
  
**Void YellMsg(System.String)**  
  
#### Parametry  
* message: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Wyrzykuje postacią gracza dany tekst.**  
  
Przykład:  
  
```python  
YellMsg("hi")  
```  
  



