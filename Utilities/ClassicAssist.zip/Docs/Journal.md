# ClassicAssist Macro Commands  
Generated on 12/7/2020 6:04:46 AM  
Version: 0.3.156.250  
  
## Journal  
### ClearJournal  
  
Method Signature:  
  
**Void ClearJournal()**  
  
Description:  
  
**Clear all journal texts.**  
  
Example:  
  
```python  
ClearJournal()  
```  
  
### InJournal  
  
Method Signature:  
  
**Boolean InJournal(System.String, System.String, Int32)**  
  
Description:  
  
**Check for a text in journal, optional source name.**  
  
Example:  
  
```python  
if InJournal("town guards", "system"):  
```  
  
### WaitForJournal  
  
Method Signature:  
  
**Boolean WaitForJournal(System.String, Int32, System.String)**  
  
Description:  
  
**Wait the given timeout for the journal text to appear.**  
  
Example:  
  
```python  
if WaitForJournal("town guards", 5000, "system"):  
```  
  



