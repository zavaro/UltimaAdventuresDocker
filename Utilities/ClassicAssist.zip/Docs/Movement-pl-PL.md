# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Poruszanie  
### Pathfind  
  
Sygnatura metody:  
  
**Void Pathfind(Int32, Int32, Int32)**  
  
#### Parametry  
* x: Koordynata X.  
* y: Koordynata Y.  
* z: Koordynata Z.  
  
Opis:  
  
**Requests client to pathfind to given coordinates / entity**  
  
Przykład:  
  
```python  
#Pathfind to coordinates
Pathfind(1438, 1630, 20)

#Pathfind to entity
SetEnemy(0x3c9)
Pathfind('enemy')  
```  
  
### Pathfind  
  
Sygnatura metody:  
  
**Void Pathfind(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Requests client to pathfind to given coordinates / entity**  
  
Przykład:  
  
```python  
#Pathfind to coordinates
Pathfind(1438, 1630, 20)

#Pathfind to entity
SetEnemy(0x3c9)
Pathfind('enemy')  
```  
  
### Run  
  
Sygnatura metody:  
  
**Boolean Run(System.String)**  
  
#### Parametry  
* direction: Kierunek, np. "West". Zobacz też: [Direction](#Direction)  
  
Opis:  
  
**Biegnie postacią gracza w określonym kierunku. Dopuszczalne wartości: "east", "west", "north", "south".**  
  
Przykład:  
  
```python  
Run("east")  
```  
  
### SetForceWalk  
  
Sygnatura metody:  
  
**Void SetForceWalk(Boolean)**  
  
Opis:  
  
**Ustawia wymuszenie chodzenia. Dopuszczalne wartości: "True", "False".**  
  
Przykład:  
  
```python  
SetForceWalk(True)  
```  
  
### ToggleForceWalk  
  
Sygnatura metody:  
  
**Void ToggleForceWalk()**  
  
Opis:  
  
**Przełącza wymuszone chodzenie.**  
  
Przykład:  
  
```python  
ToggleForceWalk()  
```  
  
### Turn  
  
Sygnatura metody:  
  
**Void Turn(System.String)**  
  
#### Parametry  
* direction: Kierunek, np. "West". Zobacz też: [Direction](#Direction)  
  
Opis:  
  
**Odwraca postać gracza w zadanym kierunku. Dopuszczalne wartości: "east", "west", "north", "south".**  
  
Przykład:  
  
```python  
Turn("east")  
```  
  
### Walk  
  
Sygnatura metody:  
  
**Boolean Walk(System.String)**  
  
#### Parametry  
* direction: Kierunek, np. "West".  
  
Opis:  
  
**Idzie postacią gracza w zadanym kierunku. Dopuszczalne wartości: "east", "west", "north", "south".**  
  
Przykład:  
  
```python  
Walk("east")  
```  
  



## Typy  
### Direction  
* North  
* Northeast  
* East  
* Southeast  
* South  
* Southwest  
* West  
* Northwest  
* Invalid  
  
