# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Gumps  
### CloseGump  
  
Sintassi del comando:  
  
**Void CloseGump(Int32)**  
  
#### Parametri  
* serial: Un Seriale, per esempio 0xgfoijhd.  
  
Descrizione:  
  
**Chiudi un gump (seriale)**  
  
Esempio:  
  
```python  
CloseGump(0x454ddef)  
```  
  
### ConfirmPrompt  
  
Sintassi del comando:  
  
**Boolean ConfirmPrompt(System.String, Boolean)**  
  
Descrizione:  
  
**Visualizza in game una finestra con un messaggio. Ritorna True se si preme Ok, altrimenti False**  
  
Esempio:  
  
```python  
res = ConfirmPrompt("Play macro?")

if res:
 PlayMacro("Macro")  
```  
  
### GumpExists  
  
Sintassi del comando:  
  
**Boolean GumpExists(UInt32)**  
  
Descrizione:  
  
**Controlla se un Gump esiste (seriale)**  
  
Esempio:  
  
```python  
if GumpExists(0xff):  
```  
  
### InGump  
  
Sintassi del comando:  
  
**Boolean InGump(UInt32, System.String)**  
  
#### Parametri  
* gumpid: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* text: Valore stringa: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Cerca un determinato testo in un Gump**  
  
Esempio:  
  
```python  
if InGump(0xf00f, "lethal darts"):  
```  
  
### MessagePrompt  
  
Sintassi del comando:  
  
**System.ValueTuple`2[System.Boolean,System.String] MessagePrompt(System.String, System.String, Boolean)**  
  
#### Parametri  
* message: Valore stringa: vedere la descrizione per l'utilizzo.  
* initialtext: Valore stringa: vedere la descrizione per l'utilizzo. (Opzionale)  
* closable: Valore True/False, vedere la descrizione per l'uso. (Opzionale)  
  
Descrizione:  
  
**Displays an ingame gump prompting for a message**  
  
Esempio:  
  
```python  
res, name = MessagePrompt("Enter Name?", "Whiskers")

if res:
 Rename(0xc1b, name)  
```  
  
### OpenGuildGump  
  
Sintassi del comando:  
  
**Void OpenGuildGump()**  
  
Descrizione:  
  
**Apre il Gump di gilda**  
  
Esempio:  
  
```python  
OpenGuildGump()  
```  
  
### OpenQuestsGump  
  
Sintassi del comando:  
  
**Void OpenQuestsGump()**  
  
Descrizione:  
  
**Apre il Gump quests**  
  
Esempio:  
  
```python  
OpenQuestsGump()  
```  
  
### OpenVirtueGump  
  
Sintassi del comando:  
  
**Void OpenVirtueGump(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Opens the Virtue gump of the given serial/alias (defaults to current player)**  
  
Esempio:  
  
```python  
OpenVirtueGump("enemy")  
```  
  
### ReplyGump  
  
Sintassi del comando:  
  
**Void ReplyGump(UInt32, Int32, Int32[])**  
  
#### Parametri  
* gumpid: ID oggetto o ID grafico tipo 0x3db.  
* buttonid: ID tasto Gump.  
* switches: Valore intero: vedere la descrizione per l'utilizzo. (Opzionale)  
  
Descrizione:  
  
**Seleziona un opzione nel Gump, i parametri sono gumpID e buttonID**  
  
Esempio:  
  
```python  
ReplyGump(0xff, 0)  
```  
  
### WaitForGump  
  
Sintassi del comando:  
  
**Boolean WaitForGump(UInt32, Int32)**  
  
#### Parametri  
* gumpid: ID oggetto o ID grafico tipo 0x3db. (Opzionale)  
* timeout: Timeout specificato in millisecondi. (Opzionale)  
  
Descrizione:  
  
**Attendi finche le propietà del Gump vengono caricate completamente**  
  
Esempio:  
  
```python  
WaitForGump(0xff, 5000)  
```  
  



