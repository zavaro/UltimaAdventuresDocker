# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 속성  
### Property  
  
메서드 시그니처:  
  
**Boolean Property(System.Object, System.String)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* value: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**텍스트가  항목 속성에 표시됩니다.**  
  
예시:  
  
```python  
if Property("item", "Defense Chance Increase"):  
```  
  
### PropertyValue  
  
메서드 시그니처:  
  
**T PropertyValue[T](System.Object, System.String, Int32)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* property: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
* argument: 정수 값 - 사용 방법에 대한 설명을 보세요. (옵션)  
  
설명:  
  
**속성 이름의 값을 갖습니다.**  
  
예시:  
  
```python  
val = PropertyValue[int]("backpack", "Contents")  
```  
  
### WaitForProperties  
  
메서드 시그니처:  
  
**Boolean WaitForProperties(System.Object, Int32)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* timeout: milliseconds 지정된 시간초과됨.  
  
설명:  
  
**항목 특성이 수신 될 때까지 기다립니다.**  
  
예시:  
  
```python  
WaitForProperties("backpack", 5000)  
```  
  



