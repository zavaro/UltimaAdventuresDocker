# ClassicAssist Macro Commands  
Generated on 12/7/2020 6:04:46 AM  
Version: 0.3.156.250  
  
## Spells  
### Cast  
  
Method Signature:  
  
**Void Cast(System.String)**  
  
#### Parameters  
* name: Spell name.  
  
Description:  
  
**Cast the given named spell and automatically target given object.**  
  
Example:  
  
```python  
Cast("Recall", "runebook")  
```  
  
### Cast  
  
Method Signature:  
  
**Boolean Cast(System.String, System.Object)**  
  
#### Parameters  
* name: Spell name.  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Description:  
  
**Cast the given named spell and automatically target given object.**  
  
Example:  
  
```python  
Cast("Recall", "runebook")  
```  
  
### InterruptSpell  
  
Method Signature:  
  
**Void InterruptSpell()**  
  
Description:  
  
**Attempts to interrupt spell by lifting an item briefly.**  
  
Example:  
  
```python  
InterruptSpell()  
```  
  



