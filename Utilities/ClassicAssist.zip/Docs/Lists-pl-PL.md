# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Listy  
### ClearList  
  
Sygnatura metody:  
  
**Void ClearList(System.String)**  
  
#### Parametry  
* listname: Nazwa listy.  
  
Opis:  
  
**Czyści elementy listy.**  
  
Przykład:  
  
```python  
ClearList("list")  
```  
  
### CreateList  
  
Sygnatura metody:  
  
**Void CreateList(System.String)**  
  
#### Parametry  
* listname: Nazwa listy.  
  
Opis:  
  
**Tworzy liste o podanej nazwie. Jeśli taka lista istnieje - jest nadpisywana.**  
  
Przykład:  
  
```python  
CreateList("list")  
```  
  
### GetList  
  
Sygnatura metody:  
  
**Int32[] GetList(System.String)**  
  
#### Parametry  
* listname: Nazwa listy.  
  
Opis:  
  
**Zwraca wszystkie elementy listy, do używania wraz z pętlami itd.**  
  
Przykład:  
  
```python  
GetList("list")  
```  
  
### InList  
  
Sygnatura metody:  
  
**Boolean InList(System.String, Int32)**  
  
#### Parametry  
* listname: Nazwa listy.  
* value: Zmianna typu integer - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Sprwadza, czy lista zawiera podany element.**  
  
Przykład:  
  
```python  
if InList("shmoo", 1):  
```  
  
### List  
  
Sygnatura metody:  
  
**Int32 List(System.String)**  
  
#### Parametry  
* listname: Nazwa listy.  
  
Opis:  
  
**Zwraca liczbę elementów w liście.**  
  
Przykład:  
  
```python  
if List("list") < 5:  
```  
  
### ListExists  
  
Sygnatura metody:  
  
**Boolean ListExists(System.String)**  
  
#### Parametry  
* listname: Nazwa listy.  
  
Opis:  
  
**Zwraca "true" jeśli lista istnieje, "false" jeśli nie istnieje.**  
  
Przykład:  
  
```python  
if ListExists("list"):  
```  
  
### PopList  
  
Sygnatura metody:  
  
**Int32 PopList(System.String, System.String)**  
  
#### Parametry  
* listname: Nazwa listy.  
* elementvalue: Element value to remove from list, or 'front' to remove the first item, or 'back' to remove last entry, default 'back'. (Opcjonalny)  
  
Opis:  
  
**Remove elements from a list, returns the number of elements removed**  
  
Przykład:  
  
```python  
CreateList("hippies")
PushList("hippies", 1)
PushList("hippies", 2)
PushList("hippies", 3)

PopList("hippies", "front") # Removes 1
PopList("hippies", "back") # Removes 3
PopList("hippies", "2") # Removes any 2's that exist in the list


for x in GetList("hippies"):
 print x # Never reached because list is empty
  
```  
  
### PushList  
  
Sygnatura metody:  
  
**Void PushList(System.String, Int32)**  
  
#### Parametry  
* listname: Nazwa listy.  
* value: Zmianna typu integer - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Dodaje element na koniec listy. Polecenie utworzy listę jeśli nie istnieje.**  
  
Przykład:  
  
```python  
PushList("list", 1)  
```  
  
### RemoveList  
  
Sygnatura metody:  
  
**Void RemoveList(System.String)**  
  
#### Parametry  
* listname: Nazwa listy.  
  
Opis:  
  
**Usuwa listę o podanej nazwie.**  
  
Przykład:  
  
```python  
RemoveList("list")  
```  
  



