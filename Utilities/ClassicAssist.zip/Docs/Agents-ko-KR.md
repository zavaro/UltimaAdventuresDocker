# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 에이전트  
### Counter  
  
메서드 시그니처:  
  
**Int32 Counter(System.String)**  
  
#### 파라미터  
* name: 에이전트 항목 이름.  
  
설명:  
  
**주어진 카운터 에이전트의 수를 반환합니다. **  
  
예시:  
  
```python  
Counter("bm")  
```  
  
### Dress  
  
메서드 시그니처:  
  
**Void Dress(System.String)**  
  
#### 파라미터  
* name: 에이전트 항목 이름. (옵션)  
  
설명:  
  
**특정된 드레스 에이전트의 모든 아이템을 입습니다.**  
  
예시:  
  
```python  
Dress("Dress-1")  
```  
  
### DressConfig  
  
메서드 시그니처:  
  
**Void DressConfig()**  
  
설명:  
  
**장착된 모든 아이템을 게임종료시 지속되지 않는 임시 목록에 추가**  
  
예시:  
  
```python  
DressConfig()  
```  
  
### Dressing  
  
메서드 시그니처:  
  
**Boolean Dressing()**  
  
설명:  
  
**드레스 에이전트 장비장착 유무에 상관 없이 작동합니다.**  
  
예시:  
  
```python  
if Dressing():  
```  
  
### Organizer  
  
메서드 시그니처:  
  
**Void Organizer(System.String, System.Object, System.Object)**  
  
#### 파라미터  
* name: 에이전트 항목 이름.  
* sourcecontainer: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
* destinationcontainer: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**오거나이저 에이전트를 실행합니다.**  
  
예시:  
  
```python  
Organizer("Organizer-1")  
```  
  
### Organizing  
  
메서드 시그니처:  
  
**Boolean Organizing()**  
  
설명:  
  
**오거나이저 에이전트가 작동 여부에 상관 없이 작동합니다.**  
  
예시:  
  
```python  
if Organizing():  
```  
  
### SetAutolootContainer  
  
메서드 시그니처:  
  
**Void SetAutolootContainer(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**Autoloot 에이전트가 대상을 넣을 컨테이너를 지정합니다.**  
  
예시:  
  
```python  
SetAutolootContainer("backpack")  
```  
  
### SetOrganizerContainers  
  
메서드 시그니처:  
  
**Void SetOrganizerContainers(System.String, System.Object, System.Object)**  
  
#### 파라미터  
* entryname: 에이전트 항목 이름.  
* sourcecontainer: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
* destinationcontainer: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**Set the source and destination for the specified Organizer name**  
  
예시:  
  
```python  
SetOrganizerContainers("Organizer-1", "backpack", "bank")  
```  
  
### Undress  
  
메서드 시그니처:  
  
**Void Undress(System.String)**  
  
#### 파라미터  
* name: 에이전트 항목 이름.  
  
설명:  
  
**모든 장비를 장착 해지합니다.**  
  
예시:  
  
```python  
Undress("Dress-1")  
```  
  



