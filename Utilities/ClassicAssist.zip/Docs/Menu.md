# ClassicAssist Macro Commands  
Generated on 12/7/2020 6:04:46 AM  
Version: 0.3.156.250  
  
## Menu  
### CloseMenu  
  
Method Signature:  
  
**Void CloseMenu(Int32)**  
  
#### Parameters  
* gumpid: ItemID / Graphic such as  0x3db.  
  
Description:  
  
**Closes the specified menu id**  
  
Example:  
  
```python  
CloseMenu(0x1d1)  
```  
  



