# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Gumps  
### CloseGump  
  
Sygnatura metody:  
  
**Void CloseGump(Int32)**  
  
#### Parametry  
* serial: Numer serial dla entity, np. 0xf00f0x0.  
  
Opis:  
  
**Zamyka podanego gumpa.**  
  
Przykład:  
  
```python  
CloseGump(0x454ddef)  
```  
  
### ConfirmPrompt  
  
Sygnatura metody:  
  
**Boolean ConfirmPrompt(System.String, Boolean)**  
  
Opis:  
  
**Displays an ingame prompt with the specified message, returns True if Okay was pressed, False if not.**  
  
Przykład:  
  
```python  
res = ConfirmPrompt("Play macro?")

if res:
 PlayMacro("Macro")  
```  
  
### GumpExists  
  
Sygnatura metody:  
  
**Boolean GumpExists(UInt32)**  
  
Opis:  
  
**Sprawdza czy gump istnieje czy nie**  
  
Przykład:  
  
```python  
if GumpExists(0xff):  
```  
  
### InGump  
  
Sygnatura metody:  
  
**Boolean InGump(UInt32, System.String)**  
  
#### Parametry  
* gumpid: An entity serial in integer or hex format, or an alias string such as "self".  
* text: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Sprawdza czy podany tekst występuje w gumpie**  
  
Przykład:  
  
```python  
if InGump(0xf00f, "lethal darts"):  
```  
  
### MessagePrompt  
  
Sygnatura metody:  
  
**System.ValueTuple`2[System.Boolean,System.String] MessagePrompt(System.String, System.String, Boolean)**  
  
#### Parametry  
* message: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
* initialtext: Zmienna typu string - zobacz opis, aby zobaczyć użycie. (Opcjonalny)  
* closable: Wartość True/False - zobacz opis, aby zobaczyć użycie. (Opcjonalny)  
  
Opis:  
  
**Displays an ingame gump prompting for a message**  
  
Przykład:  
  
```python  
res, name = MessagePrompt("Enter Name?", "Whiskers")

if res:
 Rename(0xc1b, name)  
```  
  
### OpenGuildGump  
  
Sygnatura metody:  
  
**Void OpenGuildGump()**  
  
Opis:  
  
**Otwiera gump Gildii.**  
  
Przykład:  
  
```python  
OpenGuildGump()  
```  
  
### OpenQuestsGump  
  
Sygnatura metody:  
  
**Void OpenQuestsGump()**  
  
Opis:  
  
**Otwiera ugump Questów.**  
  
Przykład:  
  
```python  
OpenQuestsGump()  
```  
  
### OpenVirtueGump  
  
Sygnatura metody:  
  
**Void OpenVirtueGump(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Otwiera gump Cnót podanego serialu/aliasu (domyślnie wybrana jest postać gracza).**  
  
Przykład:  
  
```python  
OpenVirtueGump("enemy")  
```  
  
### ReplyGump  
  
Sygnatura metody:  
  
**Void ReplyGump(UInt32, Int32, Int32[])**  
  
#### Parametry  
* gumpid: ItemId/Grafika np. 0x3db.  
* buttonid: ID przycisku Gump.  
* switches: Zmianna typu integer - zobacz opis, aby zobaczyć użycie. (Opcjonalny)  
  
Opis:  
  
**Wysyła polecenie ponownego wciśnięcia przycisku. Parametrami są gumpID i buttonID**  
  
Przykład:  
  
```python  
ReplyGump(0xff, 0)  
```  
  
### WaitForGump  
  
Sygnatura metody:  
  
**Boolean WaitForGump(UInt32, Int32)**  
  
#### Parametry  
* gumpid: ItemId/Grafika np. 0x3db. (Opcjonalny)  
* timeout: Timeout w milisekundach. (Opcjonalny)  
  
Opis:  
  
**Czeka na pakiet gumpa, opcjonalne parametry to gumpID oraz timeout.**  
  
Przykład:  
  
```python  
WaitForGump(0xff, 5000)  
```  
  



