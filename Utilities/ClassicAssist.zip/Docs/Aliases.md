# ClassicAssist Macro Commands  
Generated on 12/7/2020 6:04:46 AM  
Version: 0.3.156.250  
  
## Aliases  
### FindAlias  
  
Method Signature:  
  
**Boolean FindAlias(System.String)**  
  
#### Parameters  
* aliasname: Alias name.  
  
Description:  
  
**Returns true if alias serial can be found on screen, false if not.**  
  
Example:  
  
```python  
if FindAlias("mount"):  
```  
  
### GetAlias  
  
Method Signature:  
  
**Int32 GetAlias(System.String)**  
  
#### Parameters  
* aliasname: Alias name.  
  
Description:  
  
**Gets the value of the given alias name.**  
  
Example:  
  
```python  
GetAlias("mount")  
```  
  
### PromptAlias  
  
Method Signature:  
  
**Int32 PromptAlias(System.String)**  
  
#### Parameters  
* aliasname: Alias name.  
  
Description:  
  
**Prompt with an in-game target cursor to supply value for given alias name.**  
  
Example:  
  
```python  
PromptAlias("mount")  
```  
  
### SetAlias  
  
Method Signature:  
  
**Void SetAlias(System.String, System.Object)**  
  
#### Parameters  
* aliasname: Alias name.  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Description:  
  
**Sets the value of the given alias name.**  
  
Example:  
  
```python  
SetAlias("mount", 0x40000001)  
```  
  
### SetMacroAlias  
  
Method Signature:  
  
**Void SetMacroAlias(System.String, System.Object)**  
  
#### Parameters  
* aliasname: Alias name.  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Description:  
  
**Sets the value of the given alias name, alias is valid only in the current macro.**  
  
Example:  
  
```python  
SetMacroAlias("mount", 0x40000001)  
```  
  
### UnsetAlias  
  
Method Signature:  
  
**Void UnsetAlias(System.String)**  
  
#### Parameters  
* aliasname: Alias name.  
  
Description:  
  
**Removes the alias name given.**  
  
Example:  
  
```python  
UnsetAlias("mount")  
```  
  



