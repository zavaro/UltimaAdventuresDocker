# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Liste  
### ClearList  
  
Sintassi del comando:  
  
**Void ClearList(System.String)**  
  
#### Parametri  
* listname: Nome Lista.  
  
Descrizione:  
  
**Pulisci la lista desiderata**  
  
Esempio:  
  
```python  
ClearList("list")  
```  
  
### CreateList  
  
Sintassi del comando:  
  
**Void CreateList(System.String)**  
  
#### Parametri  
* listname: Nome Lista.  
  
Descrizione:  
  
**Crea una lista. Se già esiste, viene sovrascritta**  
  
Esempio:  
  
```python  
CreateList("list")  
```  
  
### GetList  
  
Sintassi del comando:  
  
**Int32[] GetList(System.String)**  
  
#### Parametri  
* listname: Nome Lista.  
  
Descrizione:  
  
**Risulta la matrice di tutte le voci di una lista, da utilizzare con For, Loop, etc.**  
  
Esempio:  
  
```python  
GetList("list")  
```  
  
### InList  
  
Sintassi del comando:  
  
**Boolean InList(System.String, Int32)**  
  
#### Parametri  
* listname: Nome Lista.  
* value: Valore intero: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Controlla se in una lista è presente un dato elemento**  
  
Esempio:  
  
```python  
if InList("shmoo", 1):  
```  
  
### List  
  
Sintassi del comando:  
  
**Int32 List(System.String)**  
  
#### Parametri  
* listname: Nome Lista.  
  
Descrizione:  
  
**Risulta il numero degli elementi presenti in una lista**  
  
Esempio:  
  
```python  
if List("list") < 5:  
```  
  
### ListExists  
  
Sintassi del comando:  
  
**Boolean ListExists(System.String)**  
  
#### Parametri  
* listname: Nome Lista.  
  
Descrizione:  
  
**Risulta se una lista esiste**  
  
Esempio:  
  
```python  
if ListExists("list"):  
```  
  
### PopList  
  
Sintassi del comando:  
  
**Int32 PopList(System.String, System.String)**  
  
#### Parametri  
* listname: Nome Lista.  
* elementvalue: Element value to remove from list, or 'front' to remove the first item, or 'back' to remove last entry, default 'back'. (Opzionale)  
  
Descrizione:  
  
**Remove elements from a list, returns the number of elements removed**  
  
Esempio:  
  
```python  
CreateList("hippies")
PushList("hippies", 1)
PushList("hippies", 2)
PushList("hippies", 3)

PopList("hippies", "front") # Removes 1
PopList("hippies", "back") # Removes 3
PopList("hippies", "2") # Removes any 2's that exist in the list


for x in GetList("hippies"):
 print x # Never reached because list is empty
  
```  
  
### PushList  
  
Sintassi del comando:  
  
**Void PushList(System.String, Int32)**  
  
#### Parametri  
* listname: Nome Lista.  
* value: Valore intero: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Inserisce un valore alla fine di una lista, crea la lista se non esiste**  
  
Esempio:  
  
```python  
PushList("list", 1)  
```  
  
### RemoveList  
  
Sintassi del comando:  
  
**Void RemoveList(System.String)**  
  
#### Parametri  
* listname: Nome Lista.  
  
Descrizione:  
  
**Rimuove la lista desiderata**  
  
Esempio:  
  
```python  
RemoveList("list")  
```  
  



