# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Cel  
### CancelTarget  
  
Sygnatura metody:  
  
**Void CancelTarget()**  
  
Opis:  
  
**Anuluje istniejący kursor celu.**  
  
Przykład:  
  
```python  
CancelTarget()  
```  
  
### ClearTargetQueue  
  
Sygnatura metody:  
  
**Void ClearTargetQueue()**  
  
Opis:  
  
**Czyści kolejkę celów kiedy włączone jet kolejkowanie last target/target self.**  
  
Przykład:  
  
```python  
ClearTargetQueue()  
```  
  
### GetEnemy  
  
Sygnatura metody:  
  
**Boolean GetEnemy(System.Collections.Generic.IEnumerable`1[System.String], System.String, System.String, System.String)**  
  
#### Parametry  
* notorieties: Zobacz również: {0}. Zobacz też: [TargetNotoriety](#TargetNotoriety)  
* bodytype: Zobacz również: {0}. (Opcjonalny) Zobacz też: [TargetBodyType](#TargetBodyType)  
* distance: Zobacz również: {0}. (Opcjonalny) Zobacz też: [TargetDistance](#TargetDistance)  
* infliction: Zobacz również: {0}. (Opcjonalny) Zobacz też: [TargetInfliction](#TargetInfliction)  
  
Opis:  
  
**Pobranie wartości obiektu mobile oraz ustawienie go jako aliasu wroga ("enemy").**  
  
Przykład:  
  
```python  
#get murderer
GetEnemy(['Murderer'])
#get closest murderer, any body type
GetEnemy(['Murderer'], 'Any', 'Closest')
#get next any notoriety, humanoid or transformation - unmounted
GetEnemy(['Any'], 'Both', 'Next', 'Unmounted')  
```  
  
### GetFriend  
  
Sygnatura metody:  
  
**Boolean GetFriend(System.Collections.Generic.IEnumerable`1[System.String], System.String, System.String, System.String)**  
  
#### Parametry  
* notorieties: Zobacz również: {0}. Zobacz też: [TargetNotoriety](#TargetNotoriety)  
* bodytype: Zobacz również: {0}. (Opcjonalny) Zobacz też: [TargetBodyType](#TargetBodyType)  
* distance: Zobacz również: {0}. (Opcjonalny) Zobacz też: [TargetDistance](#TargetDistance)  
* infliction: Zobacz również: {0}. (Opcjonalny) Zobacz też: [TargetInfliction](#TargetInfliction)  
  
Opis:  
  
**Pobranie wartości obiektu mobile oraz ustawienie go jako aliasu przyjaciela ("friend").**  
  
Przykład:  
  
```python  
GetFriend(["Murderer"])  
```  
  
### GetFriendListOnly  
  
Sygnatura metody:  
  
**Boolean GetFriendListOnly(System.String, System.String, System.String)**  
  
#### Parametry  
* distance: Zobacz również: {0}. (Opcjonalny) Zobacz też: [TargetDistance](#TargetDistance)  
* targetinfliction: Zobacz również: {0}. (Opcjonalny) Zobacz też: [TargetInfliction](#TargetInfliction)  
* bodytype: Zobacz również: {0}. (Opcjonalny) Zobacz też: [TargetBodyType](#TargetBodyType)  
  
Opis:  
  
**Pobiera przyjaciela tylko z listy przyjaciół. Możliwe parametry dystansu od przyjaciela: "Closest", "Nearest", "Next".**  
  
Przykład:  
  
```python  
GetFriendListOnly("Closest")  
```  
  
### SetEnemy  
  
Sygnatura metody:  
  
**Void SetEnemy(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Ustawia przeciwnika dla podanego serialu lub aliasu.**  
  
Przykład:  
  
```python  
SetEnemy("mount")  
```  
  
### SetFriend  
  
Sygnatura metody:  
  
**Void SetFriend(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Ustawia przyjaciela dla podanego serialu lub aliasu.**  
  
Przykład:  
  
```python  
SetFriend("mount")  
```  
  
### SetLastTarget  
  
Sygnatura metody:  
  
**Void SetLastTarget(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Ustawia Last Target na wskazany serial lub alias.**  
  
Przykład:  
  
```python  
SetLastTarget("mount")  
```  
  
### Target  
  
Sygnatura metody:  
  
**Void Target(System.Object, Boolean, Boolean)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* checkrange: Nie zdefiniowano - zobacz opis, aby zobaczyć użycie. (Opcjonalny)  
* usequeue: Nie zdefiniowano - zobacz opis, aby zobaczyć użycie. (Opcjonalny)  
  
Opis:  
  
**Wybiera za cel podany obiekt (parametr może być serialem lub aliasem).**  
  
Przykład:  
  
```python  
Target("self")  
```  
  
### TargetByResource  
  
Sygnatura metody:  
  
**Void TargetByResource(System.Object, System.String)**  
  
#### Parametry  
* toolobj: An entity serial in integer or hex format, or an alias string such as "self".  
* resourcetype: Zmienna typu string - zobacz opis, aby zobaczyć użycie. Zobacz też: [TargetResourceType](#TargetResourceType)  
  
Opis:  
  
**Używa narzędzi oraz celów o podanym typie (wymaga supportowania serwera (OSI/ServUO)).**  
  
Przykład:  
  
```python  
TargetByResource('pickaxe', 'Ore')  
```  
  
### TargetExists  
  
Sygnatura metody:  
  
**Boolean TargetExists(System.String)**  
  
#### Parametry  
* targetexiststype: Target type - "harmful", "beneficial", or "neutral". (Opcjonalny) Zobacz też: [TargetExistsType](#TargetExistsType)  
  
Opis:  
  
**Zwraca "true" w przypadku kiedy pokazywany jest kursor wskazywania a status gracza odpowiada podanej wartości. Możliwe parametry: "Any", "Beneficial", "Harmful", "Neutral". Domyśla wartość to "Any".**  
  
Przykład:  
  
```python  
if TargetExists("Harmful"):  
```  
  
### TargetGround  
  
Sygnatura metody:  
  
**Void TargetGround(System.Object, Int32, Int32)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek). (Opcjonalny)  
* range: Odległość, np. 10. (Opcjonalny)  
  
Opis:  
  
**Wybiera za cel wskazany typ przedmiotu na ziemi. Opcjonalnym parameternem jet dystans.**  
  
Przykład:  
  
```python  
TargetGround(0x190, -1, 10)  
```  
  
### TargetTileOffset  
  
Sygnatura metody:  
  
**Void TargetTileOffset(Int32, Int32, Int32, Int32)**  
  
#### Parametry  
* xoffset: Odstęp dla koordynaty X.  
* yoffset: Odstęp dla koordynaty Y.  
* zoffset: Odstęp dla koordynaty Y.  
* itemid: ItemId/Grafika np. 0x3db. (Opcjonalny)  
  
Opis:  
  
**Ustawia za cel podane tile w podanym odstępie relatywnie do postaci gracza.**  
  
Przykład:  
  
```python  
#Targets the tile at the current Y coordinate + 1
TargetTileOffset(0, 1, 0)  
```  
  
### TargetTileOffsetResource  
  
Sygnatura metody:  
  
**Void TargetTileOffsetResource(Int32, Int32, Int32, Int32)**  
  
#### Parametry  
* xoffset: Odstęp dla koordynaty X.  
* yoffset: Odstęp dla koordynaty Y.  
* zoffset: Odstęp dla koordynaty Y.  
* itemid: ItemId/Grafika np. 0x3db. (Opcjonalny)  
  
Opis:  
  
**Targets the tile at the given offsets relative to the player (automatically targeting trees/cave tiles/water if present)**  
  
Przykład:  
  
```python  
TargetTileOffsetResource(0, -1, 0)  
```  
  
### TargetTileRelative  
  
Sygnatura metody:  
  
**Void TargetTileRelative(System.Object, Int32, Boolean, Int32)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* distance: Zmianna typu integer - zobacz opis, aby zobaczyć użycie.  
* reverse: Wartość True/False - zobacz opis, aby zobaczyć użycie. (Opcjonalny)  
* itemid: ItemId/Grafika np. 0x3db. (Opcjonalny)  
  
Opis:  
  
**Wybiera za cel tile we wskazanym dystansie relatywnie do podanego aliasu/seriala. Opcjonalnie można podać boolean dla odwrotnego zachowania komendy.**  
  
Przykład:  
  
```python  
TargetTileRelative("self", 1, False)  
```  
  
### TargetType  
  
Sygnatura metody:  
  
**Void TargetType(System.Object, Int32, Int32)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek). (Opcjonalny)  
* range: Odległość, np. 10. (Opcjonalny)  
  
Opis:  
  
**Używa podanego typu w pleaku gracza. Opcjonalnymi parametrami są kolor i poziom szukania.**  
  
Przykład:  
  
```python  
TargetType(0xff, 0, 3)  
```  
  
### TargetXYZ  
  
Sygnatura metody:  
  
**Void TargetXYZ(Int32, Int32, Int32, Int32)**  
  
#### Parametry  
* x: Koordynata X.  
* y: Koordynata Y.  
* z: Koordynata Z.  
* itemid: ItemId/Grafika np. 0x3db. (Opcjonalny)  
  
Opis:  
  
**Wybiera za cel ziemie o podanych koordynatach.**  
  
Przykład:  
  
```python  
TargetXYZ(1000, 1000, 0)  
```  
  
### WaitForTarget  
  
Sygnatura metody:  
  
**Boolean WaitForTarget(Int32)**  
  
#### Parametry  
* timeout: Timeout w milisekundach. (Opcjonalny)  
  
Opis:  
  
**Czeka na pakiet z wybranym celem od serwera. Opcjonalnie można podać timeout (domyślnie 5000 milisekund).**  
  
Przykład:  
  
```python  
WaitForTarget(5000)  
```  
  
### WaitForTargetOrFizzle  
  
Sygnatura metody:  
  
**Boolean WaitForTargetOrFizzle(Int32)**  
  
#### Parametry  
* timeout: Timeout w milisekundach.  
  
Opis:  
  
**Czeka podaną ilość czasu na kursor szukania celu lub niepowodzenie jego rzucania.**  
  
Przykład:  
  
```python  
WaitForTargetOrFizzle(5000)  
```  
  
### WaitingForTarget  
  
Sygnatura metody:  
  
**Boolean WaitingForTarget()**  
  
Opis:  
  
**Zwraca "true" jeśli core czeka wewnętrznie na odpowiedź o wybranym celu gracza z serwera.**  
  
Przykład:  
  
```python  
if WaitingForTarget():  
```  
  



## Typy  
### TargetBodyType  
* Any  
* Humanoid  
* Transformation  
* Both  
  
### TargetDistance  
* Next  
* Nearest  
* Closest  
* Previous  
  
### TargetExistsType  
* Any  
* Beneficial  
* Harmful  
* Neutral  
  
### TargetInfliction  
* Any  
* Lowest  
* Poisoned  
* Mortaled  
* Paralyzed  
* Dead  
* Unmounted  
  
### TargetNotoriety  
* None  
* Innocent  
* Criminal  
* Enemy  
* Murderer  
* Friend  
* Gray  
* Any  
  
### TargetResourceType  
* Ore  
* Sand  
* Wood  
* Graves  
* Red_Mushrooms  
  
