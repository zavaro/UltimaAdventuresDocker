# ClassicAssist Macro Commands  
Generated on 12/7/2020 6:04:46 AM  
Version: 0.3.156.250  
  
## Gumps  
### CloseGump  
  
Method Signature:  
  
**Void CloseGump(Int32)**  
  
#### Parameters  
* serial: An entity serial such as 0xf00ff00f.  
  
Description:  
  
**Close a specified gump serial**  
  
Example:  
  
```python  
CloseGump(0x454ddef)  
```  
  
### ConfirmPrompt  
  
Method Signature:  
  
**Boolean ConfirmPrompt(System.String, Boolean)**  
  
Description:  
  
**Displays an ingame prompt with the specified message, returns True if Okay was pressed, False if not.**  
  
Example:  
  
```python  
res = ConfirmPrompt("Play macro?")

if res:
 PlayMacro("Macro")  
```  
  
### GumpExists  
  
Method Signature:  
  
**Boolean GumpExists(UInt32)**  
  
Description:  
  
**Checks if a gump id exists or not.**  
  
Example:  
  
```python  
if GumpExists(0xff):  
```  
  
### InGump  
  
Method Signature:  
  
**Boolean InGump(UInt32, System.String)**  
  
#### Parameters  
* gumpid: An entity serial in integer or hex format, or an alias string such as "self".  
* text: String value - See description for usage.  
  
Description:  
  
**Check for a text in gump.**  
  
Example:  
  
```python  
if InGump(0xf00f, "lethal darts"):  
```  
  
### MessagePrompt  
  
Method Signature:  
  
**System.ValueTuple`2[System.Boolean,System.String] MessagePrompt(System.String, System.String, Boolean)**  
  
#### Parameters  
* message: String value - See description for usage.  
* initialtext: String value - See description for usage. (Optional)  
* closable: True/False value, see description for usage. (Optional)  
  
Description:  
  
**Displays an ingame gump prompting for a message**  
  
Example:  
  
```python  
res, name = MessagePrompt("Enter Name?", "Whiskers")

if res:
 Rename(0xc1b, name)  
```  
  
### OpenGuildGump  
  
Method Signature:  
  
**Void OpenGuildGump()**  
  
Description:  
  
**Opens the Guild gump**  
  
Example:  
  
```python  
OpenGuildGump()  
```  
  
### OpenQuestsGump  
  
Method Signature:  
  
**Void OpenQuestsGump()**  
  
Description:  
  
**Opens the Quests gump**  
  
Example:  
  
```python  
OpenQuestsGump()  
```  
  
### OpenVirtueGump  
  
Method Signature:  
  
**Void OpenVirtueGump(System.Object)**  
  
#### Parameters  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Optional)  
  
Description:  
  
**Opens the Virtue gump of the given serial/alias (defaults to current player)**  
  
Example:  
  
```python  
OpenVirtueGump("enemy")  
```  
  
### ReplyGump  
  
Method Signature:  
  
**Void ReplyGump(UInt32, Int32, Int32[])**  
  
#### Parameters  
* gumpid: ItemID / Graphic such as  0x3db.  
* buttonid: Gump button ID.  
* switches: Integer value - See description for usage. (Optional)  
  
Description:  
  
**Sends a button reply to server gump, parameters are gumpID and buttonID.**  
  
Example:  
  
```python  
ReplyGump(0xff, 0)  
```  
  
### WaitForGump  
  
Method Signature:  
  
**Boolean WaitForGump(UInt32, Int32)**  
  
#### Parameters  
* gumpid: ItemID / Graphic such as  0x3db. (Optional)  
* timeout: Timeout specified in milliseconds. (Optional)  
  
Description:  
  
**Pauses until incoming gump packet is received, optional paramters of gump ID and timeout**  
  
Example:  
  
```python  
WaitForGump(0xff, 5000)  
```  
  



