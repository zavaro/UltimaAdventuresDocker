# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Proprietà Oggetti  
### Property  
  
Sintassi del comando:  
  
**Boolean Property(System.Object, System.String)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* value: Valore stringa: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Risulta se la propietà desiderata è presente in un oggetto (alias)**  
  
Esempio:  
  
```python  
if Property("item", "Defense Chance Increase")  
```  
  
### PropertyValue  
  
Sintassi del comando:  
  
**T PropertyValue[T](System.Object, System.String, Int32)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* property: Valore stringa: vedere la descrizione per l'utilizzo.  
* argument: Valore intero: vedere la descrizione per l'utilizzo. (Opzionale)  
  
Descrizione:  
  
**Risulta il valore della proprietà desiderata. Indice argomento opzionale (int, str).**  
  
Esempio:  
  
```python  
val = PropertyValue[int]("backpack", "Contents")  
```  
  
### WaitForProperties  
  
Sintassi del comando:  
  
**Boolean WaitForProperties(System.Object, Int32)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* timeout: Timeout specificato in millisecondi.  
  
Descrizione:  
  
**Attendi che le propietà di un oggetto siano completamente caricate**  
  
Esempio:  
  
```python  
WaitForProperties("backpack", 5000)  
```  
  



