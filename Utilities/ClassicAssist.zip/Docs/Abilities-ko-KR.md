# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 특수기  
### ActiveAbility  
  
메서드 시그니처:  
  
**Boolean ActiveAbility()**  
  
설명:  
  
**Returns True if either the primary or secondary ability is set**  
  
예시:  
  
```python  
if not ActiveAbility():
 SetAbility("primary", "on")  
```  
  
### ClearAbility  
  
메서드 시그니처:  
  
**Void ClearAbility()**  
  
설명:  
  
**무기 특수기 취소**  
  
예시:  
  
```python  
ClearAbility()  
```  
  
### Fly  
  
메서드 시그니처:  
  
**Void Fly()**  
  
설명:  
  
**(가고일)아직 비행모드가 아니라면  비행모드가 시작됩니다.**  
  
예시:  
  
```python  
Fly()  
```  
  
### Flying  
  
메서드 시그니처:  
  
**Boolean Flying(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**모빌이 현재 비행모드라면 True 값을 갖습니다**  
  
예시:  
  
```python  
if Flying("self"):  
```  
  
### Land  
  
메서드 시그니처:  
  
**Void Land()**  
  
설명:  
  
**(가고일)현재 비행모드라면 비행모드를 중지합니다.**  
  
예시:  
  
```python  
Land()  
```  
  
### SetAbility  
  
메서드 시그니처:  
  
**Void SetAbility(System.String, System.String)**  
  
#### 파라미터  
* ability: 특수기 이름, "첫번째","두번째","마비" 또는 "무장해제".  
* onoff: "on" or "off". (옵션)  
  
설명:  
  
**무기 특수기 설정, 매개변수 "첫번째" / "두번째".**  
  
예시:  
  
```python  
SetAbility("primary")  
```  
  



