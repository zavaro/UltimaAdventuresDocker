# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 메인  
### DisplayQuestPointer  
  
메서드 시그니처:  
  
**Void DisplayQuestPointer(Int32, Int32, Boolean)**  
  
#### 파라미터  
* x: X 좌표.  
* y: Y 좌표.  
* enabled: Ture/False 값, 사용 방법에 대한 설명을 보세요. (옵션)  
  
설명:  
  
**Display quest arrow pointer to specified coordinates**  
  
예시:  
  
```python  
# add pointer
DisplayQuestPointer(1000, 1000, True)
Pause(2000)
# remove pointer
DisplayQuestPointer(1000, 1000, False)  
```  
  
### HideEntity  
  
메서드 시그니처:  
  
**Void HideEntity(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**Remove an item/mobile from the screen**  
  
예시:  
  
```python  
ClearIgnoreList()
# Hide all corpses on screen
while FindType(0x2006):
 HideEntity('found')
 IgnoreObject('found')  
```  
  
### Hotkeys  
  
메서드 시그니처:  
  
**Void Hotkeys(System.String)**  
  
#### 파라미터  
* onoff: "on" or "off". (옵션)  
  
설명:  
  
**핫키를 활성화 / 비활성화합니다.**  
  
예시:  
  
```python  
Hotkeys()  
```  
  
### Info  
  
메서드 시그니처:  
  
**Void Info(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**제공된 시리얼/이름에 대하여 검사기를 표시하고, 매개 변수가 없으면 대상을 묻는 메시지를 표시합니다.**  
  
예시:  
  
```python  
Info("self")  
```  
  
### InvokeVirtue  
  
메서드 시그니처:  
  
**Void InvokeVirtue(System.String)**  
  
#### 파라미터  
* virtue: 문자열 값 - 사용 방법에 대한 설명을 보세요. 참조: [Virtues](#Virtues)  
  
설명:  
  
**미덕을 사용합니다.**  
  
예시:  
  
```python  
InvokeVirtue("Honor")  
```  
  
### MessageBox  
  
메서드 시그니처:  
  
**Void MessageBox(System.String, System.String)**  
  
#### 파라미터  
* title: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
* body: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**제목과 본문이있는 간단한 메시지를 표시합니다.**  
  
예시:  
  
```python  
MessageBox("title", "message")  
```  
  
### Pause  
  
메서드 시그니처:  
  
**Void Pause(Int32)**  
  
#### 파라미터  
* milliseconds: milliseconds 지정된 시간초과됨.  
  
설명:  
  
**일정 시간 동안 실행을 일시 중지합니다.**  
  
예시:  
  
```python  
Pause(1000)  
```  
  
### Playing  
  
메서드 시그니처:  
  
**Boolean Playing(System.String)**  
  
#### 파라미터  
* macroname: 매크로 이름.  
  
설명:  
  
**매크로가 있으면 백그라운드에서 작동됩니다.**  
  
예시:  
  
```python  
if Playing():  
```  
  
### Playing  
  
메서드 시그니처:  
  
**Boolean Playing()**  
  
설명:  
  
**매크로가 있으면 백그라운드에서 작동됩니다.**  
  
예시:  
  
```python  
if Playing():  
```  
  
### PlaySound  
  
메서드 시그니처:  
  
**Void PlaySound(System.Object)**  
  
설명:  
  
**ID 또는 시스템 .wav 파일로 사운드를 재생합니다.**  
  
예시:  
  
```python  
PlaySound("Bike Horn.wav")  
```  
  
### Resync  
  
메서드 시그니처:  
  
**Void Resync()**  
  
설명:  
  
**서버에 재 동기화 요청을 보냅니다.**  
  
예시:  
  
```python  
Resync()  
```  
  
### SetQuietMode  
  
메서드 시그니처:  
  
**Void SetQuietMode(Boolean)**  
  
#### 파라미터  
* onoff: "on" or "off".  
  
설명:  
  
**무음 모드를 설정합니다.**  
  
예시:  
  
```python  
SetQuietMode(True)  
```  
  
### SysMessage  
  
메서드 시그니처:  
  
**Void SysMessage(System.String, Int32)**  
  
#### 파라미터  
* text: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
* hue: 아이탬 색조 또는 모든 값에 -1. (옵션)  
  
설명:  
  
**메시지를 보냅니다.**  
  
예시:  
  
```python  
# default hue
SysMessage("Hello")
# specifying hue
SysMessage("Hello", 35)  
```  
  
### WarMode  
  
메서드 시그니처:  
  
**Void WarMode(System.String)**  
  
#### 파라미터  
* onoff: "on" or "off". (옵션)  
  
설명:  
  
**전쟁 모드 상태, 매개 변수 켜기, 끄기 또는 토글을 설정합니다. 매개 변수를 지정하지 않으면 토글(기본)됩니다.**  
  
예시:  
  
```python  
WarMode("on")  
```  
  



## 타입  
### Virtues  
* None  
* Honor  
* Sacrafice  
* Valor  
* Compassion  
* Honesty  
* Humility  
* Justice  
* Spirituality  
  
