# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Agenci  
### Counter  
  
Sygnatura metody:  
  
**Int32 Counter(System.String)**  
  
#### Parametry  
* name: Nazwa agenta.  
  
Opis:  
  
**Zwraca obecną liczbę z licznika podanego agenta zliczania (Counter Agent).**  
  
Przykład:  
  
```python  
Counter("bm")  
```  
  
### Dress  
  
Sygnatura metody:  
  
**Void Dress(System.String)**  
  
#### Parametry  
* name: Nazwa agenta. (Opcjonalny)  
  
Opis:  
  
**Zakłada wszystkie przedmioty z wybranego agenra ubioru (Dress Agent).**  
  
Przykład:  
  
```python  
Dress("Dress-1")  
```  
  
### DressConfig  
  
Sygnatura metody:  
  
**Void DressConfig()**  
  
Opis:  
  
**Dodaje wszystkie założone przedmioty to temporalnej listy, która nie jest persystentna. Po zamknięciu klienta lista jest niszczona.**  
  
Przykład:  
  
```python  
DressConfig()  
```  
  
### Dressing  
  
Sygnatura metody:  
  
**Boolean Dressing()**  
  
Opis:  
  
**Zwraca "true" jeżeli agent ubioru obecnie wykonuje czynność zakładania/zdejmowania.**  
  
Przykład:  
  
```python  
if Dressing():  
```  
  
### Organizer  
  
Sygnatura metody:  
  
**Void Organizer(System.String, System.Object, System.Object)**  
  
#### Parametry  
* name: Nazwa agenta.  
* sourcecontainer: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
* destinationcontainer: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Wykonuje wybranego agenta organizacji.**  
  
Przykład:  
  
```python  
Organize("Organizer-1")  
```  
  
### Organizing  
  
Sygnatura metody:  
  
**Boolean Organizing()**  
  
Opis:  
  
**Zwraca "true" jeżeli obecnie jest uruchomiony agnet organizacji.**  
  
Przykład:  
  
```python  
if Organizing():  
```  
  
### SetAutolootContainer  
  
Sygnatura metody:  
  
**Void SetAutolootContainer(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Ustawia kontener przechowywania obiektów dla agenta autoloot.**  
  
Przykład:  
  
```python  
SetAutolootContainer("backpack")  
```  
  
### SetOrganizerContainers  
  
Sygnatura metody:  
  
**Void SetOrganizerContainers(System.String, System.Object, System.Object)**  
  
#### Parametry  
* entryname: Nazwa agenta.  
* sourcecontainer: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
* destinationcontainer: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Set the source and destination for the specified Organizer name**  
  
Przykład:  
  
```python  
SetOrganizerContainers("Organizer-1", "backpack", "bank")  
```  
  
### Undress  
  
Sygnatura metody:  
  
**Void Undress(System.String)**  
  
#### Parametry  
* name: Nazwa agenta.  
  
Opis:  
  
**Zdejmij wszystkie przedmioty podanego agenta ubioru.**  
  
Przykład:  
  
```python  
Undress("Dress-1")  
```  
  



