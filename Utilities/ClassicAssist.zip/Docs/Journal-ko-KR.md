# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 저널  
### ClearJournal  
  
메서드 시그니처:  
  
**Void ClearJournal()**  
  
설명:  
  
**모든 저널 텍스트를 삭제합니다.**  
  
예시:  
  
```python  
ClearJournal()  
```  
  
### InJournal  
  
메서드 시그니처:  
  
**Boolean InJournal(System.String, System.String, Int32)**  
  
설명:  
  
**저널의 텍스트 (선택적 소스 이름)를 확인합니다.**  
  
예시:  
  
```python  
if InJournal("town guards", "system"):  
```  
  
### WaitForJournal  
  
메서드 시그니처:  
  
**Boolean WaitForJournal(System.String, Int32, System.String)**  
  
설명:  
  
**저널 텍스트가 나타날 때까지 주어진 시간 종료를 기다리십시오.**  
  
예시:  
  
```python  
if WaitForJournal("town guards", 5000, "system"):  
```  
  



