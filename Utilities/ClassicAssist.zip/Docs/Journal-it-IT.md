# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Journal  
### ClearJournal  
  
Sintassi del comando:  
  
**Void ClearJournal()**  
  
Descrizione:  
  
**Pulisci il Journal dal testo presente**  
  
Esempio:  
  
```python  
ClearJournal()  
```  
  
### InJournal  
  
Sintassi del comando:  
  
**Boolean InJournal(System.String, System.String, Int32)**  
  
Descrizione:  
  
**Cerca del testo all'interno del Journal, il tipo di fonte del testo è opzionale (system, nome pg..)**  
  
Esempio:  
  
```python  
if InJournal("town guards", "system"):  
```  
  
### WaitForJournal  
  
Sintassi del comando:  
  
**Boolean WaitForJournal(System.String, Int32, System.String)**  
  
Descrizione:  
  
**Attendi per un dato ammontare di tempo che si presenti nel Journal il testo desiderato**  
  
Esempio:  
  
```python  
if WaitForJournal("town guards", 5000, "system"):  
```  
  



