# ClassicAssist Macro Commands  
Generated on 12/7/2020 6:04:46 AM  
Version: 0.3.156.250  
  
## Movement  
### Pathfind  
  
Method Signature:  
  
**Void Pathfind(Int32, Int32, Int32)**  
  
#### Parameters  
* x: X Coordinate.  
* y: Y Coordinate.  
* z: Z Coordinate.  
  
Description:  
  
**Requests client to pathfind to given coordinates / entity**  
  
Example:  
  
```python  
#Pathfind to coordinates
Pathfind(1438, 1630, 20)

#Pathfind to entity
SetEnemy(0x3c9)
Pathfind('enemy')  
```  
  
### Pathfind  
  
Method Signature:  
  
**Void Pathfind(System.Object)**  
  
#### Parameters  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Description:  
  
**Requests client to pathfind to given coordinates / entity**  
  
Example:  
  
```python  
#Pathfind to coordinates
Pathfind(1438, 1630, 20)

#Pathfind to entity
SetEnemy(0x3c9)
Pathfind('enemy')  
```  
  
### Run  
  
Method Signature:  
  
**Boolean Run(System.String)**  
  
#### Parameters  
* direction: Direction, ie "West". See Also: [Direction](#Direction)  
  
Description:  
  
**Run in the given direction.**  
  
Example:  
  
```python  
Run("east")  
```  
  
### SetForceWalk  
  
Method Signature:  
  
**Void SetForceWalk(Boolean)**  
  
Description:  
  
**Set force walk, True or False**  
  
Example:  
  
```python  
SetForceWalk(True)  
```  
  
### ToggleForceWalk  
  
Method Signature:  
  
**Void ToggleForceWalk()**  
  
Description:  
  
**Toggle Force Walk**  
  
Example:  
  
```python  
ToggleForceWalk()  
```  
  
### Turn  
  
Method Signature:  
  
**Void Turn(System.String)**  
  
#### Parameters  
* direction: Direction, ie "West". See Also: [Direction](#Direction)  
  
Description:  
  
**Turn in the given direction.**  
  
Example:  
  
```python  
Turn("east")  
```  
  
### Walk  
  
Method Signature:  
  
**Boolean Walk(System.String)**  
  
#### Parameters  
* direction: Direction, ie "West".  
  
Description:  
  
**Walk in the given direction.**  
  
Example:  
  
```python  
Walk("east")  
```  
  



## Types  
### Direction  
* North  
* Northeast  
* East  
* Southeast  
* South  
* Southwest  
* West  
* Northwest  
* Invalid  
  
