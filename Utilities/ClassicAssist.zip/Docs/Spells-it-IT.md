# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Spells  
### Cast  
  
Sintassi del comando:  
  
**Boolean Cast(System.String, System.Object)**  
  
#### Parametri  
* name: Nome Spell.  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Casta una Spell su di un alias**  
  
Esempio:  
  
```python  
Cast("Recall", "runebook")  
```  
  
### Cast  
  
Sintassi del comando:  
  
**Void Cast(System.String)**  
  
#### Parametri  
* name: Nome Spell.  
  
Descrizione:  
  
**Casta una Spell su di un alias**  
  
Esempio:  
  
```python  
Cast("Recall", "runebook")  
```  
  
### InterruptSpell  
  
Sintassi del comando:  
  
**Void InterruptSpell()**  
  
Descrizione:  
  
**Attempts to interrupt spell by lifting an item briefly.**  
  
Esempio:  
  
```python  
InterruptSpell()  
```  
  



