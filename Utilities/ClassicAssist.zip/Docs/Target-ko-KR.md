# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 타겟  
### CancelTarget  
  
메서드 시그니처:  
  
**Void CancelTarget()**  
  
설명:  
  
**기존의 커서 / 대상을 취소하세요.**  
  
예시:  
  
```python  
CancelTarget()  
```  
  
### ClearTargetQueue  
  
메서드 시그니처:  
  
**Void ClearTargetQueue()**  
  
설명:  
  
**마지막 대상이 사용 가능한 경우 대상 순서를 삭제합니다.**  
  
예시:  
  
```python  
ClearTargetQueue()  
```  
  
### GetEnemy  
  
메서드 시그니처:  
  
**Boolean GetEnemy(System.Collections.Generic.IEnumerable`1[System.String], System.String, System.String, System.String)**  
  
#### 파라미터  
* notorieties:  . 참조: [TargetNotoriety](#TargetNotoriety)  
* bodytype:  . (옵션) 참조: [TargetBodyType](#TargetBodyType)  
* distance:  . (옵션) 참조: [TargetDistance](#TargetDistance)  
* infliction:  . (옵션) 참조: [TargetInfliction](#TargetInfliction)  
  
설명:  
  
**적의 이름을 설정하세요.**  
  
예시:  
  
```python  
#get murderer
GetEnemy(['Murderer'])
#get closest murderer, any body type
GetEnemy(['Murderer'], 'Any', 'Closest')
#get next any notoriety, humanoid or transformation - unmounted
GetEnemy(['Any'], 'Both', 'Next', 'Unmounted')  
```  
  
### GetFriend  
  
메서드 시그니처:  
  
**Boolean GetFriend(System.Collections.Generic.IEnumerable`1[System.String], System.String, System.String, System.String)**  
  
#### 파라미터  
* notorieties:  . 참조: [TargetNotoriety](#TargetNotoriety)  
* bodytype:  . (옵션) 참조: [TargetBodyType](#TargetBodyType)  
* distance:  . (옵션) 참조: [TargetDistance](#TargetDistance)  
* infliction:  . (옵션) 참조: [TargetInfliction](#TargetInfliction)  
  
설명:  
  
**친구의 이름을 설정하십시오.**  
  
예시:  
  
```python  
GetFriend(["Murderer"])  
```  
  
### GetFriendListOnly  
  
메서드 시그니처:  
  
**Boolean GetFriendListOnly(System.String, System.String, System.String)**  
  
#### 파라미터  
* distance:  . (옵션) 참조: [TargetDistance](#TargetDistance)  
* targetinfliction:  . (옵션) 참조: [TargetInfliction](#TargetInfliction)  
* bodytype:  . (옵션) 참조: [TargetBodyType](#TargetBodyType)  
  
설명:  
  
**친구 목록서 '가장 가까운'/ '가장 가까운'/ '다음'에 있는 친구를 설정합니다.**  
  
예시:  
  
```python  
GetFriendListOnly("Closest")  
```  
  
### SetEnemy  
  
메서드 시그니처:  
  
**Void SetEnemy(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**시리얼 / 이름으로 적을 설정합니다.**  
  
예시:  
  
```python  
SetEnemy("mount")  
```  
  
### SetFriend  
  
메서드 시그니처:  
  
**Void SetFriend(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**친구를 시리얼 / 이름으로 설정합니다.**  
  
예시:  
  
```python  
SetFriend("mount")  
```  
  
### SetLastTarget  
  
메서드 시그니처:  
  
**Void SetLastTarget(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**마지막 대상을  시리얼 / 이름으로 설정합니다.**  
  
예시:  
  
```python  
SetLastTarget("mount")  
```  
  
### Target  
  
메서드 시그니처:  
  
**Void Target(System.Object, Boolean, Boolean)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* checkrange: 지정되지 않음 - 사용 방법에 대한 설명을 보세요. (옵션)  
* usequeue: 지정되지 않음 - 사용 방법에 대한 설명을 보세요. (옵션)  
  
설명:  
  
**대상을 표시합니다. (매개 변수는 시리얼 또는 이름입니다.)**  
  
예시:  
  
```python  
Target("self")  
```  
  
### TargetByResource  
  
메서드 시그니처:  
  
**Void TargetByResource(System.Object, System.String)**  
  
#### 파라미터  
* toolobj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* resourcetype: 문자열 값 - 사용 방법에 대한 설명을 보세요. 참조: [TargetResourceType](#TargetResourceType)  
  
설명:  
  
**도구를 사용하고 자원 대상으로합니다. (서버 지원 필요 (OSI / ServUO))**  
  
예시:  
  
```python  
TargetByResource('pickaxe', 'Ore')  
```  
  
### TargetExists  
  
메서드 시그니처:  
  
**Boolean TargetExists(System.String)**  
  
#### 파라미터  
* targetexiststype: 대상 유형 - "harmful", "beneficial", "neutral". (옵션) 참조: [TargetExistsType](#TargetExistsType)  
  
설명:  
  
**커서가 표시되면 제공된 값과 일치하는 '임의', 옵션은 '임의', '유익한', '유해한' 또는 '중립'인 경우 기본값으로 설정됩니다.**  
  
예시:  
  
```python  
if TargetExists("Harmful"):  
```  
  
### TargetGround  
  
메서드 시그니처:  
  
**Void TargetGround(System.Object, Int32, Int32)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* hue: 아이탬 색조 또는 모든 값에 -1. (옵션)  
* range: 거리 예시) 10. (옵션)  
  
설명:  
  
**대상의 지면에 및 색조 및 거리에 대한 매개 변수를 표시합니다.**  
  
예시:  
  
```python  
TargetGround(0x190, -1, 10)  
```  
  
### TargetTileOffset  
  
메서드 시그니처:  
  
**Void TargetTileOffset(Int32, Int32, Int32, Int32)**  
  
#### 파라미터  
* xoffset: X 좌표 변수.  
* yoffset: Y 좌표 변수.  
* zoffset: Y 좌표 변수.  
* itemid: 아이템ID/그래픽 예시) 0x3db . (옵션)  
  
설명:  
  
**플레이어를 기준으로 주어진 타일을 대상을 지정합니다.**  
  
예시:  
  
```python  
#Targets the tile at the current Y coordinate + 1
TargetTileOffset(0, 1, 0)  
```  
  
### TargetTileOffsetResource  
  
메서드 시그니처:  
  
**Void TargetTileOffsetResource(Int32, Int32, Int32, Int32)**  
  
#### 파라미터  
* xoffset: X 좌표 변수.  
* yoffset: Y 좌표 변수.  
* zoffset: Y 좌표 변수.  
* itemid: 아이템ID/그래픽 예시) 0x3db . (옵션)  
  
설명:  
  
**Targets the tile at the given offsets relative to the player (automatically targeting trees/cave tiles/water if present)**  
  
예시:  
  
```python  
TargetTileOffsetResource(0, -1, 0)  
```  
  
### TargetTileRelative  
  
메서드 시그니처:  
  
**Void TargetTileRelative(System.Object, Int32, Boolean, Int32)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* distance: 정수 값 - 사용 방법에 대한 설명을 보세요.  
* reverse: Ture/False 값, 사용 방법에 대한 설명을 보세요. (옵션)  
* itemid: 아이템ID/그래픽 예시) 0x3db . (옵션)  
  
설명:  
  
**시리얼/대상으로 주어진 거리를 목표 타일로 지정하고 역 모드의 경우 선택적으로 표시됩니다.**  
  
예시:  
  
```python  
TargetTileRelative("self", 1, False)  
```  
  
### TargetType  
  
메서드 시그니처:  
  
**Void TargetType(System.Object, Int32, Int32)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* hue: 아이탬 색조 또는 모든 값에 -1. (옵션)  
* range: 거리 예시) 10. (옵션)  
  
설명:  
  
**플레이어 백팩의 유형, 색조 및 검색이 매개 변수로 표시됩니다.**  
  
예시:  
  
```python  
TargetType(0xff, 0, 3)  
```  
  
### TargetXYZ  
  
메서드 시그니처:  
  
**Void TargetXYZ(Int32, Int32, Int32, Int32)**  
  
#### 파라미터  
* x: X 좌표.  
* y: Y 좌표.  
* z: Z 좌표.  
* itemid: 아이템ID/그래픽 예시) 0x3db . (옵션)  
  
설명:  
  
**좌표로 지면을 지정합니다.**  
  
예시:  
  
```python  
TargetXYZ(1000, 1000, 0)  
```  
  
### WaitForTarget  
  
메서드 시그니처:  
  
**Boolean WaitForTarget(Int32)**  
  
#### 파라미터  
* timeout: milliseconds 지정된 시간초과됨. (옵션)  
  
설명:  
  
**서버에서 대상의 패킷을 기다립니다. (선택적 시간 매개 변수는 본값 5000 milliseconds)**  
  
예시:  
  
```python  
WaitForTarget(5000)  
```  
  
### WaitForTargetOrFizzle  
  
메서드 시그니처:  
  
**Boolean WaitForTargetOrFizzle(Int32)**  
  
#### 파라미터  
* timeout: milliseconds 지정된 시간초과됨.  
  
설명:  
  
**마법 시전이 실패 하거나 작동하지 않는 경우  일정 시간을 기다립니다.**  
  
예시:  
  
```python  
WaitForTargetOrFizzle(5000)  
```  
  
### WaitingForTarget  
  
메서드 시그니처:  
  
**Boolean WaitingForTarget()**  
  
설명:  
  
**코어에서 대상 서버를 기다리고있을 때 동작합니다.**  
  
예시:  
  
```python  
if WaitingForTarget():  
```  
  



## 타입  
### TargetBodyType  
* Any  
* Humanoid  
* Transformation  
* Both  
  
### TargetDistance  
* Next  
* Nearest  
* Closest  
* Previous  
  
### TargetExistsType  
* Any  
* Beneficial  
* Harmful  
* Neutral  
  
### TargetInfliction  
* Any  
* Lowest  
* Poisoned  
* Mortaled  
* Paralyzed  
* Dead  
* Unmounted  
  
### TargetNotoriety  
* None  
* Innocent  
* Criminal  
* Enemy  
* Murderer  
* Friend  
* Gray  
* Any  
  
### TargetResourceType  
* Ore  
* Sand  
* Wood  
* Graves  
* Red_Mushrooms  
  
