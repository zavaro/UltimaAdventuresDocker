# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Target  
### CancelTarget  
  
Sintassi del comando:  
  
**Void CancelTarget()**  
  
Descrizione:  
  
**Cancella il Target aperto corrente**  
  
Esempio:  
  
```python  
CancelTarget()  
```  
  
### ClearTargetQueue  
  
Sintassi del comando:  
  
**Void ClearTargetQueue()**  
  
Descrizione:  
  
**Pulisti la Coda Target quando la Coda Target è abilitata**  
  
Esempio:  
  
```python  
ClearTargetQueue()  
```  
  
### GetEnemy  
  
Sintassi del comando:  
  
**Boolean GetEnemy(System.Collections.Generic.IEnumerable`1[System.String], System.String, System.String, System.String)**  
  
#### Parametri  
* notorieties:  . Guarda anche: [TargetNotoriety](#TargetNotoriety)  
* bodytype:  . (Opzionale) Guarda anche: [TargetBodyType](#TargetBodyType)  
* distance:  . (Opzionale) Guarda anche: [TargetDistance](#TargetDistance)  
* infliction:  . (Opzionale) Guarda anche: [TargetInfliction](#TargetInfliction)  
  
Descrizione:  
  
**Acquisisci un mobile e impostalo come Enemy**  
  
Esempio:  
  
```python  
#get murderer
GetEnemy(['Murderer'])
#get closest murderer, any body type
GetEnemy(['Murderer'], 'Any', 'Closest')
#get next any notoriety, humanoid or transformation - unmounted
GetEnemy(['Any'], 'Both', 'Next', 'Unmounted')  
```  
  
### GetFriend  
  
Sintassi del comando:  
  
**Boolean GetFriend(System.Collections.Generic.IEnumerable`1[System.String], System.String, System.String, System.String)**  
  
#### Parametri  
* notorieties:  . Guarda anche: [TargetNotoriety](#TargetNotoriety)  
* bodytype:  . (Opzionale) Guarda anche: [TargetBodyType](#TargetBodyType)  
* distance:  . (Opzionale) Guarda anche: [TargetDistance](#TargetDistance)  
* infliction:  . (Opzionale) Guarda anche: [TargetInfliction](#TargetInfliction)  
  
Descrizione:  
  
**Acquisisci un mobile e impostalo come Friend**  
  
Esempio:  
  
```python  
GetFriend(["Murderer"])  
```  
  
### GetFriendListOnly  
  
Sintassi del comando:  
  
**Boolean GetFriendListOnly(System.String, System.String, System.String)**  
  
#### Parametri  
* distance:  . (Opzionale) Guarda anche: [TargetDistance](#TargetDistance)  
* targetinfliction:  . (Opzionale) Guarda anche: [TargetInfliction](#TargetInfliction)  
* bodytype:  . (Opzionale) Guarda anche: [TargetBodyType](#TargetBodyType)  
  
Descrizione:  
  
**Acquisisci un Friend che è presente nella solo nella FriendList, parametri di distanza: 'Closest'/'Nearest'/'Next'**  
  
Esempio:  
  
```python  
GetFriendListOnly("Closest")  
```  
  
### SetEnemy  
  
Sintassi del comando:  
  
**Void SetEnemy(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Imposta come Enemy un Serial o un Alias**  
  
Esempio:  
  
```python  
SetEnemy("mount")  
```  
  
### SetFriend  
  
Sintassi del comando:  
  
**Void SetFriend(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Imposta come Friend un Serial o un Alias**  
  
Esempio:  
  
```python  
SetFriend("mount")  
```  
  
### SetLastTarget  
  
Sintassi del comando:  
  
**Void SetLastTarget(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Imposta come Last Target un Serial o un Alias**  
  
Esempio:  
  
```python  
SetLastTarget("mount")  
```  
  
### Target  
  
Sintassi del comando:  
  
**Void Target(System.Object, Boolean, Boolean)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* checkrange: Non specificato: vedere la descrizione per l'utilizzo. (Opzionale)  
* usequeue: Non specificato: vedere la descrizione per l'utilizzo. (Opzionale)  
  
Descrizione:  
  
**Targetta un oggetto/mobile (seriale o alias)**  
  
Esempio:  
  
```python  
Target("self")  
```  
  
### TargetByResource  
  
Sintassi del comando:  
  
**Void TargetByResource(System.Object, System.String)**  
  
#### Parametri  
* toolobj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* resourcetype: Valore stringa: vedere la descrizione per l'utilizzo. Guarda anche: [TargetResourceType](#TargetResourceType)  
  
Descrizione:  
  
**Usa un Tool e targetta uno specifico Type di risorse (Richiede supporto server OSI / ServUO)**  
  
Esempio:  
  
```python  
TargetByResource('pickaxe', 'Ore')  
```  
  
### TargetExists  
  
Sintassi del comando:  
  
**Boolean TargetExists(System.String)**  
  
#### Parametri  
* targetexiststype: Tipo Target - "harmful", "beneficial", o "neutral". (Opzionale) Guarda anche: [TargetExistsType](#TargetExistsType)  
  
Descrizione:  
  
**Risulta se il Target è aperto. E' possibile specificare il tipo di target, se 'Any', 'Beneficial', 'Harmful' o 'Neutral'**  
  
Esempio:  
  
```python  
if TargetExists("Harmful"):  
```  
  
### TargetGround  
  
Sintassi del comando:  
  
**Void TargetGround(System.Object, Int32, Int32)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* hue: ID colore oggetto o -1 per tutti. (Opzionale)  
* range: Raggio, per esempio 10. (Opzionale)  
  
Descrizione:  
  
**Targetta un seriale grafico in schermata, parametri opzionali per colore e distanza**  
  
Esempio:  
  
```python  
TargetGround(0x190, -1, 10)  
```  
  
### TargetTileOffset  
  
Sintassi del comando:  
  
**Void TargetTileOffset(Int32, Int32, Int32, Int32)**  
  
#### Parametri  
* xoffset: X Coordinate offset.  
* yoffset: Y Coordinate offset.  
* zoffset: Y Coordinate offset.  
* itemid: ID oggetto o ID grafico tipo 0x3db. (Opzionale)  
  
Descrizione:  
  
**Targetta il pavimento alla distanza data, relativa a se**  
  
Esempio:  
  
```python  
#Targets the tile at the current Y coordinate + 1
TargetTileOffset(0, 1, 0)  
```  
  
### TargetTileOffsetResource  
  
Sintassi del comando:  
  
**Void TargetTileOffsetResource(Int32, Int32, Int32, Int32)**  
  
#### Parametri  
* xoffset: X Coordinate offset.  
* yoffset: Y Coordinate offset.  
* zoffset: Y Coordinate offset.  
* itemid: ID oggetto o ID grafico tipo 0x3db. (Opzionale)  
  
Descrizione:  
  
**Targetta un Tile ad una distanza relativa a se (targetta automaticamente alberi/grotte/acqua tiles se presenti)**  
  
Esempio:  
  
```python  
TargetTileOffsetResource(0, -1, 0)  
```  
  
### TargetTileRelative  
  
Sintassi del comando:  
  
**Void TargetTileRelative(System.Object, Int32, Boolean, Int32)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* distance: Valore intero: vedere la descrizione per l'utilizzo.  
* reverse: Valore True/False, vedere la descrizione per l'uso. (Opzionale)  
* itemid: ID oggetto o ID grafico tipo 0x3db. (Opzionale)  
  
Descrizione:  
  
**Targetta un tile ad una distanza desiderata, relativa ad un alias o seriale. Boolean opzionale per modalità inversa.**  
  
Esempio:  
  
```python  
TargetTileRelative("self", 1, False)  
```  
  
### TargetType  
  
Sintassi del comando:  
  
**Void TargetType(System.Object, Int32, Int32)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
* hue: ID colore oggetto o -1 per tutti. (Opzionale)  
* range: Raggio, per esempio 10. (Opzionale)  
  
Descrizione:  
  
**Usa un seriale grafico dallo zaino. Parametri opzionali per colore e livello**  
  
Esempio:  
  
```python  
TargetType(0xff, 0, 3)  
```  
  
### TargetXYZ  
  
Sintassi del comando:  
  
**Void TargetXYZ(Int32, Int32, Int32, Int32)**  
  
#### Parametri  
* x: X Coordinate.  
* y: Y Coordinate.  
* z: Z Coordinate.  
* itemid: ID oggetto o ID grafico tipo 0x3db. (Opzionale)  
  
Descrizione:  
  
**Targetta il pavimento alle coordinate fornite**  
  
Esempio:  
  
```python  
TargetXYZ(1000, 1000, 0)  
```  
  
### WaitForTarget  
  
Sintassi del comando:  
  
**Boolean WaitForTarget(Int32)**  
  
#### Parametri  
* timeout: Timeout specificato in millisecondi. (Opzionale)  
  
Descrizione:  
  
**Attendi finche un Target aperto è disponibile (se non specificato, è a 5000)**  
  
Esempio:  
  
```python  
WaitForTarget(5000)  
```  
  
### WaitForTargetOrFizzle  
  
Sintassi del comando:  
  
**Boolean WaitForTargetOrFizzle(Int32)**  
  
#### Parametri  
* timeout: Timeout specificato in millisecondi.  
  
Descrizione:  
  
**Attende un ammontare di tempo specifico che il Target si apra, interrompendo l'attesa in caso di flizz / impossibilità di cast.**  
  
Esempio:  
  
```python  
WaitForTargetOrFizzle(5000)  
```  
  
### WaitingForTarget  
  
Sintassi del comando:  
  
**Boolean WaitingForTarget()**  
  
Descrizione:  
  
**Risulta se stai aspettando che un Target aperto è disponibile**  
  
Esempio:  
  
```python  
if WaitingForTarget():  
```  
  



## Tipi  
### TargetBodyType  
* Any  
* Humanoid  
* Transformation  
* Both  
  
### TargetDistance  
* Next  
* Nearest  
* Closest  
* Previous  
  
### TargetExistsType  
* Any  
* Beneficial  
* Harmful  
* Neutral  
  
### TargetInfliction  
* Any  
* Lowest  
* Poisoned  
* Mortaled  
* Paralyzed  
* Dead  
* Unmounted  
  
### TargetNotoriety  
* None  
* Innocent  
* Criminal  
* Enemy  
* Murderer  
* Friend  
* Gray  
* Any  
  
### TargetResourceType  
* Ore  
* Sand  
* Wood  
* Graves  
* Red_Mushrooms  
  
