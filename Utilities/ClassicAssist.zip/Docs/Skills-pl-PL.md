# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Skille  
### SetSkill  
  
Sygnatura metody:  
  
**Void SetSkill(System.String, System.String)**  
  
#### Parametry  
* skill: Nazwa skilla.  
* status: Status zablokowania skilla - "up", "down", "locked". Zobacz też: [LockStatus](#LockStatus)  
  
Opis:  
  
**Ustawia tryb przyrostu danej umiejętności. Dopuszczalne wartości: "up", "down", "locked".**  
  
Przykład:  
  
```python  
SetSkill("hiding", "locked")  
```  
  
### SetStatus  
  
Sygnatura metody:  
  
**Void SetStatus(System.String, System.String)**  
  
#### Parametry  
* stat: Zmienna typu string - zobacz opis, aby zobaczyć użycie. Zobacz też: [StatType](#StatType)  
* lockstatus: Status zablokowania skilla - "up", "down", "locked". Zobacz też: [LockStatus](#LockStatus)  
  
Opis:  
  
**Ustawia status przyrostu skilli. Możliwe wartości: "up", "down", "locked".**  
  
Przykład:  
  
```python  
SetStatus('str', 'locked')  
```  
  
### Skill  
  
Sygnatura metody:  
  
**Double Skill(System.String)**  
  
#### Parametry  
* name: Nazwa skilla.  
  
Opis:  
  
**Zwraca bazową wartość umiejętności.**  
  
Przykład:  
  
```python  
if Skill("hiding") < 100:  
```  
  
### SkillCap  
  
Sygnatura metody:  
  
**Double SkillCap(System.String)**  
  
#### Parametry  
* name: Nazwa skilla.  
  
Opis:  
  
**Zwraca skill cap podanego skilla**  
  
Przykład:  
  
```python  
if SkillCap("Blacksmithy") == 120:  
```  
  
### SkillState  
  
Sygnatura metody:  
  
**System.String SkillState(System.String)**  
  
#### Parametry  
* name: Nazwa skilla.  
  
Opis:  
  
**Zwraca obecny status trybu przyrostu umiejętności. Dopuszczalne wartości zwracane: "up", "down", "locked".**  
  
Przykład:  
  
```python  
if SkillState("hiding') == "locked":  
```  
  
### UseSkill  
  
Sygnatura metody:  
  
**Void UseSkill(System.String)**  
  
#### Parametry  
* skill: Nazwa skilla.  
  
Opis:  
  
**Używa wybraną umiejętność.**  
  
Przykład:  
  
```python  
UseSkill("Hiding")  
```  
  



## Typy  
### LockStatus  
* Up  
* Down  
* Locked  
  
### StatType  
* Str  
* Dex  
* Int  
  
