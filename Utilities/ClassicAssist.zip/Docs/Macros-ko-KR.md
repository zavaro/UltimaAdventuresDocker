# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 매크로  
### PlayMacro  
  
메서드 시그니처:  
  
**Void PlayMacro(System.String)**  
  
#### 파라미터  
* name: 매크로 이름.  
  
설명:  
  
**주어진 이름의 매크로를 재생합니다.**  
  
예시:  
  
```python  
PlayMacro("beep")  
```  
  
### Replay  
  
메서드 시그니처:  
  
**Void Replay()**  
  
설명:  
  
**현재 매크로 재생합니다.**  
  
예시:  
  
```python  
Replay()  
```  
  
### Stop  
  
메서드 시그니처:  
  
**Void Stop(System.String)**  
  
#### 파라미터  
* name: 문자열 값 - 사용 방법에 대한 설명을 보세요. (옵션)  
  
설명:  
  
**현재 매크로를 중지합니다.**  
  
예시:  
  
```python  
# Stop the current macro
Stop()
# Stop a macro by name
Stop("Background Macro")  
```  
  
### StopAll  
  
메서드 시그니처:  
  
**Void StopAll()**  
  
설명:  
  
**실행중인 모든 매크로를 중지합니다.**  
  
예시:  
  
```python  
StopAll()  
```  
  



