# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Agenti  
### Counter  
  
Sintassi del comando:  
  
**Int32 Counter(System.String)**  
  
#### Parametri  
* name: Nome Agent.  
  
Descrizione:  
  
**Conta il numero di oggetti di uno specifico Agente Contatore**  
  
Esempio:  
  
```python  
Counter("bm")  
```  
  
### Dress  
  
Sintassi del comando:  
  
**Void Dress(System.String)**  
  
#### Parametri  
* name: Nome Agent. (Opzionale)  
  
Descrizione:  
  
**Vesti tutti gli oggetti presenti in un Agente di Dress**  
  
Esempio:  
  
```python  
Dress("Dress-1")  
```  
  
### DressConfig  
  
Sintassi del comando:  
  
**Void DressConfig()**  
  
Descrizione:  
  
**Aggiunge tutti gli elementi equipaggiati a un elenco temporaneo che non è persistito alla chiusura del client**  
  
Esempio:  
  
```python  
DressConfig()  
```  
  
### Dressing  
  
Sintassi del comando:  
  
**Boolean Dressing()**  
  
Descrizione:  
  
**Risulta se un Agente di Dress sta correntemente vestendo o svestendo qualcosa**  
  
Esempio:  
  
```python  
if Dressing():  
```  
  
### Organizer  
  
Sintassi del comando:  
  
**Void Organizer(System.String, System.Object, System.Object)**  
  
#### Parametri  
* name: Nome Agent.  
* sourcecontainer: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
* destinationcontainer: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Esegui un Agente Organizzatore**  
  
Esempio:  
  
```python  
Organize("Organizer-1")  
```  
  
### Organizing  
  
Sintassi del comando:  
  
**Boolean Organizing()**  
  
Descrizione:  
  
**Risulta se un Agente Organizzatore sta correntemente spostanto oggetti**  
  
Esempio:  
  
```python  
if Organizing():  
```  
  
### SetAutolootContainer  
  
Sintassi del comando:  
  
**Void SetAutolootContainer(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Imposta il contenitore per l'Autoloot Agent, dove mettere gli oggetti lotati.**  
  
Esempio:  
  
```python  
SetAutolootContainer("backpack")  
```  
  
### SetOrganizerContainers  
  
Sintassi del comando:  
  
**Void SetOrganizerContainers(System.String, System.Object, System.Object)**  
  
#### Parametri  
* entryname: Nome Agent.  
* sourcecontainer: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
* destinationcontainer: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self". (Opzionale)  
  
Descrizione:  
  
**Imposta la l'origine e la destinazione per un Organizer specifico**  
  
Esempio:  
  
```python  
SetOrganizerContainers("Organizer-1", "backpack", "bank")  
```  
  
### Undress  
  
Sintassi del comando:  
  
**Void Undress(System.String)**  
  
#### Parametri  
* name: Nome Agent.  
  
Descrizione:  
  
**Svesti tutti gli oggetti presenti in un Agente di Dress**  
  
Esempio:  
  
```python  
Undress("Dress-1")  
```  
  



