# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Menu  
### CloseMenu  
  
Sintassi del comando:  
  
**Void CloseMenu(Int32)**  
  
#### Parametri  
* gumpid: ID oggetto o ID grafico tipo 0x3db.  
  
Descrizione:  
  
**Chiude uno specifico menu (ID)**  
  
Esempio:  
  
```python  
CloseMenu(0x1d1)  
```  
  
### InMenu  
  
Sintassi del comando:  
  
**Boolean InMenu(Int32, System.String)**  
  
#### Parametri  
* gumpid: ID oggetto o ID grafico tipo 0x3db.  
* text: Valore stringa: vedere la descrizione per l'utilizzo.  
  
Descrizione:  
  
**Risulta True se il titolo del menu o i titoli inseriti contengono il testo dato**  
  
Esempio:  
  
```python  
UseSkill('Tracking')
WaitForMenu(0x1d0, 5000)
ReplyMenu(0x1d0, 3, 0x2106, 0)
WaitForMenu(0x1d1, 5000)
if InMenu(0x1d1, 'Omar'):
 HeadMsg('Omar is in range', 'self')
CloseMenu(0x1d1)  
```  
  
### MenuExists  
  
Sintassi del comando:  
  
**Boolean MenuExists(Int32)**  
  
Descrizione:  
  
**Risulta True se l'ID di un menu esiste**  
  
Esempio:  
  
```python  
if MenuExists(0x1d1):  
```  
  
### ReplyMenu  
  
Sintassi del comando:  
  
**Void ReplyMenu(Int32, Int32, Int32, Int32)**  
  
#### Parametri  
* gumpid: ID oggetto o ID grafico tipo 0x3db.  
* buttonid: ID tasto Gump.  
* itemid: ID oggetto o ID grafico tipo 0x3db. (Opzionale)  
* hue: ID colore oggetto o -1 per tutti. (Opzionale)  
  
Descrizione:  
  
**Invia risposta tasto ad un menu del server**  
  
Esempio:  
  
```python  
ReplyMenu(0x1d0, 3, 0x2106, 0)  
```  
  
### WaitForMenu  
  
Sintassi del comando:  
  
**Boolean WaitForMenu(Int32, Int32)**  
  
#### Parametri  
* gumpid: ID oggetto o ID grafico tipo 0x3db. (Opzionale)  
* timeout: Timeout specificato in millisecondi. (Opzionale)  
  
Descrizione:  
  
**Aspetta fino alla ricezione del menu packet, parametri opzionali di gump ID e timeout**  
  
Esempio:  
  
```python  
UseSkill('Tracking')
WaitForMenu(0x1d0, 5000)
ReplyMenu(0x1d0, 3, 0x2106, 0)
WaitForMenu(0x1d1, 5000)  
```  
  



