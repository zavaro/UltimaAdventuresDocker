# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Główne  
### DisplayQuestPointer  
  
Sygnatura metody:  
  
**Void DisplayQuestPointer(Int32, Int32, Boolean)**  
  
#### Parametry  
* x: Koordynata X.  
* y: Koordynata Y.  
* enabled: Wartość True/False - zobacz opis, aby zobaczyć użycie. (Opcjonalny)  
  
Opis:  
  
**Display quest arrow pointer to specified coordinates**  
  
Przykład:  
  
```python  
# add pointer
DisplayQuestPointer(1000, 1000, True)
Pause(2000)
# remove pointer
DisplayQuestPointer(1000, 1000, False)  
```  
  
### HideEntity  
  
Sygnatura metody:  
  
**Void HideEntity(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
  
Opis:  
  
**Usuwa przedmiot/obiekt mobile z ekranu**  
  
Przykład:  
  
```python  
ClearIgnoreList()
# Hide all corpses on screen
while FindType(0x2006):
 HideEntity('found')
 IgnoreObject('found')  
```  
  
### Hotkeys  
  
Sygnatura metody:  
  
**Void Hotkeys(System.String)**  
  
#### Parametry  
* onoff: "on" lub "off". (Opcjonalny)  
  
Opis:  
  
**Włącza lub wyłacza skróty klawiszowe.**  
  
Przykład:  
  
```python  
Hotkeys()  
```  
  
### Info  
  
Sygnatura metody:  
  
**Void Info(System.Object)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self". (Opcjonalny)  
  
Opis:  
  
**Pokazuje inspektora obiektów dla zadanego aliasu lub seriala. Poprosi o wskazanie jeśli brak parametru.**  
  
Przykład:  
  
```python  
Info("self")  
```  
  
### InvokeVirtue  
  
Sygnatura metody:  
  
**Void InvokeVirtue(System.String)**  
  
#### Parametry  
* virtue: Zmienna typu string - zobacz opis, aby zobaczyć użycie. Zobacz też: [Virtues](#Virtues)  
  
Opis:  
  
**Użyj virtue po nazwie.**  
  
Przykład:  
  
```python  
InvokeVirtue("Honor")  
```  
  
### MessageBox  
  
Sygnatura metody:  
  
**Void MessageBox(System.String, System.String)**  
  
#### Parametry  
* title: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
* body: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Pokazuje proste okno z wpisaną nazwą oraz tekstem.**  
  
Przykład:  
  
```python  
MessageBox("title", "message")  
```  
  
### Pause  
  
Sygnatura metody:  
  
**Void Pause(Int32)**  
  
#### Parametry  
* milliseconds: Timeout w milisekundach.  
  
Opis:  
  
**Zarzymuje wykonanie makra na podaną liczbę milisekund.**  
  
Przykład:  
  
```python  
Pause(1000)  
```  
  
### Playing  
  
Sygnatura metody:  
  
**Boolean Playing(System.String)**  
  
#### Parametry  
* macroname: Nazwa makra.  
  
Opis:  
  
**Zwraca "true" jeśli makro jest uruchomione, do używania w makrach uruchomionych w tle.**  
  
Przykład:  
  
```python  
if Playing():  
```  
  
### Playing  
  
Sygnatura metody:  
  
**Boolean Playing()**  
  
Opis:  
  
**Zwraca "true" jeśli makro jest uruchomione, do używania w makrach uruchomionych w tle.**  
  
Przykład:  
  
```python  
if Playing():  
```  
  
### PlaySound  
  
Sygnatura metody:  
  
**Void PlaySound(System.Object)**  
  
Opis:  
  
**Odegraj dźwięk po id albo plik .wav**  
  
Przykład:  
  
```python  
PlaySound("Bike Horn.wav")  
```  
  
### Resync  
  
Sygnatura metody:  
  
**Void Resync()**  
  
Opis:  
  
**Wyślij żądanie resynchronizacji do serwera.**  
  
Przykład:  
  
```python  
Resync()  
```  
  
### SetQuietMode  
  
Sygnatura metody:  
  
**Void SetQuietMode(Boolean)**  
  
#### Parametry  
* onoff: "on" lub "off".  
  
Opis:  
  
**Ustawia tryb cichy dla makra, dzięki któremu redukuje się liczba komunikatów na wyjścu z makra.**  
  
Przykład:  
  
```python  
SetQuietMode(True)  
```  
  
### SysMessage  
  
Sygnatura metody:  
  
**Void SysMessage(System.String, Int32)**  
  
#### Parametry  
* text: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
* hue: Kolor przedmiotu (-1 jeśli jakikolwiek). (Opcjonalny)  
  
Opis:  
  
**Wyślij wiadomość tekstową.**  
  
Przykład:  
  
```python  
# default hue
SysMessage("Hello")
# specifying hue
SysMessage("Hello", 35)  
```  
  
### WarMode  
  
Sygnatura metody:  
  
**Void WarMode(System.String)**  
  
#### Parametry  
* onoff: "on" lub "off". (Opcjonalny)  
  
Opis:  
  
**Ustawia status trybu walki. Dopuszczalne parametry: "on", "off". Domyślnie ustawione w trybie przełącznika.**  
  
Przykład:  
  
```python  
WarMode("on")  
```  
  



## Typy  
### Virtues  
* None  
* Honor  
* Sacrafice  
* Valor  
* Compassion  
* Honesty  
* Humility  
* Justice  
* Spirituality  
  
