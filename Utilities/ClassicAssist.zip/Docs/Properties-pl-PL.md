# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Właściwości  
### Property  
  
Sygnatura metody:  
  
**Boolean Property(System.Object, System.String)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* value: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
  
Opis:  
  
**Zwraca "true" jeśli dany tekst pojawi się we właściwościach przedmiotu.**  
  
Przykład:  
  
```python  
if Property("item", "Defense Chance Increase"):  
```  
  
### PropertyValue  
  
Sygnatura metody:  
  
**T PropertyValue[T](System.Object, System.String, Int32)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* property: Zmienna typu string - zobacz opis, aby zobaczyć użycie.  
* argument: Zmianna typu integer - zobacz opis, aby zobaczyć użycie. (Opcjonalny)  
  
Opis:  
  
**Zwraca wartość danej właściwości przedmiotu. Opcjonalnym argumentem jest index właściwości.**  
  
Przykład:  
  
```python  
val = PropertyValue[int]("backpack", "Contents")  
```  
  
### WaitForProperties  
  
Sygnatura metody:  
  
**Boolean WaitForProperties(System.Object, Int32)**  
  
#### Parametry  
* obj: An entity serial in integer or hex format, or an alias string such as "self".  
* timeout: Timeout w milisekundach.  
  
Opis:  
  
**Oczekuje na pakiet z właściwościami przedmiotu.**  
  
Przykład:  
  
```python  
WaitForProperties("backpack", 5000)  
```  
  



