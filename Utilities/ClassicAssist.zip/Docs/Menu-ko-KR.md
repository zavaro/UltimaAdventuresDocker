# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 메뉴  
### CloseMenu  
  
메서드 시그니처:  
  
**Void CloseMenu(Int32)**  
  
#### 파라미터  
* gumpid: 아이템ID/그래픽 예시) 0x3db .  
  
설명:  
  
**지정된 메뉴 ID를 닫습니다.**  
  
예시:  
  
```python  
CloseMenu(0x1d1)  
```  
  
### InMenu  
  
메서드 시그니처:  
  
**Boolean InMenu(Int32, System.String)**  
  
#### 파라미터  
* gumpid: 아이템ID/그래픽 예시) 0x3db .  
* text: 문자열 값 - 사용 방법에 대한 설명을 보세요.  
  
설명:  
  
**메뉴 제목이나 항목 제목에 지정된 텍스트가 포함되어 있으면 동작합니다.**  
  
예시:  
  
```python  
UseSkill('Tracking')
WaitForMenu(0x1d0, 5000)
ReplyMenu(0x1d0, 3, 0x2106, 0)
WaitForMenu(0x1d1, 5000)
if InMenu(0x1d1, 'Omar'):
 HeadMsg('Omar is in range', 'self')
CloseMenu(0x1d1)  
```  
  
### MenuExists  
  
메서드 시그니처:  
  
**Boolean MenuExists(Int32)**  
  
설명:  
  
**주어진 메뉴 ID가 존재하면 동작합니다.**  
  
예시:  
  
```python  
if MenuExists(0x1d1):  
```  
  
### ReplyMenu  
  
메서드 시그니처:  
  
**Void ReplyMenu(Int32, Int32, Int32, Int32)**  
  
#### 파라미터  
* gumpid: 아이템ID/그래픽 예시) 0x3db .  
* buttonid: 검프버튼 ID.  
* itemid: 아이템ID/그래픽 예시) 0x3db . (옵션)  
* hue: 아이탬 색조 또는 모든 값에 -1. (옵션)  
  
설명:  
  
**서버 메뉴에 회신 버튼을 보냅니다.**  
  
예시:  
  
```python  
ReplyMenu(0x1d0, 3, 0x2106, 0)  
```  
  
### WaitForMenu  
  
메서드 시그니처:  
  
**Boolean WaitForMenu(Int32, Int32)**  
  
#### 파라미터  
* gumpid: 아이템ID/그래픽 예시) 0x3db . (옵션)  
* timeout: milliseconds 지정된 시간초과됨. (옵션)  
  
설명:  
  
**메뉴 패킷이 수신 될 때까지 일시 중지 됩니다.**  
  
예시:  
  
```python  
UseSkill('Tracking')
WaitForMenu(0x1d0, 5000)
ReplyMenu(0x1d0, 3, 0x2106, 0)
WaitForMenu(0x1d1, 5000)  
```  
  



