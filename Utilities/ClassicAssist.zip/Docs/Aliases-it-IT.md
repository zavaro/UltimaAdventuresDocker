# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Alias  
### FindAlias  
  
Sintassi del comando:  
  
**Boolean FindAlias(System.String)**  
  
#### Parametri  
* aliasname: Nome Alias.  
  
Descrizione:  
  
**Risulta se un dato alias puo' essere trovato sullo schermo**  
  
Esempio:  
  
```python  
if FindAlias("mount"):  
```  
  
### GetAlias  
  
Sintassi del comando:  
  
**Int32 GetAlias(System.String)**  
  
#### Parametri  
* aliasname: Nome Alias.  
  
Descrizione:  
  
**Aggancia l'alias desiderato**  
  
Esempio:  
  
```python  
GetAlias("mount")  
```  
  
### PromptAlias  
  
Sintassi del comando:  
  
**Int32 PromptAlias(System.String)**  
  
#### Parametri  
* aliasname: Nome Alias.  
  
Descrizione:  
  
**Richiedi con un cursore target nel gioco per creare/sostituire un alias**  
  
Esempio:  
  
```python  
PromptAlias("mount")  
```  
  
### SetAlias  
  
Sintassi del comando:  
  
**Void SetAlias(System.String, System.Object)**  
  
#### Parametri  
* aliasname: Nome Alias.  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Crea/sostituisci un alias con un seriale specifico**  
  
Esempio:  
  
```python  
SetAlias("mount", 0x40000001")  
```  
  
### SetMacroAlias  
  
Sintassi del comando:  
  
**Void SetMacroAlias(System.String, System.Object)**  
  
#### Parametri  
* aliasname: Nome Alias.  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Crea/sostituisci un alias con un seriale specifico, l'alias è valido solo per lo script corrente**  
  
Esempio:  
  
```python  
SetMacroAlias("mount", 0x40000001")  
```  
  
### UnsetAlias  
  
Sintassi del comando:  
  
**Void UnsetAlias(System.String)**  
  
#### Parametri  
* aliasname: Nome Alias.  
  
Descrizione:  
  
**Rimuovi un alias**  
  
Esempio:  
  
```python  
UnsetAlias("mount")  
```  
  



