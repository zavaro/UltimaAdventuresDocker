# Lista Comandi per gli Script di ClassicAssist  
Generato il 07/12/2020 06:04:46  
Versione: 0.3.156.250  
Tradotto da riin4  
  
## Movimento  
### Pathfind  
  
Sintassi del comando:  
  
**Void Pathfind(System.Object)**  
  
#### Parametri  
* obj: Un'entità seriale in formato intero o esadecimale o una stringa alias come "self".  
  
Descrizione:  
  
**Attiva Pathfind alle cordinate specifiche**  
  
Esempio:  
  
```python  
#Pathfind to coordinates
Pathfind(1438, 1630, 20)

#Pathfind to entity
SetEnemy(0x3c9)
Pathfind('enemy')  
```  
  
### Pathfind  
  
Sintassi del comando:  
  
**Void Pathfind(Int32, Int32, Int32)**  
  
#### Parametri  
* x: X Coordinate.  
* y: Y Coordinate.  
* z: Z Coordinate.  
  
Descrizione:  
  
**Attiva Pathfind alle cordinate specifiche**  
  
Esempio:  
  
```python  
#Pathfind to coordinates
Pathfind(1438, 1630, 20)

#Pathfind to entity
SetEnemy(0x3c9)
Pathfind('enemy')  
```  
  
### Run  
  
Sintassi del comando:  
  
**Boolean Run(System.String)**  
  
#### Parametri  
* direction: Direzione. Per esempio "West". Guarda anche: [Direction](#Direction)  
  
Descrizione:  
  
**Corri nella direzione desiderata**  
  
Esempio:  
  
```python  
Run("east")  
```  
  
### SetForceWalk  
  
Sintassi del comando:  
  
**Void SetForceWalk(Boolean)**  
  
Descrizione:  
  
**Imposta Camminata Forzata (True o False)**  
  
Esempio:  
  
```python  
SetForceWalk(True)  
```  
  
### ToggleForceWalk  
  
Sintassi del comando:  
  
**Void ToggleForceWalk()**  
  
Descrizione:  
  
**Abilita/Disabilita Camminata Forzata**  
  
Esempio:  
  
```python  
ToggleForceWalk()  
```  
  
### Turn  
  
Sintassi del comando:  
  
**Void Turn(System.String)**  
  
#### Parametri  
* direction: Direzione. Per esempio "West". Guarda anche: [Direction](#Direction)  
  
Descrizione:  
  
**Girati nella direzione desiderata**  
  
Esempio:  
  
```python  
Turn("east")  
```  
  
### Walk  
  
Sintassi del comando:  
  
**Boolean Walk(System.String)**  
  
#### Parametri  
* direction: Direzione. Per esempio "West".  
  
Descrizione:  
  
**Cammina nella direzione desiderata**  
  
Esempio:  
  
```python  
Walk("east")  
```  
  



## Tipi  
### Direction  
* North  
* Northeast  
* East  
* Southeast  
* South  
* Southwest  
* West  
* Northwest  
* Invalid  
  
