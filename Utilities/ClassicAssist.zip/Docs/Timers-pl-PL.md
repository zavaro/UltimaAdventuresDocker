# Lista komend makr  
Utworzono na 07.12.2020 06:04:46  
Wersja: 0.3.156.250  
Aru (ŁCh)  
  
## Liczniki  
### CreateTimer  
  
Sygnatura metody:  
  
**Void CreateTimer(System.String)**  
  
#### Parametry  
* name: Nazwa timera.  
  
Opis:  
  
**Tworzy nowy licznilk o podanej nazwie.**  
  
Przykład:  
  
```python  
CreateTimer("shmoo")  
```  
  
### RemoveTimer  
  
Sygnatura metody:  
  
**Void RemoveTimer(System.String)**  
  
#### Parametry  
* name: Nazwa timera.  
  
Opis:  
  
**Usuwa licznik o podanej nazwie.**  
  
Przykład:  
  
```python  
RemoveTimer("shmoo")  
```  
  
### SetTimer  
  
Sygnatura metody:  
  
**Void SetTimer(System.String, Int32)**  
  
#### Parametry  
* name: An entity serial in integer or hex format, or an alias string such as "self".  
* milliseconds: Zmianna typu integer - zobacz opis, aby zobaczyć użycie. (Opcjonalny)  
  
Opis:  
  
**Ustawia licznik czasu dla podanej wartości. Jeśli takiego nie ma jest tworzony nowy.**  
  
Przykład:  
  
```python  
SetTimer("shmoo", 0)  
```  
  
### Timer  
  
Sygnatura metody:  
  
**Int64 Timer(System.String)**  
  
#### Parametry  
* name: Nazwa timera.  
  
Opis:  
  
**Sprawdza wartość podanego licznika czasu.**  
  
Przykład:  
  
```python  
if Timer("shmoo") > 10000:  
```  
  
### TimerExists  
  
Sygnatura metody:  
  
**Boolean TimerExists(System.String)**  
  
#### Parametry  
* name: Nazwa timera.  
  
Opis:  
  
**Zwraca "true" jeśli podany licznik czasu istnieje.**  
  
Przykład:  
  
```python  
if TimerExists("shmoo"):  
```  
  
### TimerMsg  
  
Sygnatura metody:  
  
**Void TimerMsg(System.String)**  
  
#### Parametry  
* name: Nazwa timera.  
  
Opis:  
  
**Zwraca czas naliczony poprzez licznik czasu jako "SysMessage".**  
  
Przykład:  
  
```python  
TimerMsg("shmoo")  
```  
  



