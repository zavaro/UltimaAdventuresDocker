# 클래식어시스트 매크로 명령어  
생성된 2020-12-07 오전 6:04:46  
버전: 0.3.156.250  
Translated by Mark Hunt & Andy H.  
  
## 행동  
### Attack  
  
메서드 시그니처:  
  
**Void Attack(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**모빌 공격 (매개변수는 시리얼 또는 별칭일 수 있습니다).**  
  
예시:  
  
```python  
Attack("last")  
```  
  
### BandageSelf  
  
메서드 시그니처:  
  
**Boolean BandageSelf()**  
  
설명:  
  
**플레이어에게 붕대를 적용합니다.**  
  
예시:  
  
```python  
BandageSelf()  
```  
  
### ClearHands  
  
메서드 시그니처:  
  
**Void ClearHands(System.String)**  
  
#### 파라미터  
* hand: 손 - "왼쪽", "오른쪽", "양쪽". (옵션)  
  
설명:  
  
**손 비우기, "왼손", "오른손" 또는 "양손"**  
  
예시:  
  
```python  
ClearHands("both")  
```  
  
### ClearUseOnce  
  
메서드 시그니처:  
  
**Void ClearUseOnce()**  
  
설명:  
  
**UseOnce 리스트 지우기**  
  
예시:  
  
```python  
ClearUseOnce()  
```  
  
### ClickObject  
  
메서드 시그니처:  
  
**Void ClickObject(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**오브젝트 한번클릭 (매개변수는 시리얼 또는 별칭일 수 있습니다).**  
  
예시:  
  
```python  
ClickObject("last")  
```  
  
### Contents  
  
메서드 시그니처:  
  
**Int32 Contents(System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**주어진 컨테이너의 아이템 카운트를 반환합니다**  
  
예시:  
  
```python  
if Contents("backpack") > 120:  
```  
  
### ContextMenu  
  
메서드 시그니처:  
  
**Void ContextMenu(System.Object, Int32)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* entry: 메뉴 화면 인덱스 숫자.  
  
설명:  
  
**Context 메뉴 옵션을 요청**  
  
예시:  
  
```python  
ContextMenu(0x00aabbcc, 1)  
```  
  
### EquipItem  
  
메서드 시그니처:  
  
**Void EquipItem(System.Object, System.Object)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* layer: "한손" 또는 "부적" 등과 같은 레이어를 나태니는 문자열. 참조: [Layer](#Layer)  
  
설명:  
  
**특정 아이템을 주어진 레이어에 장착하십시오. 오브젝트 인스펙터를 사용하여 레이어 값을 결정하십시오.**  
  
예시:  
  
```python  
EquipItem("axe", "TwoHanded")  
```  
  
### EquipLastWeapon  
  
메서드 시그니처:  
  
**Void EquipLastWeapon()**  
  
설명:  
  
**빠른 무기전환 패킷을 보냅니다 (AoS이전 서버에서는 지원되지 않을 수 있습니다).**  
  
예시:  
  
```python  
EquipLastWeapon()  
```  
  
### EquipType  
  
메서드 시그니처:  
  
**Void EquipType(Int32, System.Object)**  
  
#### 파라미터  
* id: 아이템ID/그래픽 예시) 0x3db .  
* layer: "한손" 또는 "부적" 등과 같은 레이어를 나태니는 문자열. 참조: [Layer](#Layer)  
  
설명:  
  
**특정 타입을 주어진 레이어에 장착하십시오. 오브젝트 인스펙터를 사용하여 레이어 값을 결정하십시오.**  
  
예시:  
  
```python  
EquipType(0xff, "TwoHanded")  
```  
  
### Feed  
  
메서드 시그니처:  
  
**Void Feed(System.Object, Int32, Int32, Int32)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* graphic: 아이템ID/그래픽 예시) 0x3db .  
* amount: 수량을 나타내는 정수, 예) 10. (옵션)  
* hue: 아이탬 색조 또는 모든 값에 -1. (옵션)  
  
설명:  
  
**그래픽으로 설정된 별명 또는 시리어를 공급하십시오.**  
  
예시:  
  
```python  
Feed("mount", 0xff)  
```  
  
### FindLayer  
  
메서드 시그니처:  
  
**Boolean FindLayer(System.Object, System.Object)**  
  
#### 파라미터  
* layer: "한손" 또는 "부적" 등과 같은 레이어를 나태니는 문자열. 참조: [Layer](#Layer)  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**만약 지정된 레이어에 아이템이 존재한다면 Ture 값을 갖고 별칭을 업데이트합니다, 모빌의 시리얼/별칭 옵션을 체크**  
  
예시:  
  
```python  
if FindLayer("OneHanded"):  
```  
  
### InRegion  
  
메서드 시그니처:  
  
**Boolean InRegion(System.String, System.Object)**  
  
#### 파라미터  
* attribute: 문자열 값 - 사용 방법에 대한 설명을 보세요. 참조: [RegionAttributes](#RegionAttributes)  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**타겟의 범위가 지정된 속성을 가진경우 True 값을 갖습니다**  
  
예시:  
  
```python  
if InRegion("Guarded", "self")  
```  
  
### Ping  
  
메서드 시그니처:  
  
**Int64 Ping()**  
  
설명:  
  
**서버의 근접한 핑을 검색합니다. 실패하면 -1 입니다.**  
  
예시:  
  
```python  
Ping()  
```  
  
### Rename  
  
메서드 시그니처:  
  
**Void Rename(System.Object, System.String)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* name: 이름을 나타내는 문자열, 예시) "Snoopy".  
  
설명:  
  
**이름변경 요청을 보냅니다.**  
  
예시:  
  
```python  
Rename("mount", "Snoopy")  
```  
  
### ShowNames  
  
메서드 시그니처:  
  
**Void ShowNames(System.String)**  
  
#### 파라미터  
* showtype: 표시 유형 - "모빌" 또는 "시체". 참조: [ShowNamesType](#ShowNamesType)  
  
설명:  
  
**시체 그리고/또는 모빌 이름 표시 (매개변수 "모빌" 또는 "시체".**  
  
예시:  
  
```python  
ShowNames("corpses")  
```  
  
### ToggleMounted  
  
메서드 시그니처:  
  
**Void ToggleMounted()**  
  
설명:  
  
**말을 타고 있다면 말에서내리고, 또는 말을타고있지 않다면 말을타고, "마운트" 별칭이 없다면 마운트에 프롬프트를 활성화 합니다. **  
  
예시:  
  
```python  
ToggleMounted()  
```  
  
### UseObject  
  
메서드 시그니처:  
  
**Void UseObject(System.Object, Boolean)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* skipqueue: 지정되지 않음 - 사용 방법에 대한 설명을 보세요. (옵션)  
  
설명:  
  
**지정된 오브젝트에 대한 사용(더블클릭) 요청을 보냅니다. (매개변수는 시리얼 또는 별칭일 수 있습니다.)**  
  
예시:  
  
```python  
UseObject("mount")  
```  
  
### UseOnce  
  
메서드 시그니처:  
  
**Boolean UseOnce(Int32, Int32)**  
  
#### 파라미터  
* graphic: 아이템ID/그래픽 예시) 0x3db .  
* hue: 아이탬 색조 또는 모든 값에 -1. (옵션)  
  
설명:  
  
**너의 백팩으로 부터 특정 아이템 타입(그래픽)을 한번만 사용합니다.**  
  
예시:  
  
```python  
UseOnce(0xff)  
```  
  
### UseTargetedItem  
  
메서드 시그니처:  
  
**Void UseTargetedItem(System.Object, System.Object)**  
  
#### 파라미터  
* item: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* target: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
  
설명:  
  
**Uses specified item and targets target in one action. Requires server support (OSI / ServUO)**  
  
예시:  
  
```python  
UseTargetedItem('bandage', 'pet')  
```  
  
### UseType  
  
메서드 시그니처:  
  
**Void UseType(System.Object, Int32, System.Object)**  
  
#### 파라미터  
* type: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* hue: 아이탬 색조 또는 모든 값에 -1. (옵션)  
* container: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열. (옵션)  
  
설명:  
  
**주어진 타입에 대해서 사용(더블클릭) 요청을 보냅니다. HUE 및 컨테이너 오브젝트의 선택적 매개변수(기본값은 플레이어 백팩) (매개변수는 시리얼 및 별칭일 수 있습니다.)**  
  
예시:  
  
```python  
UseType(0xff)  
```  
  
### WaitForContents  
  
메서드 시그니처:  
  
**Boolean WaitForContents(System.Object, Int32)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* timeout: milliseconds 지정된 시간초과됨. (옵션)  
  
설명:  
  
**지정된 컨테이너의 내용을 기다립니다.**  
  
예시:  
  
```python  
WaitForContents("backpack", 5000)  
```  
  
### WaitForContext  
  
메서드 시그니처:  
  
**Boolean WaitForContext(System.Object, Int32, Int32)**  
  
#### 파라미터  
* obj: 정수 또는 16진수 형식의 실제 시리얼, 또는 "self"와 같은 이름 문자열.  
* entry: 메뉴 화면 인덱스 숫자.  
* timeout: milliseconds 지정된 시간초과됨.  
  
설명:  
  
**CONTEXT 메뉴 옵션을 요청하거나 기다립니다.**  
  
예시:  
  
```python  
WaitForContext(0x00aabbcc, 1, 5000)  
```  
  



## 타입  
### Layer  
* Invalid  
* OneHanded  
* TwoHanded  
* Shoes  
* Pants  
* Shirt  
* Helm  
* Gloves  
* Ring  
* Talisman  
* Neck  
* Hair  
* Waist  
* InnerTorso  
* Bracelet  
* Unused_xF  
* FacialHair  
* MiddleTorso  
* Earrings  
* Arms  
* Cloak  
* Backpack  
* OuterTorso  
* OuterLegs  
* InnerLegs  
* Mount  
* ShopBuy  
* ShopResale  
* ShopSell  
* Bank  
* LastValid  
  
### RegionAttributes  
* None  
* Guarded  
* Jail  
* Wilderness  
* Town  
* Dungeon  
* Special  
* Default  
  
### ShowNamesType  
* Mobiles  
* Corpses  
  
